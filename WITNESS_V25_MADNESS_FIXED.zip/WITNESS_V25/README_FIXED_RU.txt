WITNESS V25 FIXED / MADNESS

Что исправлено:
- Установщик больше не удаляет чужие .smx по маскам curse/error404/haunted/etc.
- Автокопирование в Left 4 Dead 2 и автозапуск No Mercy сохранены.
- Финальный ClientCommand exit сохранён намеренно.
- Добавлен addons/metamod/sourcemod.vdf для загрузки SourceMod через MetaMod.
- Оригинальный witness_core.smx перенесён в plugins/disabled как backup, чтобы не запускалась старая небезопасная версия.
- Исправленный исходник: WITNESS_FILES/addons/sourcemod/scripting/witness_core.sp
- Добавлены ConVar'ы: witness_enable, witness_nomercy_only, witness_debug.
- Добавлен OnPluginEnd/OnMapEnd cleanup.
- Сохраняются и восстанавливаются flags/значения host_timescale, sv_gravity, r_screenoverlay.
- Добавлен precache ambient/energy/zap1.wav.
- Убрано агрессивное удаление survivor-ботов.
- Infected purge стал мягче: common/witch удаляются, SI-боты убиваются, но не кикаются.
- props сталкера/статуй/void теперь трекаются и чистятся.
- darkness больше не перезаписывает env_fog_controller карты.
- ResetEngine больше не вызывается каждые 0.1 сек из логики ведьмы.
- Проверки клиента/карты/режима игры стали строже.
- Void-кнопки ограничены No Mercy c8m4/c8m5, а не всеми кампаниями.
- Knockback от ведьмы исправлен: теперь отталкивает от неё.

Важное:
В этой песочнице не было SourceMod spcomp, поэтому новый .smx не был скомпилирован. Установщик пытается скомпилировать fixed .sp автоматически, если найдёт spcomp.exe:
1) в WITNESS_FILES/addons/sourcemod/scripting/spcomp.exe, или
2) в папке игры left4dead2/addons/sourcemod/scripting/spcomp.exe.

Если spcomp.exe нет, установщик скопирует fixed .sp, но плагин не будет активен до компиляции.

Чтобы активировать вручную:
spcomp.exe witness_core.sp -o witness_core.smx
и положить witness_core.smx в:
left4dead2/addons/sourcemod/plugins/

Финал с exit сохранён по просьбе автора.
