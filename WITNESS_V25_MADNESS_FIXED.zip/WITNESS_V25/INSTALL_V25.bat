@echo off
call "%~dp0INSTALL_V25_FIXED.bat"
