@echo off
setlocal EnableExtensions EnableDelayedExpansion
color 0C
title WITNESS V25 FIXED - MADNESS

set "GAME="
if exist "D:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=D:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "E:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=E:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME set /p "GAME=Paste the folder containing left4dead2.exe: "
set "GAME=%GAME:"=%"
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%"

if not exist "%GAME%\left4dead2.exe" (
    echo ERROR: left4dead2.exe was not found.
    pause
    exit /b 1
)

set "SRC=%~dp0WITNESS_FILES"
set "DST=%GAME%\left4dead2"
set "PKG_SP=%SRC%\addons\sourcemod\scripting\witness_core.sp"
set "PKG_SMX=%SRC%\addons\sourcemod\plugins\witness_core.smx"
set "PKG_SPCOMP=%SRC%\addons\sourcemod\scripting\spcomp.exe"
set "GAME_SPCOMP=%DST%\addons\sourcemod\scripting\spcomp.exe"
set "DST_SP=%DST%\addons\sourcemod\scripting\witness_core.sp"
set "DST_SMX=%DST%\addons\sourcemod\plugins\witness_core.smx"

echo.
echo === WITNESS V25 FIXED ===
echo Installing to: %DST%
echo This installer no longer deletes other people's plugins.
echo It still auto-copies files and launches No Mercy as requested.
echo.

if exist "%PKG_SPCOMP%" (
    echo Compiling fixed plugin with packaged spcomp.exe...
    "%PKG_SPCOMP%" "%PKG_SP%" -o"%PKG_SMX%"
)

echo Copying payload...
xcopy "%SRC%\*" "%DST%\" /E /I /H /R /Y /Q >NUL

if not exist "%DST%\addons\metamod\sourcemod.vdf" (
    echo WARNING: SourceMod loader VDF was not copied correctly.
)

if not exist "%DST_SMX%" (
    if exist "%GAME_SPCOMP%" (
        echo Compiling fixed plugin with game spcomp.exe...
        "%GAME_SPCOMP%" "%DST_SP%" -o"%DST_SMX%"
    )
)

if not exist "%DST_SMX%" (
    color 0E
    echo.
    echo WARNING: fixed witness_core.smx is not present.
    echo The fixed source was copied to:
    echo   %DST_SP%
    echo.
    echo To make the fixed plugin active, compile witness_core.sp with SourceMod spcomp.exe
    echo and place witness_core.smx into:
    echo   %DST%\addons\sourcemod\plugins\
    echo.
    echo The original unfixed SMX is kept disabled in plugins\disabled and will NOT be loaded.
    echo.
    pause
) else (
    echo Fixed plugin is installed: %DST_SMX%
)

echo.
echo Launching L4D2: No Mercy, coop, insecure/local mod mode...
timeout /t 2 /nobreak >NUL
start "" "%GAME%\left4dead2.exe" -insecure -console -windowed -noborder +sv_consistency 0 +map c8m1_apartment coop
endlocal
