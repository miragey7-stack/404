#pragma semicolon 1
#pragma newdecls required

#include <sourcemod>
#include <sdktools>
#include <sdkhooks>

#define PLUGIN_VERSION "25.1.0-fixed"
#define INVALID_FLAGS -1

static const char SURV_MODELS[][] = {
    "models/survivors/survivor_namvet.mdl",
    "models/survivors/survivor_biker.mdl",
    "models/survivors/survivor_teenangst.mdl",
    "models/survivors/survivor_manager.mdl",
    "models/survivors/survivor_coach.mdl",
    "models/survivors/survivor_gambler.mdl"
};

enum Phase {
    P_Init = 0,
    P_Normal,
    P_Corrupted,
    P_Void
};

Phase g_Phase = P_Init;
bool g_bActive = false;
bool g_bSafeRoomTrap = false;
bool g_bEngineCaptured = false;
bool g_bDirectorStopped = false;

int g_iWitchRef = INVALID_ENT_REFERENCE;
float g_fNextTeleport = 0.0;
float g_fNextAttack = 0.0;
float g_fNextGlitch = 0.0;
float g_fNextStatue = 0.0;

int g_iChapter = 1;
char g_sMap[64];
float g_fSpawnOrigin[MAXPLAYERS + 1][3];

ConVar g_cvTimeScale = null;
ConVar g_cvGravity = null;
ConVar g_cvGameMode = null;
ConVar g_cvEnable = null;
ConVar g_cvNoMercyOnly = null;
ConVar g_cvDebug = null;

float g_fOldTimeScale = 1.0;
float g_fOldGravity = 800.0;
int g_iOldTimeScaleFlags = INVALID_FLAGS;
int g_iOldGravityFlags = INVALID_FLAGS;
int g_iOldOverlayFlags = INVALID_FLAGS;

Handle g_hMainTimer = null;
Handle g_hPurgeTimer = null;
ArrayList g_hSpawnedRefs = null;

public Plugin myinfo = {
    name = "WITNESS V25: MADNESS FIXED",
    author = "NELIXO, fixed by Arena.ai",
    description = "No Mercy isolation horror mode with safer cleanup and installer behavior",
    version = PLUGIN_VERSION
};

public void OnPluginStart() {
    g_cvEnable = CreateConVar("witness_enable", "1", "Enable WITNESS V25 mode.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    g_cvNoMercyOnly = CreateConVar("witness_nomercy_only", "1", "Run only on No Mercy maps c8m*. Recommended.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    g_cvDebug = CreateConVar("witness_debug", "0", "Print debug messages.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    AutoExecConfig(true, "witness_v25");

    HookEvent("round_start", Event_RoundStart, EventHookMode_PostNoCopy);
    HookEvent("player_spawn", Event_PlayerSpawn, EventHookMode_Post);
    HookEvent("door_close", Event_DoorClose, EventHookMode_Post);
    HookEntityOutput("func_button", "OnPressed", OnButtonPressed);

    g_cvTimeScale = FindConVar("host_timescale");
    g_cvGravity = FindConVar("sv_gravity");
    g_cvGameMode = FindConVar("mp_gamemode");

    CaptureEngineState();
    RelaxCheatFlags();

    g_hSpawnedRefs = new ArrayList();
    g_hMainTimer = CreateTimer(0.2, Timer_MainLoop, _, TIMER_REPEAT | TIMER_FLAG_NO_MAPCHANGE);
    g_hPurgeTimer = CreateTimer(0.5, Timer_PurgeInfected, _, TIMER_REPEAT | TIMER_FLAG_NO_MAPCHANGE);

    LogMessage("WITNESS V25 fixed loaded.");
}

public void OnPluginEnd() {
    g_bActive = false;

    if (g_hMainTimer != null) {
        KillTimer(g_hMainTimer);
        g_hMainTimer = null;
    }
    if (g_hPurgeTimer != null) {
        KillTimer(g_hPurgeTimer);
        g_hPurgeTimer = null;
    }

    CleanupSpawnedEntities();
    ResetEngine(true);

    if (g_hSpawnedRefs != null) {
        delete g_hSpawnedRefs;
        g_hSpawnedRefs = null;
    }

    LogMessage("WITNESS V25 fixed unloaded and cleaned up.");
}

public void OnMapStart() {
    GetCurrentMap(g_sMap, sizeof(g_sMap));
    g_iChapter = ParseChapter(g_sMap);
    g_bActive = ShouldRunOnThisMap();
    g_bSafeRoomTrap = false;
    g_Phase = P_Init;
    g_iWitchRef = INVALID_ENT_REFERENCE;
    g_fNextGlitch = 0.0;

    PrecacheModel("models/infected/witch.mdl", true);
    for (int i = 0; i < sizeof(SURV_MODELS); i++) {
        PrecacheModel(SURV_MODELS[i], true);
    }

    PrecacheSound("ambient/atmosphere/cave_hit5.wav", true);
    PrecacheSound("ambient/ambience/rainscapes/Thunder_close01.wav", true);
    PrecacheSound("ambient/energy/zap1.wav", true);
    PrecacheSound("music/witness_v25/screamer.wav", true);
    PrecacheSound("music/witness_v25/void_drone.wav", true);
    PrecacheSound("music/witness_v25/static_burst.wav", true);

    AddFileToDownloadsTable("materials/witness_v25/scream_face.vtf");
    AddFileToDownloadsTable("materials/witness_v25/scream_face.vmt");
    AddFileToDownloadsTable("materials/witness_v25/tv_noise.vtf");
    AddFileToDownloadsTable("materials/witness_v25/tv_noise.vmt");
    AddFileToDownloadsTable("sound/music/witness_v25/screamer.wav");
    AddFileToDownloadsTable("sound/music/witness_v25/void_drone.wav");
    AddFileToDownloadsTable("sound/music/witness_v25/static_burst.wav");

    if (g_bActive) {
        Debug("Active on map %s, chapter %d", g_sMap, g_iChapter);
        ResetEngine(false);
    } else {
        Debug("Inactive on map %s", g_sMap);
    }
}

public void OnMapEnd() {
    g_bActive = false;
    CleanupSpawnedEntities();
    ResetEngine(false);
}

public void OnClientPutInServer(int client) {
    SDKHook(client, SDKHook_OnTakeDamage, OnTakeDamage);
}

public Action OnTakeDamage(int victim, int &attacker, int &inflictor, float &damage, int &damagetype) {
    if (g_bActive && g_Phase >= P_Corrupted && IsValidSurvivor(victim) && (damagetype & DMG_FALL)) {
        damage = 0.0;
        return Plugin_Handled;
    }
    return Plugin_Continue;
}

public void OnEntityCreated(int entity, const char[] classname) {
    if (!g_bActive || g_Phase < P_Corrupted) {
        return;
    }

    if (StrEqual(classname, "infected") || StrEqual(classname, "witch")) {
        RequestFrame(Frame_RemoveEntity, EntIndexToEntRef(entity));
    }
}

public void Frame_RemoveEntity(any ref) {
    int ent = EntRefToEntIndex(ref);
    if (ent > MaxClients && IsValidEntity(ent)) {
        RemoveEntity(ent);
    }
}

public Action Timer_PurgeInfected(Handle timer) {
    if (!g_bActive || g_Phase < P_Corrupted) {
        return Plugin_Continue;
    }

    int ent = -1;
    while ((ent = FindEntityByClassname(ent, "infected")) != -1) {
        if (ent > MaxClients && IsValidEntity(ent)) {
            RemoveEntity(ent);
        }
    }

    while ((ent = FindEntityByClassname(ent, "witch")) != -1) {
        if (ent > MaxClients && IsValidEntity(ent)) {
            RemoveEntity(ent);
        }
    }

    for (int i = 1; i <= MaxClients; i++) {
        if (IsClientInGame(i) && IsFakeClient(i) && GetClientTeam(i) == 3 && IsPlayerAlive(i)) {
            ForcePlayerSuicide(i);
        }
    }

    return Plugin_Continue;
}

public void Event_RoundStart(Event event, const char[] name, bool dontBroadcast) {
    g_bActive = ShouldRunOnThisMap();
    g_Phase = P_Init;
    g_bSafeRoomTrap = false;
    g_iWitchRef = INVALID_ENT_REFERENCE;
    g_fNextGlitch = 0.0;
    CleanupSpawnedEntities();
    ResetEngine(false);
}

public void Event_PlayerSpawn(Event event, const char[] name, bool dontBroadcast) {
    if (!g_bActive) {
        return;
    }

    int client = GetClientOfUserId(event.GetInt("userid"));
    if (!IsValidSurvivor(client) || IsFakeClient(client)) {
        return;
    }

    GetClientAbsOrigin(client, g_fSpawnOrigin[client]);

    if (g_iChapter >= 2) {
        TriggerCorruption(client);
    } else if (g_Phase == P_Init) {
        g_Phase = P_Normal;
        ClientCommand(client, "r_screenoverlay \"\"");
    }
}

public void OnButtonPressed(const char[] output, int caller, int activator, float delay) {
    if (!g_bActive || g_Phase == P_Void) {
        return;
    }

    if (!IsValidSurvivor(activator) || IsFakeClient(activator)) {
        return;
    }

    if (ShouldButtonTriggerVoid(caller)) {
        TriggerVoid(activator);
    }
}

public void Event_DoorClose(Event event, const char[] name, bool dontBroadcast) {
    if (!g_bActive || g_Phase < P_Corrupted || !event.GetBool("checkpoint") || g_bSafeRoomTrap || g_iChapter >= 4) {
        return;
    }

    g_bSafeRoomTrap = true;
    int p = GetPrimaryPlayer();
    if (p <= 0) {
        return;
    }

    SetDarkness();
    EmitSoundToClient(p, "music/witness_v25/screamer.wav", SOUND_FROM_PLAYER, SNDCHAN_STATIC, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
    ScreenShake(p, 40.0, 30.0, 3.0);
    ShowOverlay(p, "witness_v25/scream_face", 3.0);

    float pos[3];
    GetClientAbsOrigin(p, pos);
    for (int i = 0; i < 8; i++) {
        int e = CreateEntityByName("prop_dynamic_override");
        if (e == -1) {
            continue;
        }

        DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS) - 1)]);
        DispatchKeyValue(e, "solid", "0");
        DispatchSpawn(e);
        TrackEntity(e);

        float y = i * 45.0 * FLOAT_PI / 180.0;
        float ep[3];
        ep[0] = pos[0] + Cosine(y) * 70.0;
        ep[1] = pos[1] + Sine(y) * 70.0;
        ep[2] = pos[2];

        float ea[3];
        ea[0] = 0.0;
        ea[1] = (y * 180.0 / FLOAT_PI) + 180.0;
        ea[2] = 0.0;

        TeleportEntity(e, ep, ea, NULL_VECTOR);
        SetEntityRenderMode(e, RENDER_TRANSCOLOR);
        SetEntityRenderColor(e, 0, 0, 0, 255);
        SetEntPropFloat(e, Prop_Send, "m_flModelScale", GetRandomFloat(2.5, 4.0));
        SetEntProp(e, Prop_Send, "m_nSequence", 0);
    }
}

public Action Timer_MainLoop(Handle timer) {
    if (!g_bActive) {
        return Plugin_Continue;
    }

    float now = GetGameTime();

    if (g_Phase == P_Normal) {
        for (int i = 1; i <= MaxClients; i++) {
            if (!IsValidSurvivor(i) || IsFakeClient(i)) {
                continue;
            }

            float pPos[3];
            GetClientAbsOrigin(i, pPos);
            if (GetVectorDistance(g_fSpawnOrigin[i], pPos) > 1500.0) {
                TriggerCorruption(i);
                break;
            }
        }
    } else if (g_Phase == P_Corrupted) {
        int p = GetPrimaryPlayer();
        if (p <= 0) {
            return Plugin_Continue;
        }

        UpdateWitch(p, now);
        UpdateGlitches(p, now);
        UpdateStatues(p, now);
    } else if (g_Phase == P_Void) {
        int p = GetPrimaryPlayer();
        if (p > 0) {
            float a[3];
            GetClientEyeAngles(p, a);
            a[2] += 0.5;
            TeleportEntity(p, NULL_VECTOR, a, NULL_VECTOR);
            PrintCenterText(p, "Y O U   C A N N O T   E X I T");
        }
    }

    return Plugin_Continue;
}

void TriggerCorruption(int client) {
    if (!IsValidSurvivor(client) || g_Phase >= P_Corrupted) {
        return;
    }

    g_Phase = P_Corrupted;
    g_fNextTeleport = GetGameTime() + 5.0;
    g_fNextStatue = GetGameTime() + 10.0;
    g_fNextGlitch = GetGameTime() + 4.0;

    EmitSoundToClient(client, "ambient/ambience/rainscapes/Thunder_close01.wav", SOUND_FROM_PLAYER, SNDCHAN_STATIC, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
    FadeClient(client, 255, 255, 255, 255, 200, 3000, 0x0010);

    SetDarkness();
    StopDirector();
    Debug("Corruption started by client %N", client);
}

void UpdateGlitches(int p, float now) {
    if (now <= g_fNextGlitch) {
        return;
    }

    g_fNextGlitch = now + GetRandomFloat(5.0, 15.0);
    int roll = GetRandomInt(0, 3);

    if (roll == 0) {
        float a[3];
        GetClientEyeAngles(p, a);
        a[2] = GetRandomFloat(-35.0, 35.0);
        TeleportEntity(p, NULL_VECTOR, a, NULL_VECTOR);
        EmitSoundToClient(p, "music/witness_v25/static_burst.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
        CreateTimer(3.0, Timer_RestoreRoll, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    } else if (roll == 1) {
        int effects = GetEntProp(p, Prop_Send, "m_fEffects");
        if (effects & 4) {
            SetEntProp(p, Prop_Send, "m_fEffects", effects & ~4);
        }
        ShowOverlay(p, "witness_v25/tv_noise", 0.5);
        EmitSoundToClient(p, "music/witness_v25/static_burst.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
    } else if (roll == 2 && g_cvGravity != null) {
        g_cvGravity.FloatValue = 200.0;
        CreateTimer(4.0, Timer_RestoreGrav, _, TIMER_FLAG_NO_MAPCHANGE);
    }
}

void UpdateStatues(int p, float now) {
    if (now <= g_fNextStatue) {
        return;
    }

    g_fNextStatue = now + GetRandomFloat(10.0, 20.0);

    float pPos[3], pAng[3];
    GetClientAbsOrigin(p, pPos);
    GetClientEyeAngles(p, pAng);

    float y = (pAng[1] + GetRandomFloat(-45.0, 45.0)) * FLOAT_PI / 180.0;
    float sP[3];
    sP[0] = pPos[0] + Cosine(y) * 500.0;
    sP[1] = pPos[1] + Sine(y) * 500.0;
    sP[2] = pPos[2] + 10.0;

    int e = CreateEntityByName("prop_dynamic_override");
    if (e == -1) {
        return;
    }

    DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS) - 1)]);
    DispatchSpawn(e);
    TrackEntity(e);

    float ea[3], d[3];
    MakeVectorFromPoints(sP, pPos, d);
    GetVectorAngles(d, ea);
    ea[0] = 0.0;
    ea[2] = 0.0;

    TeleportEntity(e, sP, ea, NULL_VECTOR);
    SetEntityRenderMode(e, RENDER_TRANSCOLOR);
    SetEntityRenderColor(e, 0, 0, 0, 255);
    SetEntPropFloat(e, Prop_Send, "m_flModelScale", GetRandomFloat(1.5, 3.0));
    SetEntProp(e, Prop_Send, "m_nSequence", 0);
    SetEntPropFloat(e, Prop_Send, "m_flPlaybackRate", 0.0);

    CreateTimer(8.0, Timer_DeleteTrackedEntity, EntIndexToEntRef(e), TIMER_FLAG_NO_MAPCHANGE);
}

void UpdateWitch(int p, float now) {
    int witch = EntRefToEntIndex(g_iWitchRef);
    if (witch == INVALID_ENT_REFERENCE || !IsValidEntity(witch)) {
        SpawnWitchStalker(p);
        return;
    }

    float wPos[3], pPos[3], dir[3], ang[3];
    GetEntPropVector(witch, Prop_Data, "m_vecAbsOrigin", wPos);
    GetClientAbsOrigin(p, pPos);

    MakeVectorFromPoints(wPos, pPos, dir);
    dir[2] = 0.0;
    NormalizeVector(dir, dir);
    GetVectorAngles(dir, ang);
    ang[0] = 0.0;
    ang[2] = 0.0;
    TeleportEntity(witch, NULL_VECTOR, ang, NULL_VECTOR);

    float dist = GetVectorDistance(wPos, pPos);
    bool looking = IsPlayerLookingAtPoint(p, wPos, 0.45);

    if (looking) {
        if (g_cvTimeScale != null) {
            g_cvTimeScale.FloatValue = 0.35;
        }

        int fov = RoundToNearest(70.0 + 15.0 * Sine(now * 5.0));
        SetEntProp(p, Prop_Send, "m_iDefaultFOV", fov);

        if (now > g_fNextAttack) {
            EmitSoundToClient(p, "ambient/energy/zap1.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 70);
            g_fNextAttack = now + 1.0;
        }
    } else {
        RestoreLookEffect(p);

        if (now > g_fNextTeleport) {
            g_fNextTeleport = now + GetRandomFloat(4.0, 8.0);
            float y = (ang[1] + 180.0 + GetRandomFloat(-45.0, 45.0)) * FLOAT_PI / 180.0;
            float nP[3];
            nP[0] = pPos[0] + Cosine(y) * 200.0;
            nP[1] = pPos[1] + Sine(y) * 200.0;
            nP[2] = pPos[2] + 10.0;
            TeleportEntity(witch, nP, NULL_VECTOR, NULL_VECTOR);
            SetEntProp(witch, Prop_Data, "m_nSequence", 6);
            SetEntPropFloat(witch, Prop_Send, "m_flPlaybackRate", 1.5);
            EmitSoundToClient(p, "ambient/atmosphere/cave_hit5.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 60);
        }
    }

    if (dist < 80.0) {
        EmitSoundToClient(p, "music/witness_v25/screamer.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
        ShowOverlay(p, "witness_v25/scream_face", 1.0);

        float vel[3];
        vel[0] = dir[0] * 1200.0;
        vel[1] = dir[1] * 1200.0;
        vel[2] = 300.0;
        TeleportEntity(p, NULL_VECTOR, NULL_VECTOR, vel);

        FadeClient(p, 255, 0, 0, 200, 200, 0, 0x0001);

        int effects = GetEntProp(p, Prop_Send, "m_fEffects");
        if (effects & 4) {
            SetEntProp(p, Prop_Send, "m_fEffects", effects & ~4);
        }

        RemoveEntity(witch);
        g_iWitchRef = INVALID_ENT_REFERENCE;
        g_fNextTeleport = now + 15.0;
    }
}

void SpawnWitchStalker(int p) {
    float pPos[3], pAng[3];
    GetClientAbsOrigin(p, pPos);
    GetClientEyeAngles(p, pAng);

    float yaw = (pAng[1] + 180.0) * FLOAT_PI / 180.0;
    float sPos[3];
    sPos[0] = pPos[0] + Cosine(yaw) * 800.0;
    sPos[1] = pPos[1] + Sine(yaw) * 800.0;
    sPos[2] = pPos[2] + 10.0;

    int e = CreateEntityByName("prop_dynamic_override");
    if (e == -1) {
        return;
    }

    DispatchKeyValue(e, "model", "models/infected/witch.mdl");
    DispatchKeyValue(e, "targetname", "witness_stalker");
    DispatchKeyValue(e, "solid", "0");
    DispatchSpawn(e);
    TrackEntity(e);

    float d[3], a[3];
    MakeVectorFromPoints(sPos, pPos, d);
    GetVectorAngles(d, a);
    a[0] = 0.0;
    a[2] = 0.0;
    TeleportEntity(e, sPos, a, NULL_VECTOR);
    SetEntityRenderMode(e, RENDER_TRANSCOLOR);
    SetEntityRenderColor(e, 0, 0, 0, 255);
    SetEntProp(e, Prop_Data, "m_nSequence", 4);

    g_iWitchRef = EntIndexToEntRef(e);
}

void TriggerVoid(int p) {
    if (!IsValidSurvivor(p) || g_Phase == P_Void) {
        return;
    }

    g_Phase = P_Void;
    Debug("Void finale started by client %N", p);

    float pos[3];
    GetClientAbsOrigin(p, pos);
    pos[2] += 2000.0;

    RemoveWeaponsFromSlot(p, 0);
    RemoveWeaponsFromSlot(p, 1);
    SetEntityMoveType(p, MOVETYPE_NONE);
    TeleportEntity(p, pos, NULL_VECTOR, NULL_VECTOR);

    SetDarkness();
    EmitSoundToClient(p, "music/witness_v25/void_drone.wav", SOUND_FROM_PLAYER, SNDCHAN_STATIC, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);

    for (int i = 0; i < 20; i++) {
        float yaw = (i * 18.0) * FLOAT_PI / 180.0;
        float mP[3];
        mP[0] = pos[0] + Cosine(yaw) * 200.0;
        mP[1] = pos[1] + Sine(yaw) * 200.0;
        mP[2] = pos[2];

        int e = CreateEntityByName("prop_dynamic_override");
        if (e == -1) {
            continue;
        }

        DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS) - 1)]);
        DispatchKeyValue(e, "solid", "0");
        DispatchSpawn(e);
        TrackEntity(e);

        float mA[3], d[3];
        MakeVectorFromPoints(mP, pos, d);
        GetVectorAngles(d, mA);
        mA[0] = 0.0;
        mA[2] = 0.0;
        TeleportEntity(e, mP, mA, NULL_VECTOR);
        SetEntityRenderMode(e, RENDER_TRANSCOLOR);
        SetEntityRenderColor(e, 0, 0, 0, 255);
        SetEntPropFloat(e, Prop_Send, "m_flModelScale", 2.0);
        SetEntProp(e, Prop_Data, "m_nSequence", 0);
    }

    // Intentionally preserved: this is part of the requested finale.
    CreateTimer(12.0, Timer_ExitGame, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
}

public Action Timer_ExitGame(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (p > 0 && IsClientInGame(p) && g_Phase == P_Void) {
        ClientCommand(p, "exit");
    }
    return Plugin_Stop;
}

public Action Timer_RestoreRoll(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (IsValidSurvivor(p)) {
        float a[3];
        GetClientEyeAngles(p, a);
        a[2] = 0.0;
        TeleportEntity(p, NULL_VECTOR, a, NULL_VECTOR);
    }
    return Plugin_Stop;
}

public Action Timer_RestoreGrav(Handle timer) {
    if (g_cvGravity != null) {
        g_cvGravity.FloatValue = g_fOldGravity;
    }
    return Plugin_Stop;
}

public Action Timer_DeleteTrackedEntity(Handle timer, any ref) {
    int e = EntRefToEntIndex(ref);
    if (e != INVALID_ENT_REFERENCE && e > MaxClients && IsValidEntity(e)) {
        EmitSoundToAll("music/witness_v25/static_burst.wav", e, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 0.4);
        RemoveEntity(e);
    }
    return Plugin_Stop;
}

void CaptureEngineState() {
    if (g_bEngineCaptured) {
        return;
    }

    if (g_cvTimeScale != null) {
        g_fOldTimeScale = g_cvTimeScale.FloatValue;
        g_iOldTimeScaleFlags = g_cvTimeScale.Flags;
    }

    if (g_cvGravity != null) {
        g_fOldGravity = g_cvGravity.FloatValue;
        g_iOldGravityFlags = g_cvGravity.Flags;
    }

    g_iOldOverlayFlags = GetCommandFlags("r_screenoverlay");
    g_bEngineCaptured = true;
}

void RelaxCheatFlags() {
    if (g_cvTimeScale != null) {
        g_cvTimeScale.Flags = g_cvTimeScale.Flags & ~FCVAR_CHEAT;
    }

    if (g_cvGravity != null) {
        g_cvGravity.Flags = g_cvGravity.Flags & ~FCVAR_CHEAT;
    }

    int overlayFlags = GetCommandFlags("r_screenoverlay");
    if (overlayFlags != INVALID_FLAGS) {
        SetCommandFlags("r_screenoverlay", overlayFlags & ~FCVAR_CHEAT);
    }
}

void ResetEngine(bool restoreFlags) {
    if (g_cvTimeScale != null) {
        g_cvTimeScale.FloatValue = g_fOldTimeScale;
        if (restoreFlags && g_iOldTimeScaleFlags != INVALID_FLAGS) {
            g_cvTimeScale.Flags = g_iOldTimeScaleFlags;
        }
    }

    if (g_cvGravity != null) {
        g_cvGravity.FloatValue = g_fOldGravity;
        if (restoreFlags && g_iOldGravityFlags != INVALID_FLAGS) {
            g_cvGravity.Flags = g_iOldGravityFlags;
        }
    }

    if (restoreFlags && g_iOldOverlayFlags != INVALID_FLAGS) {
        SetCommandFlags("r_screenoverlay", g_iOldOverlayFlags);
    }

    SetLightStyle(0, "m");

    if (g_bDirectorStopped) {
        ServerCommand("director_start");
        g_bDirectorStopped = false;
    }

    for (int i = 1; i <= MaxClients; i++) {
        if (!IsClientInGame(i) || IsFakeClient(i)) {
            continue;
        }

        SetEntProp(i, Prop_Send, "m_iDefaultFOV", 90);
        SetEntityMoveType(i, MOVETYPE_WALK);
        ClientCommand(i, "r_screenoverlay \"\"");
        StopSound(i, SNDCHAN_STATIC, "music/witness_v25/void_drone.wav");
        StopSound(i, SNDCHAN_STATIC, "music/witness_v25/screamer.wav");

        float a[3];
        GetClientEyeAngles(i, a);
        a[2] = 0.0;
        TeleportEntity(i, NULL_VECTOR, a, NULL_VECTOR);
    }
}

void RestoreLookEffect(int client) {
    if (g_cvTimeScale != null) {
        g_cvTimeScale.FloatValue = g_fOldTimeScale;
    }

    if (IsValidSurvivor(client)) {
        SetEntProp(client, Prop_Send, "m_iDefaultFOV", 90);
        float a[3];
        GetClientEyeAngles(client, a);
        if (FloatAbs(a[2]) > 0.1) {
            a[2] = 0.0;
            TeleportEntity(client, NULL_VECTOR, a, NULL_VECTOR);
        }
    }
}

void SetDarkness() {
    // Do not overwrite map fog controllers anymore; lightstyle is reversible enough for this mode.
    SetLightStyle(0, "a");
}

void StopDirector() {
    if (!g_bDirectorStopped) {
        ServerCommand("director_stop");
        g_bDirectorStopped = true;
    }
}

void CleanupSpawnedEntities() {
    int witch = EntRefToEntIndex(g_iWitchRef);
    if (witch != INVALID_ENT_REFERENCE && witch > MaxClients && IsValidEntity(witch)) {
        RemoveEntity(witch);
    }
    g_iWitchRef = INVALID_ENT_REFERENCE;

    if (g_hSpawnedRefs == null) {
        return;
    }

    for (int i = 0; i < g_hSpawnedRefs.Length; i++) {
        int ent = EntRefToEntIndex(g_hSpawnedRefs.Get(i));
        if (ent != INVALID_ENT_REFERENCE && ent > MaxClients && IsValidEntity(ent)) {
            RemoveEntity(ent);
        }
    }
    g_hSpawnedRefs.Clear();
}

void TrackEntity(int entity) {
    if (g_hSpawnedRefs != null && entity > MaxClients && IsValidEntity(entity)) {
        g_hSpawnedRefs.Push(EntIndexToEntRef(entity));
    }
}

void RemoveWeaponsFromSlot(int client, int slot) {
    for (int i = 0; i < 8; i++) {
        int weapon = GetPlayerWeaponSlot(client, slot);
        if (weapon == -1 || !IsValidEntity(weapon)) {
            break;
        }
        RemovePlayerItem(client, weapon);
        RemoveEntity(weapon);
    }
}

bool ShouldRunOnThisMap() {
    if (g_cvEnable == null || !g_cvEnable.BoolValue) {
        return false;
    }

    if (!IsAllowedGameMode()) {
        return false;
    }

    if (g_cvNoMercyOnly != null && g_cvNoMercyOnly.BoolValue && !IsNoMercyMap(g_sMap)) {
        return false;
    }

    return true;
}

bool IsAllowedGameMode() {
    if (g_cvGameMode == null) {
        return true;
    }

    char mode[32];
    g_cvGameMode.GetString(mode, sizeof(mode));
    return StrEqual(mode, "coop", false) || StrEqual(mode, "realism", false) || StrEqual(mode, "singleplayer", false);
}

bool IsNoMercyMap(const char[] map) {
    return StrContains(map, "c8m", false) == 0;
}

int ParseChapter(const char[] map) {
    int len = strlen(map);
    for (int i = 0; i < len - 1; i++) {
        if (map[i] == 'm' && i > 0 && map[0] == 'c') {
            int c = map[i + 1] - '0';
            if (c >= 1 && c <= 5) {
                return c;
            }
        }
    }
    return 1;
}

bool ShouldButtonTriggerVoid(int caller) {
    if (g_iChapter < 4 || !IsNoMercyMap(g_sMap)) {
        return false;
    }

    if (caller <= MaxClients || !IsValidEntity(caller)) {
        return false;
    }

    char target[128];
    GetEntPropString(caller, Prop_Data, "m_iName", target, sizeof(target));

    // No Mercy finale/elevator buttons are not consistent across edits, so keep a fallback,
    // but restrict it to c8m4/c8m5 instead of every chapter >= 4 in every campaign.
    if (target[0] == '\0') {
        return true;
    }

    return StrContains(target, "radio", false) != -1
        || StrContains(target, "finale", false) != -1
        || StrContains(target, "elevator", false) != -1
        || StrContains(target, "heli", false) != -1
        || StrContains(target, "rescue", false) != -1
        || StrContains(target, "button", false) != -1;
}

bool IsValidSurvivor(int client) {
    return client > 0
        && client <= MaxClients
        && IsClientInGame(client)
        && IsPlayerAlive(client)
        && GetClientTeam(client) == 2;
}

int GetPrimaryPlayer() {
    for (int i = 1; i <= MaxClients; i++) {
        if (IsValidSurvivor(i) && !IsFakeClient(i)) {
            return i;
        }
    }
    return 0;
}

bool IsPlayerLookingAtPoint(int client, const float point[3], float threshold) {
    float eye[3], angles[3], fwd[3], target[3];
    GetClientEyePosition(client, eye);
    GetClientEyeAngles(client, angles);
    GetAngleVectors(angles, fwd, NULL_VECTOR, NULL_VECTOR);

    float adjusted[3];
    adjusted[0] = point[0];
    adjusted[1] = point[1];
    adjusted[2] = point[2] + 40.0;

    MakeVectorFromPoints(eye, adjusted, target);
    NormalizeVector(target, target);

    if (GetVectorDotProduct(fwd, target) <= threshold) {
        return false;
    }

    TR_TraceRayFilter(eye, adjusted, MASK_SOLID, RayType_EndPoint, TraceIgnorePlayers, client);
    return !TR_DidHit();
}

public bool TraceIgnorePlayers(int entity, int contentsMask, any data) {
    if (entity > 0 && entity <= MaxClients) {
        return false;
    }

    if (entity > MaxClients && IsValidEntity(entity)) {
        char classname[64];
        GetEntityClassname(entity, classname, sizeof(classname));
        if (StrEqual(classname, "prop_dynamic") || StrEqual(classname, "prop_dynamic_override")) {
            return false;
        }
    }

    return true;
}

void ShowOverlay(int client, const char[] overlay, float duration) {
    if (!IsValidSurvivor(client)) {
        return;
    }

    ClientCommand(client, "r_screenoverlay \"%s\"", overlay);
    if (duration < 900.0) {
        DataPack pack = new DataPack();
        pack.WriteCell(GetClientUserId(client));
        CreateTimer(duration, Timer_RemoveOverlay, pack, TIMER_DATA_HNDL_CLOSE | TIMER_FLAG_NO_MAPCHANGE);
    }
}

public Action Timer_RemoveOverlay(Handle timer, DataPack pack) {
    pack.Reset();
    int client = GetClientOfUserId(pack.ReadCell());
    if (IsValidSurvivor(client)) {
        ClientCommand(client, "r_screenoverlay \"\"");
    }
    return Plugin_Stop;
}

void ScreenShake(int client, float amplitude, float frequency, float duration) {
    Handle msg = StartMessageOne("Shake", client);
    if (msg == null) {
        return;
    }

    BfWriteByte(msg, 0);
    BfWriteFloat(msg, amplitude);
    BfWriteFloat(msg, frequency);
    BfWriteFloat(msg, duration);
    EndMessage();
}

void FadeClient(int client, int r, int g, int b, int a, int fadeIn, int fadeOut, int flags) {
    Handle msg = StartMessageOne("Fade", client);
    if (msg == null) {
        return;
    }

    BfWriteShort(msg, fadeIn);
    BfWriteShort(msg, fadeOut);
    BfWriteShort(msg, flags);
    BfWriteByte(msg, r);
    BfWriteByte(msg, g);
    BfWriteByte(msg, b);
    BfWriteByte(msg, a);
    EndMessage();
}

void Debug(const char[] format, any ...) {
    if (g_cvDebug == null || !g_cvDebug.BoolValue) {
        return;
    }

    char buffer[256];
    VFormat(buffer, sizeof(buffer), format, 2);
    PrintToServer("[WITNESS] %s", buffer);
    LogMessage("[WITNESS] %s", buffer);
}
