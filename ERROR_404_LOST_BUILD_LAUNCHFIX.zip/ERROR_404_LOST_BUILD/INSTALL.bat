@echo off
setlocal EnableExtensions
color 0C
title ERROR 404 LOST BUILD Installer
set "GAME="
if exist "D:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=D:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "E:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=E:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME set /p "GAME=Paste the folder containing left4dead2.exe: "
set "GAME=%GAME:"=%"
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%"
if not exist "%GAME%\left4dead2.exe" (
  echo ERROR: left4dead2.exe was not found.
  pause
  exit /b 1
)
set "GAME_L4D2=%GAME%\left4dead2"
set "DST=%GAME_L4D2%\addons\error404_lost_build"
if not exist "%DST%" mkdir "%DST%"
xcopy "%~dp0addons\error404_lost_build\*" "%DST%\" /E /I /H /R /Y /Q >NUL

rem Root fallback: some local builds do not discover unpacked addon mutations reliably.
xcopy "%~dp0addons\error404_lost_build\modes\*" "%GAME_L4D2%\modes\" /E /I /H /R /Y /Q >NUL
xcopy "%~dp0addons\error404_lost_build\scripts\*" "%GAME_L4D2%\scripts\" /E /I /H /R /Y /Q >NUL
xcopy "%~dp0addons\error404_lost_build\addoninfo.txt" "%DST%\" /Y /Q >NUL
xcopy "%~dp0cfg\*" "%GAME_L4D2%\cfg\" /E /I /H /R /Y /Q >NUL
rem Disable old SourceMod witness if present, so it cannot interfere.
if exist "%GAME%\left4dead2\addons\sourcemod\plugins\witness_core.smx" (
  if not exist "%GAME%\left4dead2\addons\sourcemod\plugins\disabled" mkdir "%GAME%\left4dead2\addons\sourcemod\plugins\disabled"
  move /Y "%GAME%\left4dead2\addons\sourcemod\plugins\witness_core.smx" "%GAME%\left4dead2\addons\sourcemod\plugins\disabled\witness_core.smx.disabled" >NUL
)
echo Installed. Launching via cfg: exec error404_lost_build_start.cfg
timeout /t 2 /nobreak >NUL
start "" "%GAME%\left4dead2.exe" -insecure -console -windowed -noborder +sv_consistency 0 +exec error404_lost_build_start.cfg
endlocal
