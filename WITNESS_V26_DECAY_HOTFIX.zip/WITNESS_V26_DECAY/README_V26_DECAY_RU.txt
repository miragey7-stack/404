WITNESS V26: DECAY
Haunted Cartridge / Analog Horror layer for Left 4 Dead 2: No Mercy

Идея:
Это не обычный мод, а цифровой психологический хоррор. Кампания начинается почти как обычная No Mercy, но игра постепенно "замечает" игрока, стирает союзников и зараженных, затем превращается в проклятый билд.

Что добавлено в V26:
- Gradual Decay: постепенная прогрессия по главам No Mercy.
- c8m1: иллюзия обычной кампании, первые странные признаки.
- c8m2+: постановочная изоляция игрока.
- Survivor-боты перед исчезновением замирают, чернеют и поворачиваются к игроку.
- Director останавливается, common infected и witch удаляются.
- SCP-173 сталкер: если смотреть — замирает, замедляет время и сжимает FOV; если отвернуться — приближается.
- Удары сталкера не убивают, а дают скример, визг, ломают фонарик и отбрасывают игрока.
- Черные T-pose survivors появляются как наблюдатели, смотрят на игрока и исчезают при приближении.
- Weapon jam: на поздних стадиях оружие иногда клинит, вместо выстрела слышен сухой щелчок.
- Fake UI / Meta Horror: фальшивые сообщения консоли, сервера и ошибок движка.
- Safe Room Trap: убежище больше не безопасно, свет гаснет, вокруг появляются сущности, бьет скример.
- Staged Void Finale: на финале игрок лишается оружия, телепортируется в пустоту, вокруг мертвые survivor-модели, затем финальный скример и exit.

Установка:
1. Распакуй архив.
2. Запусти INSTALL_V26_DECAY.bat или INSTALL_V26.bat.
3. Установщик найдет Left 4 Dead 2, скопирует файлы, попытается скачать официальный SourceMod compiler/runtime, скомпилирует witness_core.sp в witness_core.smx и запустит No Mercy.

Важно:
- Финальный exit оставлен специально. Это часть fake crash / haunted cartridge финала.
- Установщик НЕ удаляет чужие плагины.
- Установщик может скачать SourceMod 1.12 compiler/runtime с GitHub, если spcomp.exe не найден.
- Если автоматическая компиляция не прошла, вручную скомпилируй:
  addons/sourcemod/scripting/witness_core.sp
  в:
  addons/sourcemod/plugins/witness_core.smx

ConVars:
- witness_enable 1/0
- witness_nomercy_only 1/0
- witness_debug 1/0
- witness_finale_exit 1/0

Рекомендуемый режим:
- Локально / singleplayer / coop.
- No Mercy.
- Запуск через -insecure, как делает установщик.

Hotfix 26.1:
- Исправлена ошибка SourceMod: Invalid timer handle / KillTimer в OnPluginEnd.
- Главные повторяющиеся таймеры больше не создаются как TIMER_FLAG_NO_MAPCHANGE.
- Установщик переносит несовместимый nextmap.smx в plugins/disabled, чтобы он не спамил errors.log.
- Установщик переносит updater.smx в plugins/disabled, чтобы offline/local запуск не спамил ошибками updater.

Версия:
WITNESS V26 DECAY, source version 26.1.0-decay-hotfix.
