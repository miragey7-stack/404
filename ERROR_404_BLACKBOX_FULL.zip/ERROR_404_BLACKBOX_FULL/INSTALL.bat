@echo off
call "%~dp0INSTALL_ERROR404_FULL.bat"
