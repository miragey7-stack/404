@echo off
setlocal EnableExtensions EnableDelayedExpansion
color 0C
title ERROR 404 BLACKBOX FULL Installer

set "GAME="
if exist "D:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=D:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "E:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=E:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME set /p "GAME=Paste the folder containing left4dead2.exe: "
set "GAME=%GAME:"=%"
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%"

if not exist "%GAME%\left4dead2.exe" (
    echo ERROR: left4dead2.exe was not found.
    pause
    exit /b 1
)

set "SRC=%~dp0ERROR404_FILES"
set "DST=%GAME%\left4dead2"

echo.
echo ============================================================
echo  ERROR 404: BLACKBOX FULL
echo  VScript mutation. Inspired by Alone mechanics.
echo ============================================================
echo Installing to: %DST%
echo.

xcopy "%SRC%\*" "%DST%\" /E /I /H /R /Y /Q >NUL

rem Disable older SourceMod ERROR404/WITNESS plugins so they do not run on top of BLACKBOX.
if exist "%DST%\addons\sourcemod\plugins" (
    if not exist "%DST%\addons\sourcemod\plugins\disabled" mkdir "%DST%\addons\sourcemod\plugins\disabled"
    if exist "%DST%\addons\sourcemod\plugins\witness_core.smx" move /Y "%DST%\addons\sourcemod\plugins\witness_core.smx" "%DST%\addons\sourcemod\plugins\disabled\witness_core.smx.disabled" >NUL
    if exist "%DST%\addons\sourcemod\plugins\nextmap.smx" move /Y "%DST%\addons\sourcemod\plugins\nextmap.smx" "%DST%\addons\sourcemod\plugins\disabled\nextmap.smx.disabled" >NUL
    if exist "%DST%\addons\sourcemod\plugins\updater.smx" move /Y "%DST%\addons\sourcemod\plugins\updater.smx" "%DST%\addons\sourcemod\plugins\disabled\updater.smx.disabled" >NUL
)

echo Installed.
echo Launching: map c8m1_apartment error404
timeout /t 2 /nobreak >NUL
start "" "%GAME%\left4dead2.exe" -insecure -console -windowed -noborder +sv_consistency 0 +map c8m1_apartment error404
endlocal
