ERROR 404: BLACKBOX MODE

Это новая архитектура проекта на основе механик Alone:
- mutation/mode вместо SourceMod-спама;
- VScript director error404.nut;
- MemoryTable/BlackboxMemory;
- DelayFunc/client_command/AudioCommand;
- TV contact points;
- safe room ritual;
- finale/void;
- sparse map fracture вместо постоянного рандома.

Установка:
1. Распакуй архив.
2. Запусти INSTALL_ERROR404_MODE.bat или INSTALL.bat.
3. Игра стартует командой:
   mp_gamemode error404
map c8m1_apartment

Ручной запуск:
mp_gamemode error404
map c8m1_apartment

Что внутри:
ERROR404_FILES/modes/error404.txt
ERROR404_FILES/scripts/vscripts/error404.nut
ERROR404_FILES/models/props_interiors/tv.*
ERROR404_FILES/materials/models/props_interiors/tv*.*
ERROR404_FILES/scripts/melee/baseball_bat.txt
ERROR404_FILES/models/weapons/melee/v_bat.* / w_bat.*
ERROR404_FILES/materials/weapons/fists/*

Что взято из разобранной сборки:
- TV-модель и TV-материалы из Psychological Horror Single Player Mode.
- Fists/baseball_bat replacement из Alone First.

Концепция:
Не спамить. Строить сцены:
- c8m1: BLACKBOX boot + checksum mismatch + первый наблюдатель.
- c8m2: isolation + NEXT TRAIN: NEVER.
- c8m3: water memory.
- c8m4: PATIENT: YOU.
- c8m5: rescue entity missing + NO EXIT.

Важно:
Это первая VScript/mutation-версия. Если скрипт выдаст ошибку в консоли, пришли строку с SCRIPT ERROR / AN ERROR HAS OCCURRED и номер строки.


Hotfix 0.1.1:
- Установщик теперь запускает режим через +mp_gamemode error404 +map c8m1_apartment.
- В addoninfo добавлен addonContent_Script 1.
- Если после запуска в консоли нет "ERROR 404: BLACKBOX script loaded", введи вручную:
  mp_gamemode error404
  map c8m1_apartment
