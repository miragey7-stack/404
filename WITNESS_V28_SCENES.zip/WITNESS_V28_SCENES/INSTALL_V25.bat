@echo off
call "%~dp0INSTALL_V28_SCENES.bat"
