ERROR 404: WITNESS V28 SCENES
Haunted Cartridge / Creepypasta сборка для Left 4 Dead 2: No Mercy

V28 сделана по результатам теста V27:
- стало больше жутких звуков;
- стало больше экранных horror-кадров через overlay VMT;
- ведьма больше не просто преследует: у нее появились специальные действия;
- сломанные survivor-модели больше НЕ скейлятся агрессивно, чтобы не взлетали штаны/части одежды;
- вместо комичного bodygroup-багования теперь используются силуэты, controlled twitch, face overlays, звуки костей и постановочные сцены;
- карта активнее ведет себя как живая: предметы бросаются, props дергаются, свет/материалы дают ERROR 404 сбои.

Новые звуки V28:
- breath_behind.wav
- distant_knock.wav
- metal_drag.wav
- reverse_whisper_01.wav
- bone_crack.wav
- deep_glitch_hit.wav
- old_radio_click.wav
- witch_breath.wav
- entity_presence.wav
- map_hand.wav

Новые overlay-кадры V28:
- witness_v28/face_01
- witness_v28/face_red
- witness_v28/face_blue
- witness_v28/eyes_static
- witness_v28/old_build_noise
- witness_v28/missing_texture_flash
- witness_v28/404_frame
- witness_v28/void_frame
- witness_v28/corrupt_hud

Важно про изображения:
Это VMT-слои поверх существующих VTF из V25, с разной цветовой обработкой. Для полноценных новых лиц нужны настоящие VTF, но в этой сборке уже добавлен набор разных horror-кадров без необходимости внешнего VTF-компилятора.

Новые постановочные сцены:
- SceneBehind: игра реагирует на частые оборачивания, дыхание за спиной и короткий horror-frame.
- SceneOldBuild: имитация загрузки старой таблицы материалов.
- SceneMapHand: предметы рядом подбрасываются, будто карту трогает невидимая рука.
- SceneWrongSurvivor: фальшивый Bill/выживший впереди, затем лицо и bone crack.
- ScenePhotoFlash: вставленный неизвестным клиентом horror-frame.
- SceneDoorKnock: стук за дверью и предупреждение.
- SceneTexture404: flash missing texture / material replacement.
- SceneCeilingBody: силуэт выжившего появляется над игроком, как подвешенное тело.

Ведьма / WITNESS теперь умеет:
- смотреть в ответ, если игрок слишком долго смотрит;
- вызывать face overlay и дыхание;
- трогать карту / бросать предметы;
- спавнить hallucination за спиной;
- резко менять позицию с radio click;
- наказывать stare так же, как и отворачивание.

Почему конечности не скейлятся по костям:
SourcePawn без отдельного model/animation pipeline не умеет безопасно удлинять отдельные руки/ноги survivor-моделей. В V27 попытка имитировать это масштабом/sequence приводила к визуальному багу одежды — например, штаны улетали вверх. В V28 это исправлено: survivor horror сделан как силуэтный/постановочный, а не через поломку bodygroups.

Установка:
1. Распакуй архив.
2. Запусти INSTALL_V28_SCENES.bat или INSTALL_V28.bat.
3. Установщик скопирует файлы, отключит nextmap/updater, скачает SourceMod compiler/runtime при необходимости, скомпилирует witness_core.sp и запустит No Mercy.

Проверка в консоли игры:
sm plugins list
sm plugins info witness_core

Должно быть:
ERROR 404: WITNESS V28 SCENES
28.0.0-error404-scenes

ConVars:
- witness_enable 1/0
- witness_nomercy_only 1/0
- witness_debug 1/0
- witness_finale_exit 1/0

Финальный exit сохранен как часть fake crash.
