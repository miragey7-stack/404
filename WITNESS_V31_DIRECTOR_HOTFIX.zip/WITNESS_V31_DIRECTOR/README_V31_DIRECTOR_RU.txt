ERROR 404: WITNESS V31.1 DIRECTOR

Главная идея V31: не спам, а режиссура.
- Добавлены map-specific сцены для c8m1-c8m5.
- Добавлена более сильная, но контролируемая поломка карты: physics props бросаются серией, двери рядом могут открываться/закрываться, props дергаются.
- По умолчанию witness_intensity = 2, чтобы не раздражать как V29.
- Для голосов добавлены MP3 в sound/music/witness_v31; если MP3 не подцепятся, есть stock fallback.
- Custom WAV больше не используются напрямую.

Новые сцены:
- c8m1: сигнал/фигура за пределами квартиры.
- c8m2: поезд/тоннель смотрит на игрока.
- c8m3: вода/трубы хранят голоса выживших.
- c8m4: PATIENT: YOU.
- c8m5: rescue entity missing / helicopter path null.

Проверка:
sm plugins info witness_core
Ожидаемо: ERROR 404: WITNESS V31.1 DIRECTOR / 31.1.0-loadfix


Hotfix 31.1:
- installer больше не удаляет старый witness_core.smx до успешной компиляции.
- compile log показывается сразу, если spcomp не смог собрать .sp.
- упрощена функция дверей, чтобы убрать риск ошибки компиляции.
Если после установки в консоли нет строки ERROR 404 / WITNESS V31.1 DIRECTOR loaded — плагин не загрузился/не скомпилировался.
