@echo off
call "%~dp0INSTALL_V31_DIRECTOR.bat"
