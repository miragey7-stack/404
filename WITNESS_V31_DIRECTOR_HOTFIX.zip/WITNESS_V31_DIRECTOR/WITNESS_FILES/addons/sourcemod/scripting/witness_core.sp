#pragma semicolon 1
#pragma newdecls required

#include <sourcemod>
#include <sdktools>
#include <sdkhooks>

#define PLUGIN_VERSION "31.1.0-loadfix"
#define INVALID_FLAGS -1
#define IN_ATTACK_BIT (1 << 0)

static const char SURV_MODELS[][] = {
    "models/survivors/survivor_namvet.mdl",
    "models/survivors/survivor_biker.mdl",
    "models/survivors/survivor_teenangst.mdl",
    "models/survivors/survivor_manager.mdl",
    "models/survivors/survivor_coach.mdl",
    "models/survivors/survivor_gambler.mdl"
};

enum Phase {
    P_Init = 0,
    P_Normal,
    P_Observed,
    P_Isolation,
    P_Decay,
    P_SafeRoomTrap,
    P_Void
};

public Plugin myinfo = {
    name = "ERROR 404: WITNESS V31.1 DIRECTOR",
    author = "NELIXO concept, Arena.ai implementation",
    description = "Map-specific ERROR 404 horror director with stronger controlled map corruption",
    version = PLUGIN_VERSION
};

Phase g_Phase = P_Init;
bool g_bActive = false;
bool g_bDirectorStopped = false;
bool g_bSafeRoomTrap = false;
bool g_bIsolationDone = false;
bool g_bEngineCaptured = false;

int g_iDecay = 0;
int g_iChapter = 1;
int g_iWitchRef = INVALID_ENT_REFERENCE;
char g_sMap[64];
float g_fSpawnOrigin[MAXPLAYERS + 1][3];
float g_fNextGlitch = 0.0;
float g_fNextHallucination = 0.0;
float g_fNextStalkerMove = 0.0;
float g_fNextFakeUi = 0.0;
float g_fNextAttackSound = 0.0;

bool g_bJammed[MAXPLAYERS + 1];
float g_fJamEnd[MAXPLAYERS + 1];
float g_fNextJamTry[MAXPLAYERS + 1];
float g_fNextDryClick[MAXPLAYERS + 1];

int g_iEntityAwareness = 0;
int g_iLookBackCount[MAXPLAYERS + 1];
int g_iShotsFired[MAXPLAYERS + 1];
float g_fLastPos[MAXPLAYERS + 1][3];
float g_fIdleSince[MAXPLAYERS + 1];
float g_fNextWorldCorrupt = 0.0;
float g_fNextEntityVoice = 0.0;
float g_fNextPropThrow = 0.0;
float g_fNextTextureRot = 0.0;
bool g_bWitnessJoined = false;
float g_fNextScene = 0.0;
float g_fNextWitchAction = 0.0;
float g_fNextBehind = 0.0;
float g_fNextOldBuildScene = 0.0;
float g_fNextHeartbeat = 0.0;
float g_fNextHardEvent = 0.0;
int g_iLastScene = -1;
bool g_bMapSceneDone[8];
float g_fNextDirectorScene = 0.0;
float g_fNextMapFracture = 0.0;

ConVar g_cvEnable;
ConVar g_cvNoMercyOnly;
ConVar g_cvDebug;
ConVar g_cvExitFinale;
ConVar g_cvIntensity;
ConVar g_cvTimeScale;
ConVar g_cvGravity;
ConVar g_cvGameMode;

float g_fOldTimeScale = 1.0;
float g_fOldGravity = 800.0;
int g_iOldTimeScaleFlags = INVALID_FLAGS;
int g_iOldGravityFlags = INVALID_FLAGS;
int g_iOldOverlayFlags = INVALID_FLAGS;

Handle g_hMainTimer = null;
Handle g_hPurgeTimer = null;
ArrayList g_hSpawnedRefs = null;

public void OnPluginStart() {
    g_cvEnable = CreateConVar("witness_enable", "1", "Enable ERROR 404 WITNESS V31 DIRECTOR.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    g_cvNoMercyOnly = CreateConVar("witness_nomercy_only", "1", "Only run on No Mercy c8m*.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    g_cvDebug = CreateConVar("witness_debug", "0", "Debug logging.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    g_cvExitFinale = CreateConVar("witness_finale_exit", "1", "Final fake crash: send client exit command.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    g_cvIntensity = CreateConVar("witness_intensity", "2", "Haunting intensity: 1 quiet, 2 slow-burn, 3 intense, 4 aggressive.", FCVAR_NOTIFY, true, 1.0, true, 4.0);
    AutoExecConfig(true, "witness_v31_director");

    HookEvent("round_start", Event_RoundStart, EventHookMode_PostNoCopy);
    HookEvent("player_spawn", Event_PlayerSpawn, EventHookMode_Post);
    HookEvent("door_close", Event_DoorClose, EventHookMode_Post);
    HookEvent("weapon_fire", Event_WeaponFire, EventHookMode_Post);
    HookEntityOutput("func_button", "OnPressed", OnButtonPressed);

    g_cvTimeScale = FindConVar("host_timescale");
    g_cvGravity = FindConVar("sv_gravity");
    g_cvGameMode = FindConVar("mp_gamemode");

    CaptureEngineState();
    RelaxCheatFlags();

    g_hSpawnedRefs = new ArrayList();
    // Repeating core timers are intentionally not TIMER_FLAG_NO_MAPCHANGE.
    // SourceMod can auto-kill NO_MAPCHANGE timers during transitions, leaving stored handles invalid.
    g_hMainTimer = CreateTimer(0.20, Timer_MainLoop, _, TIMER_REPEAT);
    g_hPurgeTimer = CreateTimer(0.50, Timer_PurgeWorld, _, TIMER_REPEAT);

    LogMessage("ERROR 404 / WITNESS V31.1 DIRECTOR loaded.");
}

public void OnPluginEnd() {
    g_bActive = false;
    // Do not KillTimer() here: on game shutdown/map transitions SM may have already invalidated them.
    // Plugin unload closes owned handles anyway; calling KillTimer on a stale handle caused error 23.
    g_hMainTimer = null;
    g_hPurgeTimer = null;
    CleanupSpawnedEntities();
    ResetEngine(true);
    if (g_hSpawnedRefs != null) { delete g_hSpawnedRefs; g_hSpawnedRefs = null; }
}

public void OnMapStart() {
    GetCurrentMap(g_sMap, sizeof(g_sMap));
    g_iChapter = ParseChapter(g_sMap);
    g_iDecay = GetBaseDecayForChapter(g_iChapter);
    g_Phase = P_Init;
    g_bActive = ShouldRun();
    g_bSafeRoomTrap = false;
    g_bIsolationDone = false;
    g_iWitchRef = INVALID_ENT_REFERENCE;
    g_fNextGlitch = 0.0;
    g_fNextHallucination = 0.0;
    g_fNextFakeUi = 0.0;
    g_fNextStalkerMove = 0.0;
    g_fNextWorldCorrupt = 0.0;
    g_fNextEntityVoice = 0.0;
    g_fNextPropThrow = 0.0;
    g_fNextTextureRot = 0.0;
    g_iEntityAwareness = g_iDecay;
    g_bWitnessJoined = false;
    g_fNextScene = 0.0;
    g_fNextWitchAction = 0.0;
    g_fNextBehind = 0.0;
    g_fNextOldBuildScene = 0.0;
    g_fNextHeartbeat = 0.0;
    g_fNextHardEvent = 0.0;
    g_iLastScene = -1;
    g_fNextDirectorScene = 0.0;
    g_fNextMapFracture = 0.0;
    for (int i = 0; i < sizeof(g_bMapSceneDone); i++) g_bMapSceneDone[i] = false;

    PrecacheAll();

    if (g_bActive) {
        ResetEngine(false);
        Debug("Active on %s, chapter=%d, base_decay=%d", g_sMap, g_iChapter, g_iDecay);
    }
}

public void OnMapEnd() {
    g_bActive = false;
    CleanupSpawnedEntities();
    ResetEngine(false);
}

public void OnClientPutInServer(int client) {
    SDKHook(client, SDKHook_OnTakeDamage, OnTakeDamage);
}

public Action OnTakeDamage(int victim, int &attacker, int &inflictor, float &damage, int &damagetype) {
    if (g_bActive && g_Phase >= P_Isolation && IsValidSurvivor(victim) && (damagetype & DMG_FALL)) {
        damage = 0.0;
        return Plugin_Handled;
    }
    return Plugin_Continue;
}

public Action OnPlayerRunCmd(int client, int &buttons, int &impulse, float vel[3], float angles[3], int &weapon, int &subtype, int &cmdnum, int &tickcount, int &seed, int mouse[2]) {
    if (!g_bActive || g_Phase < P_Decay || !IsValidSurvivor(client) || IsFakeClient(client)) {
        return Plugin_Continue;
    }

    float now = GetGameTime();
    if (g_bJammed[client]) {
        if (now < g_fJamEnd[client]) {
            buttons &= ~IN_ATTACK_BIT;
            if (now > g_fNextDryClick[client]) {
                EmitSoundToClient(client, "weapons/clipempty_rifle.wav", SOUND_FROM_PLAYER, SNDCHAN_WEAPON, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 70);
                g_fNextDryClick[client] = now + 0.22;
            }
            return Plugin_Changed;
        }
        g_bJammed[client] = false;
    }

    if ((buttons & IN_ATTACK_BIT) && now > g_fNextJamTry[client]) {
        g_fNextJamTry[client] = now + GetRandomFloat(6.0, 14.0);
        int chance = 7 + (g_iDecay * 4);
        if (GetRandomInt(1, 100) <= chance) {
            g_bJammed[client] = true;
            g_fJamEnd[client] = now + GetRandomFloat(0.65, 1.25);
            g_fNextDryClick[client] = 0.0;
            buttons &= ~IN_ATTACK_BIT;
            ShowOverlay(client, "witness_v25/tv_noise", 0.25);
            PrintHintText(client, "WEAPON_INTERFACE_FAILURE");
            return Plugin_Changed;
        }
    }

    return Plugin_Continue;
}

public void Event_RoundStart(Event event, const char[] name, bool dontBroadcast) {
    g_bActive = ShouldRun();
    g_Phase = P_Init;
    g_bSafeRoomTrap = false;
    g_bIsolationDone = false;
    CleanupSpawnedEntities();
    ResetEngine(false);
}

public void Event_PlayerSpawn(Event event, const char[] name, bool dontBroadcast) {
    if (!g_bActive) return;

    int client = GetClientOfUserId(event.GetInt("userid"));
    if (!IsValidSurvivor(client) || IsFakeClient(client)) return;

    GetClientAbsOrigin(client, g_fSpawnOrigin[client]);

    if (g_Phase == P_Init) {
        g_Phase = P_Normal;
        if (g_iChapter == 1) {
            CreateTimer(12.0, Timer_IllusionWhisper, GetClientUserId(client), TIMER_FLAG_NO_MAPCHANGE);
        } else {
            CreateTimer(2.0, Timer_BeginIsolation, GetClientUserId(client), TIMER_FLAG_NO_MAPCHANGE);
        }
    }
}

public void Event_WeaponFire(Event event, const char[] name, bool dontBroadcast) {
    if (!g_bActive || g_Phase < P_Decay) return;

    int client = GetClientOfUserId(event.GetInt("userid"));
    if (IsValidSurvivor(client) && !IsFakeClient(client)) {
        g_iShotsFired[client]++;
        if (g_iShotsFired[client] % 18 == 0 && g_iEntityAwareness < 9) g_iEntityAwareness++;
    }
    if (IsValidSurvivor(client) && !IsFakeClient(client) && GetRandomInt(1, 100) <= (2 + g_iDecay)) {
        PlayHorrorSound(client, "music/witness_v25/static_burst.wav", 0.55);
    }
}

public void Event_DoorClose(Event event, const char[] name, bool dontBroadcast) {
    if (!g_bActive || g_Phase < P_Isolation || g_bSafeRoomTrap || !event.GetBool("checkpoint") || g_iChapter >= 5) return;
    int p = GetPrimaryPlayer();
    if (p <= 0) return;

    g_bSafeRoomTrap = true;
    g_Phase = P_SafeRoomTrap;
    StartSafeRoomTrap(p);
}

public void OnButtonPressed(const char[] output, int caller, int activator, float delay) {
    if (!g_bActive || g_Phase == P_Void || !IsValidSurvivor(activator) || IsFakeClient(activator)) return;
    if (ShouldButtonTriggerVoid(caller)) {
        TriggerVoid(activator);
    }
}

public void OnEntityCreated(int entity, const char[] classname) {
    if (!g_bActive || g_Phase < P_Isolation) return;
    if (StrEqual(classname, "infected") || StrEqual(classname, "witch")) {
        RequestFrame(Frame_RemoveEntity, EntIndexToEntRef(entity));
    }
}

public void Frame_RemoveEntity(any ref) {
    int ent = EntRefToEntIndex(ref);
    if (ent > MaxClients && IsValidEntity(ent)) RemoveEntity(ent);
}

public Action Timer_MainLoop(Handle timer) {
    if (!g_bActive) return Plugin_Continue;

    float now = GetGameTime();
    int p = GetPrimaryPlayer();
    if (p <= 0) return Plugin_Continue;

    if (g_Phase == P_Normal) {
        UpdateIllusion(p, now);
    } else if (g_Phase == P_Observed || g_Phase == P_Isolation || g_Phase == P_Decay || g_Phase == P_SafeRoomTrap) {
        if (g_Phase != P_SafeRoomTrap) g_Phase = P_Decay;
        UpdateStalker(p, now);
        UpdateDecayGlitches(p, now);
        UpdateHallucinations(p, now);
        UpdateFakeUi(p, now);
        UpdateEntityMemory(p, now);
        UpdateWorldCorruption(p, now);
        UpdateEntityVoice(p, now);
        UpdateCinematicScenes(p, now);
        UpdateDirectorScenes(p, now);
        UpdateAggressiveAudio(p, now);
        UpdateTrackedWatchers(p);
    } else if (g_Phase == P_Void) {
        float a[3]; GetClientEyeAngles(p, a); a[2] += 0.65; TeleportEntity(p, NULL_VECTOR, a, NULL_VECTOR);
        PrintCenterText(p, "Y O U   C A N N O T   E X I T");
        UpdateTrackedWatchers(p);
    }

    return Plugin_Continue;
}

public Action Timer_PurgeWorld(Handle timer) {
    if (!g_bActive || g_Phase < P_Isolation) return Plugin_Continue;

    int ent = -1;
    while ((ent = FindEntityByClassname(ent, "infected")) != -1) {
        if (ent > MaxClients && IsValidEntity(ent)) RemoveEntity(ent);
    }
    ent = -1;
    while ((ent = FindEntityByClassname(ent, "witch")) != -1) {
        if (ent > MaxClients && IsValidEntity(ent)) RemoveEntity(ent);
    }
    for (int i = 1; i <= MaxClients; i++) {
        if (IsClientInGame(i) && IsFakeClient(i) && GetClientTeam(i) == 3 && IsPlayerAlive(i)) ForcePlayerSuicide(i);
    }
    return Plugin_Continue;
}

void UpdateIllusion(int p, float now) {
    float pos[3]; GetClientAbsOrigin(p, pos);
    if (GetVectorDistance(g_fSpawnOrigin[p], pos) > 900.0 && g_Phase == P_Normal) {
        g_Phase = P_Observed;
        g_iDecay = 1;
        PlayHorrorSound(p, "music/witness_v25/static_burst.wav", 0.70);
        PrintHintText(p, "...");
        SpawnHallucination(p, 900.0, 2.0, true);
    }
    if (GetVectorDistance(g_fSpawnOrigin[p], pos) > 1700.0 && !g_bIsolationDone) {
        BeginIsolation(p);
    }
}

public Action Timer_IllusionWhisper(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (g_bActive && IsValidSurvivor(p) && g_Phase == P_Normal) {
        PrintToChat(p, "\x01[Console] missing survivor memory segment: 0x404");
        PlayHorrorSound(p, "music/witness_v25/static_burst.wav", 0.55);
    }
    return Plugin_Stop;
}

public Action Timer_BeginIsolation(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (g_bActive && IsValidSurvivor(p) && !g_bIsolationDone) BeginIsolation(p);
    return Plugin_Stop;
}

void BeginIsolation(int p) {
    if (g_bIsolationDone || !IsValidSurvivor(p)) return;
    g_bIsolationDone = true;
    g_Phase = P_Isolation;
    if (g_iDecay < 2) g_iDecay = 2;
    if (g_iEntityAwareness < 3) g_iEntityAwareness = 3;

    StopDirector();
    SetDarkness();
    ShowOverlay(p, "witness_v25/tv_noise", 0.65);
    FadeClient(p, 0, 0, 0, 220, 200, 1200, 0x0001);
    PlayHorrorSound(p, "music/witness_v25/static_burst.wav", 1.0);
    PrintCenterText(p, "IT NOTICED YOU");
    PlayVoiceMP3(p, "music/witness_v31/not_alone.mp3", 0.85);
    PlayHorrorSound(p, "music/witness_v28/entity_presence.wav", 1.0);

    StageBotsForDeletion(p);
    CreateTimer(0.85, Timer_DeleteSurvivorBots, _, TIMER_FLAG_NO_MAPCHANGE);
    CreateTimer(1.25, Timer_PostIsolation, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
}

public Action Timer_PostIsolation(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (g_bActive && IsValidSurvivor(p)) {
        PrintToChat(p, "\x01Bill has left the game");
        PrintToChat(p, "\x01Zoey has left the game");
        PrintToChat(p, "\x01Francis has left the game");
        PrintToChat(p, "\x04YOU ARE ALONE");
        SpawnStalker(p);
        g_Phase = P_Decay;
        g_fNextGlitch = GetGameTime() + 4.0;
        g_fNextHallucination = GetGameTime() + 7.0;
        g_fNextFakeUi = GetGameTime() + 18.0;
    }
    return Plugin_Stop;
}

void StageBotsForDeletion(int p) {
    float ppos[3]; GetClientAbsOrigin(p, ppos);
    for (int i = 1; i <= MaxClients; i++) {
        if (!IsClientInGame(i) || !IsFakeClient(i) || GetClientTeam(i) != 2 || !IsPlayerAlive(i)) continue;
        SetEntityMoveType(i, MOVETYPE_NONE);
        float bpos[3], dir[3], ang[3]; GetClientAbsOrigin(i, bpos); MakeVectorFromPoints(bpos, ppos, dir); GetVectorAngles(dir, ang); ang[0]=0.0; ang[2]=0.0;
        TeleportEntity(i, NULL_VECTOR, ang, NULL_VECTOR);
        SetEntityRenderMode(i, RENDER_TRANSCOLOR);
        SetEntityRenderColor(i, 0, 0, 0, 255);
    }
}

public Action Timer_DeleteSurvivorBots(Handle timer) {
    for (int i = 1; i <= MaxClients; i++) {
        if (IsClientInGame(i) && IsFakeClient(i) && GetClientTeam(i) == 2) KickClient(i, "memory erased");
    }
    return Plugin_Stop;
}

void UpdateStalker(int p, float now) {
    int stalker = EntRefToEntIndex(g_iWitchRef);
    if (stalker == INVALID_ENT_REFERENCE || !IsValidEntity(stalker)) {
        SpawnStalker(p);
        return;
    }

    float wpos[3], ppos[3], dir[3], ang[3];
    GetEntPropVector(stalker, Prop_Data, "m_vecAbsOrigin", wpos);
    GetClientAbsOrigin(p, ppos);
    MakeVectorFromPoints(wpos, ppos, dir); dir[2] = 0.0; NormalizeVector(dir, dir); GetVectorAngles(dir, ang); ang[0] = 0.0; ang[2] = 0.0;
    TeleportEntity(stalker, NULL_VECTOR, ang, NULL_VECTOR);

    bool looking = IsPlayerLookingAtPoint(p, wpos, 0.43);
    float dist = GetVectorDistance(wpos, ppos);

    if (now > g_fNextWitchAction && g_iEntityAwareness >= 4) {
        g_fNextWitchAction = now + GetRandomFloat(12.0, 24.0) - float(GetIntensity()) * 2.0;
        WitchSpecialAction(p, stalker, looking, dist);
    }

    if (looking) {
        if (g_cvTimeScale != null) g_cvTimeScale.FloatValue = 0.38 - float(g_iDecay) * 0.025;
        int fov = RoundToNearest(72.0 - float(g_iDecay * 3) + 10.0 * Sine(now * 5.5));
        if (fov < 42) fov = 42;
        SetEntProp(p, Prop_Send, "m_iDefaultFOV", fov);
        if (now > g_fNextAttackSound) {
            EmitSoundToClient(p, "ambient/energy/zap1.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 0.85, GetRandomInt(45, 70));
            g_fNextAttackSound = now + 0.8;
        }
    } else {
        RestoreLookEffect(p);
        if (now > g_fNextStalkerMove) {
            g_fNextStalkerMove = now + GetRandomFloat(1.2, 3.3) - float(g_iDecay) * 0.12;
            float radius = 420.0 - float(g_iDecay) * 45.0;
            if (radius < 115.0) radius = 115.0;
            float y = (ang[1] + 180.0 + GetRandomFloat(-55.0, 55.0)) * FLOAT_PI / 180.0;
            float np[3]; np[0] = ppos[0] + Cosine(y) * radius; np[1] = ppos[1] + Sine(y) * radius; np[2] = ppos[2] + 10.0;
            TeleportEntity(stalker, np, NULL_VECTOR, NULL_VECTOR);
            SetEntProp(stalker, Prop_Data, "m_nSequence", 6);
            SetEntPropFloat(stalker, Prop_Send, "m_flPlaybackRate", 1.5);
            if (GetRandomInt(0, 1) == 0) EmitSoundToClient(p, "ambient/atmosphere/cave_hit5.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 0.8, 55);
        }
    }

    if (dist < 85.0) StalkerStrike(p, stalker, dir);
}

void SpawnStalker(int p) {
    float ppos[3], pang[3]; GetClientAbsOrigin(p, ppos); GetClientEyeAngles(p, pang);
    float yaw = (pang[1] + 180.0) * FLOAT_PI / 180.0;
    float spos[3]; spos[0] = ppos[0] + Cosine(yaw) * 700.0; spos[1] = ppos[1] + Sine(yaw) * 700.0; spos[2] = ppos[2] + 10.0;

    int e = CreateEntityByName("prop_dynamic_override");
    if (e == -1) return;
    DispatchKeyValue(e, "model", "models/infected/witch.mdl");
    DispatchKeyValue(e, "targetname", "witness_stalker_v26");
    DispatchKeyValue(e, "solid", "0");
    DispatchSpawn(e);
    TrackEntity(e);

    float d[3], a[3]; MakeVectorFromPoints(spos, ppos, d); GetVectorAngles(d, a); a[0] = 0.0; a[2] = 0.0;
    TeleportEntity(e, spos, a, NULL_VECTOR);
    SetEntityRenderMode(e, RENDER_TRANSCOLOR);
    SetEntityRenderColor(e, 0, 0, 0, 255);
    SetEntProp(e, Prop_Data, "m_nSequence", 4);
    g_iWitchRef = EntIndexToEntRef(e);
}

void StalkerStrike(int p, int stalker, float dir[3]) {
    PlayHorrorSound(p, "music/witness_v25/screamer.wav", 1.0);
    ShowOverlay(p, "witness_v25/scream_face", 0.85);
    ScreenShake(p, 45.0, 35.0, 2.5);
    FadeClient(p, 255, 0, 0, 210, 120, 500, 0x0001);

    float vel[3]; vel[0] = dir[0] * 1450.0; vel[1] = dir[1] * 1450.0; vel[2] = 360.0;
    TeleportEntity(p, NULL_VECTOR, NULL_VECTOR, vel);

    int effects = GetEntProp(p, Prop_Send, "m_fEffects");
    if (effects & 4) SetEntProp(p, Prop_Send, "m_fEffects", effects & ~4);

    RemoveEntity(stalker);
    g_iWitchRef = INVALID_ENT_REFERENCE;
    g_fNextStalkerMove = GetGameTime() + 9.0;
    if (g_iDecay < 5) g_iDecay++;
    if (g_iEntityAwareness < 10) g_iEntityAwareness += 2;
}

void UpdateDecayGlitches(int p, float now) {
    if (now <= g_fNextGlitch) return;
    g_fNextGlitch = now + GetRandomFloat(2.2, 6.5) - float(g_iDecay) * 0.25 - float(GetIntensity());

    int roll = GetRandomInt(0, 5);
    if (roll == 0) {
        float a[3]; GetClientEyeAngles(p, a); a[2] = GetRandomFloat(-40.0, 40.0); TeleportEntity(p, NULL_VECTOR, a, NULL_VECTOR);
        CreateTimer(2.2, Timer_RestoreRoll, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    } else if (roll == 1) {
        ShowOverlay(p, "witness_v25/tv_noise", GetRandomFloat(0.25, 0.8));
    } else if (roll == 2 && g_cvGravity != null) {
        g_cvGravity.FloatValue = GetRandomFloat(160.0, 360.0);
        CreateTimer(3.0, Timer_RestoreGravity, _, TIMER_FLAG_NO_MAPCHANGE);
    } else if (roll == 3) {
        PrintHintText(p, "ERROR 404: DIRECTOR NOT FOUND");
    } else if (roll == 4) {
        PlayHorrorSound(p, "music/witness_v25/static_burst.wav", 1.0);
    } else {
        SpawnHallucination(p, GetRandomFloat(280.0, 650.0), GetRandomFloat(3.5, 8.0), false);
    }
}

void UpdateHallucinations(int p, float now) {
    if (now <= g_fNextHallucination) return;
    g_fNextHallucination = now + GetRandomFloat(3.5, 9.0) - float(g_iDecay) * 0.35 - float(GetIntensity()) * 0.6;
    SpawnHallucination(p, GetRandomFloat(220.0, 720.0), GetRandomFloat(4.0, 9.0), false);
}

void UpdateFakeUi(int p, float now) {
    if (now <= g_fNextFakeUi) return;
    g_fNextFakeUi = now + GetRandomFloat(32.0, 62.0) - float(GetIntensity()) * 3.0;
    int r = GetRandomInt(0, 5);
    if (r == 0) PrintToChat(p, "\x01[Console] CBaseEntity::SetModel: corrupted survivor pointer");
    else if (r == 1) PrintToChat(p, "\x01[ERROR 404] connection to survivor memory timed out");
    else if (r == 2) PrintHintText(p, "do not turn around");
    else if (r == 3) PrintCenterText(p, "IT IS LEARNING YOUR ROUTE");
    else if (r == 4) PrintToChat(p, "\x04%s has joined the game", "WITNESS");
    else PrintToChat(p, "\x01[SM] Native 'GetClientAbsOrigin' reported: client is not alone");
}

void SpawnHallucination(int p, float distance, float lifetime, bool inFront) {
    float ppos[3], pang[3]; GetClientAbsOrigin(p, ppos); GetClientEyeAngles(p, pang);
    float yawDeg = pang[1] + (inFront ? GetRandomFloat(-22.0, 22.0) : GetRandomFloat(-150.0, 150.0));
    float y = yawDeg * FLOAT_PI / 180.0;
    float pos[3]; pos[0] = ppos[0] + Cosine(y) * distance; pos[1] = ppos[1] + Sine(y) * distance; pos[2] = ppos[2] + 5.0;

    int e = CreateEntityByName("prop_dynamic_override");
    if (e == -1) return;
    DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS) - 1)]);
    DispatchKeyValue(e, "targetname", "witness_watcher_v26");
    DispatchKeyValue(e, "solid", "0");
    DispatchSpawn(e);
    TrackEntity(e);

    float a[3], d[3]; MakeVectorFromPoints(pos, ppos, d); GetVectorAngles(d, a); a[0]=0.0; a[2]=0.0;
    TeleportEntity(e, pos, a, NULL_VECTOR);
    SetEntityRenderMode(e, RENDER_TRANSCOLOR);
    SetEntityRenderColor(e, 0, 0, 0, 255);
    ApplyBrokenSurvivorBody(e, g_iEntityAwareness);
    CreateTimer(lifetime, Timer_DeleteEntity, EntIndexToEntRef(e), TIMER_FLAG_NO_MAPCHANGE);
    CreateTimer(0.75, Timer_SubtleTwitchEntity, EntIndexToEntRef(e), TIMER_REPEAT | TIMER_FLAG_NO_MAPCHANGE);
}

void UpdateTrackedWatchers(int p) {
    if (g_hSpawnedRefs == null) return;
    float ppos[3]; GetClientAbsOrigin(p, ppos);
    for (int i = 0; i < g_hSpawnedRefs.Length; i++) {
        int e = EntRefToEntIndex(g_hSpawnedRefs.Get(i));
        if (e == INVALID_ENT_REFERENCE || e <= MaxClients || !IsValidEntity(e)) continue;
        char name[64]; GetEntPropString(e, Prop_Data, "m_iName", name, sizeof(name));
        if (StrContains(name, "witness_watcher", false) == -1) continue;
        float epos[3], d[3], a[3]; GetEntPropVector(e, Prop_Data, "m_vecAbsOrigin", epos);
        if (GetVectorDistance(epos, ppos) < 105.0) { RemoveEntity(e); continue; }
        MakeVectorFromPoints(epos, ppos, d); GetVectorAngles(d, a); a[0]=0.0; a[2]=0.0; TeleportEntity(e, NULL_VECTOR, a, NULL_VECTOR);
    }
}

void StartSafeRoomTrap(int p) {
    SetDarkness();
    ShowOverlay(p, "witness_v25/tv_noise", 0.4);
    CreateTimer(0.25, Timer_SafeTrapScream, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    CreateTimer(3.5, Timer_EndSafeTrap, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
}

public Action Timer_SafeTrapScream(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (!IsValidSurvivor(p)) return Plugin_Stop;
    float pos[3]; GetClientAbsOrigin(p, pos);
    for (int i = 0; i < 12; i++) {
        float y = i * 30.0 * FLOAT_PI / 180.0;
        float sp[3]; sp[0]=pos[0]+Cosine(y)*82.0; sp[1]=pos[1]+Sine(y)*82.0; sp[2]=pos[2];
        int e = CreateEntityByName("prop_dynamic_override");
        if (e == -1) continue;
        DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS)-1)]);
        DispatchKeyValue(e, "targetname", "witness_watcher_safe"); DispatchKeyValue(e, "solid", "0"); DispatchSpawn(e); TrackEntity(e);
        float a[3], d[3]; MakeVectorFromPoints(sp, pos, d); GetVectorAngles(d, a); a[0]=0.0; a[2]=0.0;
        TeleportEntity(e, sp, a, NULL_VECTOR); SetEntityRenderMode(e, RENDER_TRANSCOLOR); SetEntityRenderColor(e, 0,0,0,255);
        ApplyBrokenSurvivorBody(e, 9); SetEntProp(e, Prop_Send, "m_nSequence", 0);
        CreateTimer(0.65, Timer_SubtleTwitchEntity, EntIndexToEntRef(e), TIMER_REPEAT | TIMER_FLAG_NO_MAPCHANGE);
    }
    PlayHorrorSound(p, "music/witness_v25/screamer.wav", 1.0);
    ShowOverlay(p, "witness_v25/scream_face", 1.1);
    ScreenShake(p, 60.0, 45.0, 3.0);
    PrintCenterText(p, "SAFE ROOM IS A LIE");
    return Plugin_Stop;
}

public Action Timer_EndSafeTrap(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (IsValidSurvivor(p) && g_Phase == P_SafeRoomTrap) {
        g_Phase = P_Decay;
        CleanupNonStalkerWatchers();
        PrintHintText(p, "continue");
    }
    return Plugin_Stop;
}

void TriggerVoid(int p) {
    if (!IsValidSurvivor(p) || g_Phase == P_Void) return;
    g_Phase = P_Void;
    g_iDecay = 9;
    StopDirector();
    CleanupSpawnedEntities();
    FadeClient(p, 0, 0, 0, 255, 200, 1800, 0x0001);
    PrintCenterText(p, "ERROR 404: EXIT ROUTE NOT FOUND");
    PrintToChat(p, "\x04WITNESS: you never installed a way out");
    CreateTimer(1.5, Timer_VoidStage1, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
}

public Action Timer_VoidStage1(Handle timer, any userid) {
    int p = GetClientOfUserId(userid); if (!IsValidSurvivor(p)) return Plugin_Stop;
    float pos[3]; GetClientAbsOrigin(p, pos); pos[2] += 2200.0;
    RemoveWeaponsFromSlot(p, 0); RemoveWeaponsFromSlot(p, 1); RemoveWeaponsFromSlot(p, 2);
    SetEntityMoveType(p, MOVETYPE_NONE);
    TeleportEntity(p, pos, NULL_VECTOR, NULL_VECTOR);
    SetDarkness();
    PlayHorrorSound(p, "music/witness_v25/void_drone.wav", 1.0);
    PlayHorrorSound(p, "music/witness_v28/entity_presence.wav", 1.0);
    PlayVoiceMP3(p, "music/witness_v31/no_exit.mp3", 0.9);
    SpawnVoidCircle(p, pos);
    CreateTimer(2.0, Timer_VoidStage2, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    return Plugin_Stop;
}

public Action Timer_VoidStage2(Handle timer, any userid) {
    int p = GetClientOfUserId(userid); if (!IsValidSurvivor(p)) return Plugin_Stop;
    PrintCenterText(p, "Y O U   C A N N O T   E X I T");
    ShowOverlay(p, "witness_v25/tv_noise", 0.8);
    ScreenShake(p, 12.0, 8.0, 4.0);
    CreateTimer(5.5, Timer_VoidFinale, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    return Plugin_Stop;
}

public Action Timer_VoidFinale(Handle timer, any userid) {
    int p = GetClientOfUserId(userid); if (!IsValidSurvivor(p)) return Plugin_Stop;
    PlayHorrorSound(p, "music/witness_v25/screamer.wav", 1.0);
    ShowOverlay(p, "witness_v25/scream_face", 1.25);
    ScreenShake(p, 80.0, 60.0, 2.0);
    FadeClient(p, 255, 255, 255, 255, 80, 850, 0x0001);
    CreateTimer(1.35, Timer_ExitGame, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    return Plugin_Stop;
}

public Action Timer_ExitGame(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (p > 0 && IsClientInGame(p) && g_Phase == P_Void && g_cvExitFinale.BoolValue) {
        ClientCommand(p, "exit");
    }
    return Plugin_Stop;
}

void SpawnVoidCircle(int p, float center[3]) {
    for (int i = 0; i < 28; i++) {
        float yaw = i * (360.0 / 28.0) * FLOAT_PI / 180.0;
        float pos[3]; pos[0]=center[0]+Cosine(yaw)*260.0; pos[1]=center[1]+Sine(yaw)*260.0; pos[2]=center[2]+GetRandomFloat(-40.0, 80.0);
        int e = CreateEntityByName("prop_dynamic_override"); if (e == -1) continue;
        DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS)-1)]);
        DispatchKeyValue(e, "targetname", "witness_watcher_void"); DispatchKeyValue(e, "solid", "0"); DispatchSpawn(e); TrackEntity(e);
        float a[3], d[3]; MakeVectorFromPoints(pos, center, d); GetVectorAngles(d, a); a[0]=0.0; a[2]=0.0;
        TeleportEntity(e, pos, a, NULL_VECTOR); SetEntityRenderMode(e, RENDER_TRANSCOLOR); SetEntityRenderColor(e, 0,0,0,255);
        ApplyBrokenSurvivorBody(e, 10); SetEntProp(e, Prop_Data, "m_nSequence", 0);
        CreateTimer(0.80, Timer_SubtleTwitchEntity, EntIndexToEntRef(e), TIMER_REPEAT | TIMER_FLAG_NO_MAPCHANGE);
    }
}

public Action Timer_RestoreRoll(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (IsValidSurvivor(p)) { float a[3]; GetClientEyeAngles(p, a); a[2] = 0.0; TeleportEntity(p, NULL_VECTOR, a, NULL_VECTOR); }
    return Plugin_Stop;
}

public Action Timer_RestoreGravity(Handle timer) {
    if (g_cvGravity != null) g_cvGravity.FloatValue = g_fOldGravity;
    return Plugin_Stop;
}

public Action Timer_DeleteEntity(Handle timer, any ref) {
    int e = EntRefToEntIndex(ref);
    if (e != INVALID_ENT_REFERENCE && e > MaxClients && IsValidEntity(e)) {
        EmitSoundToAll("ambient/energy/zap1.wav", e, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 0.35);
        RemoveEntity(e);
    }
    return Plugin_Stop;
}


void UpdateEntityMemory(int p, float now) {
    float pos[3];
    GetClientAbsOrigin(p, pos);

    if (g_fIdleSince[p] <= 0.0) {
        g_fIdleSince[p] = now;
        g_fLastPos[p][0] = pos[0]; g_fLastPos[p][1] = pos[1]; g_fLastPos[p][2] = pos[2];
        return;
    }

    if (GetVectorDistance(pos, g_fLastPos[p]) < 24.0) {
        if (now - g_fIdleSince[p] > 18.0) {
            if (g_iEntityAwareness < 10) g_iEntityAwareness++;
            if (GetRandomInt(0, 2) == 0) PrintCenterText(p, "WHY DID YOU STOP");
            g_fIdleSince[p] = now + 10.0;
        }
    } else {
        g_fIdleSince[p] = now;
        g_fLastPos[p][0] = pos[0]; g_fLastPos[p][1] = pos[1]; g_fLastPos[p][2] = pos[2];
    }

    float ang[3];
    GetClientEyeAngles(p, ang);
    static float lastYaw[MAXPLAYERS + 1];
    float delta = FloatAbs(AngleDiff(ang[1], lastYaw[p]));
    if (delta > 135.0) {
        g_iLookBackCount[p]++;
        if (g_iLookBackCount[p] % 5 == 0 && g_iEntityAwareness < 10) {
            g_iEntityAwareness++;
            PrintHintText(p, "STOP CHECKING");
        }
    }
    lastYaw[p] = ang[1];
}

float AngleDiff(float a, float b) {
    float d = a - b;
    while (d > 180.0) d -= 360.0;
    while (d < -180.0) d += 360.0;
    return d;
}

void UpdateEntityVoice(int p, float now) {
    if (now <= g_fNextEntityVoice) return;
    g_fNextEntityVoice = now + GetRandomFloat(28.0, 55.0) - float(g_iEntityAwareness) * 1.5;

    if (!g_bWitnessJoined && g_iEntityAwareness >= 3) {
        g_bWitnessJoined = true;
        PrintToChat(p, "\x04WITNESS has joined the game");
        return;
    }

    int r = GetRandomInt(0, 10);
    if (r == 0) PrintToChat(p, "\x01[ERROR 404] model/survivors/%s_face.vtx was touched", "human");
    else if (r == 1) PrintToChat(p, "\x04WITNESS changed name to Bill");
    else if (r == 2) PrintToChat(p, "\x01Bill: that's not my face");
    else if (r == 3) PrintToChat(p, "\x01Zoey: it is moving the walls");
    else if (r == 4) PrintHintText(p, "404: TEXTURE MEMORY REPLACED");
    else if (r == 5) PrintCenterText(p, "I AM IN THE MAP");
    else if (r == 6) PrintToChat(p, "\x01[Console] bone matrix overflow: survivor_limb_elongated");
    else if (r == 7) PrintHintText(p, "THE OLD BUILD IS UNDER THIS ONE");
    else if (r == 8) PrintToChat(p, "\x01[ERROR 404] %d moving props without owner", CountNearbyProps(p));
    else if (r == 9) PrintCenterText(p, "DO NOT LOOK AT THEIR FACES");
    else PrintToChat(p, "\x04WITNESS is now idle");
}

void UpdateWorldCorruption(int p, float now) {
    if (now > g_fNextTextureRot) {
        g_fNextTextureRot = now + GetRandomFloat(18.0, 34.0) - float(g_iEntityAwareness);
        TextureMemoryPulse(p);
    }

    if (now > g_fNextWorldCorrupt) {
        g_fNextWorldCorrupt = now + GetRandomFloat(8.0, 18.0) - float(g_iEntityAwareness) * 0.7;
        CorruptNearbyStaticProps(p);
    }

    if (now > g_fNextPropThrow) {
        g_fNextPropThrow = now + GetRandomFloat(10.0, 22.0) - float(g_iEntityAwareness) * 0.8;
        ThrowTouchedProp(p);
    }
}

void TextureMemoryPulse(int p) {
    if (!IsValidSurvivor(p)) return;
    int r = GetRandomInt(0, 4);
    if (r == 0) SetLightStyle(0, "b");
    else if (r == 1) SetLightStyle(0, "z");
    else SetLightStyle(0, "a");

    ShowOverlay(p, "witness_v25/tv_noise", GetRandomFloat(0.18, 0.55));
    PlayHorrorSound(p, "music/witness_v25/static_burst.wav", 0.85);
    PrintToChat(p, "\x01[ERROR 404] material table reverted to previous build");
    CreateTimer(1.2, Timer_RestoreDarkness, _, TIMER_FLAG_NO_MAPCHANGE);
}

public Action Timer_RestoreDarkness(Handle timer) {
    if (g_bActive && g_Phase >= P_Isolation) SetDarkness();
    else SetLightStyle(0, "m");
    return Plugin_Stop;
}

int CountNearbyProps(int p) {
    float ppos[3]; GetClientAbsOrigin(p, ppos);
    int count = 0;
    int ent = -1;
    while ((ent = FindEntityByClassname(ent, "prop_physics*")) != -1) {
        if (!IsValidEntity(ent)) continue;
        float epos[3]; GetEntPropVector(ent, Prop_Data, "m_vecAbsOrigin", epos);
        if (GetVectorDistance(ppos, epos) < 900.0) count++;
    }
    return count;
}

void CorruptNearbyStaticProps(int p) {
    float ppos[3]; GetClientAbsOrigin(p, ppos);
    int changed = 0;
    int ent = -1;
    while ((ent = FindEntityByClassname(ent, "prop_dynamic*")) != -1) {
        if (changed >= 4) break;
        if (ent <= MaxClients || !IsValidEntity(ent)) continue;
        float epos[3]; GetEntPropVector(ent, Prop_Data, "m_vecAbsOrigin", epos);
        if (GetVectorDistance(ppos, epos) > 850.0) continue;
        if (GetRandomInt(0, 100) > 35 + g_iEntityAwareness * 4) continue;
        float ang[3]; GetEntPropVector(ent, Prop_Data, "m_angRotation", ang);
        ang[0] += GetRandomFloat(-8.0, 8.0); ang[1] += GetRandomFloat(-35.0, 35.0); ang[2] += GetRandomFloat(-8.0, 8.0);
        TeleportEntity(ent, NULL_VECTOR, ang, NULL_VECTOR);
        SetEntityRenderMode(ent, RENDER_TRANSCOLOR);
        SetEntityRenderColor(ent, GetRandomInt(40, 120), GetRandomInt(40, 120), GetRandomInt(40, 120), 255);
        changed++;
    }
}

void ThrowTouchedProp(int p) {
    float ppos[3]; GetClientAbsOrigin(p, ppos);
    int candidates[32];
    int count = 0;
    int ent = -1;
    while ((ent = FindEntityByClassname(ent, "prop_physics*")) != -1) {
        if (count >= sizeof(candidates)) break;
        if (ent <= MaxClients || !IsValidEntity(ent)) continue;
        float epos[3]; GetEntPropVector(ent, Prop_Data, "m_vecAbsOrigin", epos);
        if (GetVectorDistance(ppos, epos) > 720.0) continue;
        candidates[count++] = ent;
    }
    if (count <= 0) return;
    int e = candidates[GetRandomInt(0, count - 1)];
    float vel[3];
    vel[0] = GetRandomFloat(-380.0, 380.0);
    vel[1] = GetRandomFloat(-380.0, 380.0);
    vel[2] = GetRandomFloat(180.0, 420.0);
    TeleportEntity(e, NULL_VECTOR, NULL_VECTOR, vel);
    EmitSoundToClient(p, "ambient/atmosphere/cave_hit5.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 0.75, 55);
    PrintHintText(p, "something touched the map");
}


void ApplyBrokenSurvivorBody(int e, int intensity) {
    // V28: no more huge survivor scaling. L4D2 survivor meshes/bodygroups can detach clothes
    // and look silly if scaled/animated aggressively. We use silhouettes + controlled twitch.
    float scale = GetRandomFloat(1.08, 1.38) + float(intensity) * 0.015;
    if (scale > 1.55) scale = 1.55;
    SetEntPropFloat(e, Prop_Send, "m_flModelScale", scale);
    SetEntityRenderMode(e, RENDER_TRANSCOLOR);
    SetEntityRenderColor(e, GetRandomInt(0, 12), GetRandomInt(0, 12), GetRandomInt(0, 12), 255);
    SetEntProp(e, Prop_Send, "m_nSequence", 0);
    SetEntPropFloat(e, Prop_Send, "m_flPlaybackRate", 0.0);
}

public Action Timer_SubtleTwitchEntity(Handle timer, any ref) {
    int e = EntRefToEntIndex(ref);
    if (e == INVALID_ENT_REFERENCE || e <= MaxClients || !IsValidEntity(e) || !g_bActive) return Plugin_Stop;
    float ang[3];
    GetEntPropVector(e, Prop_Data, "m_angRotation", ang);
    // Small rotations only: enough to look possessed, not enough to explode bodygroups.
    ang[1] += GetRandomFloat(-5.0, 5.0);
    if (GetRandomInt(0, 100) < 10) ang[2] += GetRandomFloat(-3.0, 3.0);
    TeleportEntity(e, NULL_VECTOR, ang, NULL_VECTOR);
    return Plugin_Continue;
}

void UpdateCinematicScenes(int p, float now) {
    if (g_Phase < P_Decay || g_Phase == P_Void) return;

    if (now > g_fNextBehind && g_iLookBackCount[p] >= 4) {
        g_fNextBehind = now + GetRandomFloat(35.0, 65.0);
        SceneBehind(p);
        return;
    }

    if (now > g_fNextOldBuildScene && g_iEntityAwareness >= 5) {
        g_fNextOldBuildScene = now + GetRandomFloat(55.0, 90.0);
        SceneOldBuild(p);
        return;
    }

    if (now <= g_fNextScene) return;
    g_fNextScene = now + GetSceneCooldown();

    int scene = GetRandomInt(0, 5);
    if (scene == g_iLastScene) scene = (scene + 1) % 6;
    g_iLastScene = scene;

    if (scene == 0) SceneObjectPossessionChain(p);
    else if (scene == 1) SceneWrongSurvivor(p);
    else if (scene == 2) ScenePhotoFlash(p);
    else if (scene == 3) SceneDoorKnock(p);
    else if (scene == 4) SceneTexture404(p);
    else SceneCeilingBody(p);
}

void SceneBehind(int p) {
    PrintCenterText(p, "BEHIND");
    PlayHorrorSound(p, "music/witness_v28/breath_behind.wav", 1.0);
    PlayVoiceMP3(p, "music/witness_v31/not_alone.mp3", 0.65);
    ShowRandomHorrorFrame(p, 0.12);
    SpawnHallucination(p, 120.0, 1.4, false);
}

void SceneOldBuild(int p) {
    PrintToChat(p, "\x01[ERROR 404] loading pre-release asset table...");
    PrintToChat(p, "\x01[ERROR 404] survivors/faces/old not found");
    ShowOverlay(p, "witness_v28/old_build_404", 1.6);
    PlayHorrorSound(p, "music/witness_v28/reverse_whisper_01.wav", 1.0);
    PlayVoiceMP3(p, "music/witness_v31/wrong_way.mp3", 0.7);
    SetLightStyle(0, "z");
    CreateTimer(1.8, Timer_RestoreDarkness, _, TIMER_FLAG_NO_MAPCHANGE);
}

void SceneMapHand(int p) {
    PrintHintText(p, "something is touching the map");
    PlayHorrorSound(p, "music/witness_v28/map_hand.wav", 1.0);
    for (int i = 0; i < 3; i++) ThrowTouchedProp(p);
}

void SceneWrongSurvivor(int p) {
    PrintToChat(p, "\x01Bill: don't come closer");
    SpawnHallucination(p, GetRandomFloat(260.0, 420.0), 5.0, true);
    PlayHorrorSound(p, "music/witness_v28/witch_breath.wav", 1.0);
    CreateTimer(2.2, Timer_WrongSurvivorFace, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
}

public Action Timer_WrongSurvivorFace(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (IsValidSurvivor(p)) {
        ShowOverlay(p, "witness_v28/face_red", 0.28);
        PlayHorrorSound(p, "music/witness_v28/bone_crack.wav", 1.0);
        PrintCenterText(p, "THAT WAS NOT BILL");
    }
    return Plugin_Stop;
}

void ScenePhotoFlash(int p) {
    ShowRandomHorrorFrame(p, GetRandomFloat(0.08, 0.22));
    PlayHorrorSound(p, "music/witness_v28/deep_glitch_hit.wav", 1.0);
    if (GetRandomInt(0, 1) == 0) PrintToChat(p, "\x01[ERROR 404] frame inserted by unknown client");
}

void SceneDoorKnock(int p) {
    PlayHorrorSound(p, "music/witness_v29/door_pound.wav", 1.0);
    PlayHorrorSound(p, "music/witness_v28/distant_knock.wav", 1.0);
    PrintHintText(p, "do not open it");
}

void SceneTexture404(int p) {
    ShowOverlay(p, "witness_v28/missing_texture_flash", 0.55);
    PrintToChat(p, "\x01[ERROR 404] texture replacement requested by WITNESS");
    TextureMemoryPulse(p);
}

void SceneCeilingBody(int p) {
    float ppos[3]; GetClientAbsOrigin(p, ppos);
    float pos[3]; pos[0] = ppos[0] + GetRandomFloat(-80.0, 80.0); pos[1] = ppos[1] + GetRandomFloat(-80.0, 80.0); pos[2] = ppos[2] + 180.0;
    int e = CreateEntityByName("prop_dynamic_override");
    if (e == -1) return;
    DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS) - 1)]);
    DispatchKeyValue(e, "targetname", "witness_watcher_ceiling");
    DispatchKeyValue(e, "solid", "0");
    DispatchSpawn(e); TrackEntity(e); ApplyBrokenSurvivorBody(e, 9);
    float ang[3]; ang[0] = 180.0; ang[1] = GetRandomFloat(0.0, 360.0); ang[2] = 0.0;
    TeleportEntity(e, pos, ang, NULL_VECTOR);
    PlayHorrorSound(p, "music/witness_v28/metal_drag.wav", 1.0);
    PlayHorrorSound(p, "music/witness_v29/body_drop.wav", 0.95);
    CreateTimer(4.0, Timer_DeleteEntity, EntIndexToEntRef(e), TIMER_FLAG_NO_MAPCHANGE);
}

void ShowRandomHorrorFrame(int p, float duration) {
    int r = GetRandomInt(0, 6);
    if (r == 0) ShowOverlay(p, "witness_v28/face_analog_01", duration);
    else if (r == 1) ShowOverlay(p, "witness_v28/old_build_404", duration);
    else if (r == 2) ShowOverlay(p, "witness_v28/eyes_in_static", duration);
    else if (r == 3) ShowOverlay(p, "witness_v28/eyes_static", duration);
    else if (r == 4) ShowOverlay(p, "witness_v28/404_frame", duration);
    else if (r == 5) ShowOverlay(p, "witness_v28/corrupt_hud", duration);
    else ShowOverlay(p, "witness_v28/void_frame", duration);
}

void WitchSpecialAction(int p, int witch, bool looking, float dist) {
    int action = GetRandomInt(0, 4);
    if (looking && action <= 1) {
        PrintCenterText(p, "SHE SEES YOU TOO");
        PlayVoiceMP3(p, "music/witness_v31/look_at_me.mp3", 0.9);
        ShowOverlay(p, "witness_v28/eyes_static", 0.35);
        PlayHorrorSound(p, "music/witness_v28/witch_breath.wav", 1.0);
        if (g_cvTimeScale != null) g_cvTimeScale.FloatValue = 0.22;
    } else if (action == 2) {
        SceneObjectPossessionChain(p);
    } else if (action == 3) {
        SpawnHallucination(p, 190.0, 2.8, false);
        PrintHintText(p, "she moved something behind you");
    } else {
        float wpos[3], ppos[3]; GetEntPropVector(witch, Prop_Data, "m_vecAbsOrigin", wpos); GetClientAbsOrigin(p, ppos);
        float y = GetRandomFloat(0.0, 360.0) * FLOAT_PI / 180.0;
        float np[3]; np[0] = ppos[0] + Cosine(y) * 150.0; np[1] = ppos[1] + Sine(y) * 150.0; np[2] = ppos[2] + 10.0;
        TeleportEntity(witch, np, NULL_VECTOR, NULL_VECTOR);
        PlayHorrorSound(p, "music/witness_v28/old_radio_click.wav", 1.0);
    }
}



void UpdateDirectorScenes(int p, float now) {
    if (g_Phase == P_Void || !IsValidSurvivor(p)) return;

    // One-shot map-specific scenes: more memorable than random spam.
    if (g_iChapter == 1 && !g_bMapSceneDone[1] && g_Phase >= P_Observed) {
        g_bMapSceneDone[1] = true;
        SceneC8M1WindowSignal(p);
        g_fNextDirectorScene = now + 45.0;
        return;
    }

    if (g_iChapter == 2 && !g_bMapSceneDone[2] && g_Phase >= P_Decay) {
        g_bMapSceneDone[2] = true;
        SceneC8M2TrainWatching(p);
        g_fNextDirectorScene = now + 40.0;
        return;
    }

    if (g_iChapter == 3 && !g_bMapSceneDone[3] && g_Phase >= P_Decay) {
        g_bMapSceneDone[3] = true;
        SceneC8M3PipeMemory(p);
        g_fNextDirectorScene = now + 38.0;
        return;
    }

    if (g_iChapter == 4 && !g_bMapSceneDone[4] && g_Phase >= P_Decay) {
        g_bMapSceneDone[4] = true;
        SceneC8M4PatientYou(p);
        g_fNextDirectorScene = now + 38.0;
        return;
    }

    if (g_iChapter == 5 && !g_bMapSceneDone[5] && g_Phase >= P_Decay) {
        g_bMapSceneDone[5] = true;
        SceneC8M5NoRescue(p);
        g_fNextDirectorScene = now + 20.0;
        return;
    }

    // Controlled stronger map breaking: occasional, staged, not constant noise.
    if (g_Phase >= P_Decay && now > g_fNextMapFracture) {
        float minDelay = (g_iChapter >= 3) ? 34.0 : 55.0;
        float maxDelay = (g_iChapter >= 3) ? 70.0 : 95.0;
        if (GetIntensity() >= 3) { minDelay *= 0.65; maxDelay *= 0.75; }
        g_fNextMapFracture = now + GetRandomFloat(minDelay, maxDelay);
        SceneMapFracture(p);
    }
}

void SceneC8M1WindowSignal(int p) {
    PrintToChat(p, "\x01[ERROR 404] camera entity found outside apartment bounds");
    SpawnHallucination(p, 650.0, 5.5, true);
    SetLightStyle(0, "b");
    CreateTimer(1.5, Timer_RestoreDarkness, _, TIMER_FLAG_NO_MAPCHANGE);
    PlayHorrorSound(p, "signal", 0.45);
}

void SceneC8M2TrainWatching(int p) {
    PrintCenterText(p, "NEXT TRAIN: NEVER");
    PlayHorrorSound(p, "metal", 0.65);
    ScreenShake(p, 7.0, 4.0, 1.4);
    SpawnHallucination(p, 520.0, 6.0, true);
    CreateTimer(1.2, Timer_DirectorSecondWatcher, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
}

void SceneC8M3PipeMemory(int p) {
    PrintToChat(p, "\x01[ERROR 404] water contains survivor voice data");
    PlayHorrorSound(p, "door", 0.7);
    ScreenShake(p, 10.0, 7.0, 1.7);
    ThrowTouchedProp(p);
    ThrowTouchedProp(p);
}

void SceneC8M4PatientYou(int p) {
    PrintCenterText(p, "PATIENT: YOU");
    PrintToChat(p, "\x01Zoey: don't let it wear my face");
    SceneCeilingBody(p);
    PlayHorrorSound(p, "body", 0.7);
}

void SceneC8M5NoRescue(int p) {
    PrintToChat(p, "\x01[ERROR 404] rescue entity missing");
    PrintToChat(p, "\x01[ERROR 404] helicopter path: null");
    PlayVoiceMP3(p, "music/witness_v31/no_exit.mp3", 0.9);
    SpawnHallucination(p, 260.0, 8.0, true);
    SpawnHallucination(p, 300.0, 8.0, false);
}

public Action Timer_DirectorSecondWatcher(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (IsValidSurvivor(p)) SpawnHallucination(p, 240.0, 3.5, false);
    return Plugin_Stop;
}

void SceneMapFracture(int p) {
    PrintHintText(p, "the map moved while you were inside it");
    PlayHorrorSound(p, "map_fracture", 0.65);
    if (GetRandomInt(0, 1) == 1) SetLightStyle(0, "a"); else SetLightStyle(0, "c");
    CreateTimer(0.9, Timer_RestoreDarkness, _, TIMER_FLAG_NO_MAPCHANGE);

    // Stronger but still mostly safe: only physics props get real velocity.
    for (int i = 0; i < 5; i++) ThrowTouchedProp(p);
    CorruptNearbyStaticProps(p);
    NudgeNearbyDoors(p);

    if (GetRandomInt(0, 100) < 45) SpawnHallucination(p, GetRandomFloat(180.0, 420.0), 4.0, GetRandomInt(0, 1) == 1);
}

void NudgeNearbyDoors(int p) {
    float ppos[3];
    GetClientAbsOrigin(p, ppos);

    NudgeDoorClass(p, ppos, "prop_door_rotating");
    NudgeDoorClass(p, ppos, "func_door");
    NudgeDoorClass(p, ppos, "func_door_rotating");
}

void NudgeDoorClass(int client, float ppos[3], const char[] classname) {
    int ent = -1;
    int touched = 0;
    while ((ent = FindEntityByClassname(ent, classname)) != -1) {
        if (touched >= 2) break;
        if (ent <= MaxClients || !IsValidEntity(ent)) continue;
        float epos[3];
        GetEntPropVector(ent, Prop_Data, "m_vecAbsOrigin", epos);
        if (GetVectorDistance(ppos, epos) > 650.0) continue;
        if (GetRandomInt(0, 1) == 1) {
            AcceptEntityInput(ent, "Open");
        } else {
            AcceptEntityInput(ent, "Close");
        }
        touched++;
    }
}

void PlayVoiceMP3(int client, const char[] snd, float volume) {
    if (!IsValidSurvivor(client)) return;
    // Try MP3 custom voice. If the local cache rejects it, the stock fallback still fires.
    EmitSoundToClient(client, snd, SOUND_FROM_PLAYER, SNDCHAN_VOICE, SNDLEVEL_NORMAL, SND_NOFLAGS, volume, 100);
    EmitSoundToClient(client, "ambient/ambience/rainscapes/Thunder_close01.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 0.22, 45);
}

int GetIntensity() {
    if (g_cvIntensity == null) return 4;
    int v = g_cvIntensity.IntValue;
    if (v < 1) return 1;
    if (v > 4) return 4;
    return v;
}

float GetSceneCooldown() {
    int intensity = GetIntensity();
    float baseMin = 34.0;
    float baseMax = 58.0;

    if (g_iChapter >= 2) { baseMin = 22.0; baseMax = 42.0; }
    if (g_iChapter >= 3) { baseMin = 18.0; baseMax = 34.0; }
    if (g_iChapter >= 5) { baseMin = 10.0; baseMax = 18.0; }

    // Intensity affects pressure, but V30 never becomes constant spam by default.
    float c = GetRandomFloat(baseMin, baseMax) - float(intensity - 1) * 3.0 - float(g_iEntityAwareness) * 0.25;
    if (c < 8.0 && g_iChapter < 5) c = 8.0;
    if (c < 4.5) c = 4.5;
    return c;
}

void PlayHorrorSound(int client, const char[] snd, float volume) {
    if (!IsValidSurvivor(client)) return;

    // V30: stock-only fallback by design. Custom WAVs were unreliable in listen-server L4D2
    // without a rebuilt sound cache and spammed "file missing". Stock sounds are guaranteed.
    char stock[PLATFORM_MAX_PATH];
    float vol = volume;
    int pitch = 70;

    if (StrContains(snd, "voice", false) != -1 || StrContains(snd, "witch", false) != -1) {
        strcopy(stock, sizeof(stock), "ambient/ambience/rainscapes/Thunder_close01.wav");
        vol *= 0.38;
        pitch = 45;
    } else if (StrContains(snd, "body", false) != -1 || StrContains(snd, "door", false) != -1 || StrContains(snd, "metal", false) != -1 || StrContains(snd, "map_hand", false) != -1) {
        strcopy(stock, sizeof(stock), "ambient/atmosphere/cave_hit5.wav");
        vol *= 0.75;
        pitch = 58;
    } else if (StrContains(snd, "screamer", false) != -1 || StrContains(snd, "deep_glitch", false) != -1 || StrContains(snd, "static", false) != -1) {
        strcopy(stock, sizeof(stock), "ambient/energy/zap1.wav");
        vol *= 0.85;
        pitch = 72;
    } else if (StrContains(snd, "heartbeat", false) != -1 || StrContains(snd, "presence", false) != -1 || StrContains(snd, "void", false) != -1) {
        strcopy(stock, sizeof(stock), "ambient/atmosphere/cave_hit5.wav");
        vol *= 0.45;
        pitch = 55;
    } else {
        strcopy(stock, sizeof(stock), "ambient/atmosphere/cave_hit5.wav");
        vol *= 0.55;
        pitch = 65;
    }

    EmitSoundToClient(client, stock, SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, vol, pitch);
}

void UpdateAggressiveAudio(int p, float now) {
    if (now > g_fNextHeartbeat && g_Phase >= P_Decay) {
        g_fNextHeartbeat = now + GetRandomFloat(24.0, 42.0) - float(GetIntensity()) * 2.0;
        if (g_iChapter >= 3 || g_iEntityAwareness >= 6) {
            PlayHorrorSound(p, "heartbeat", 0.38);
        }
    }

    // V30: no constant aggressive chains unless the user explicitly asks for intensity 3-4.
    if (GetIntensity() < 3) return;

    if (now > g_fNextHardEvent && g_iEntityAwareness >= 6) {
        g_fNextHardEvent = now + GetRandomFloat(32.0, 55.0) - float(GetIntensity()) * 4.0;
        int r = GetRandomInt(0, 3);
        if (r == 0) SceneWitchDemand(p);
        else if (r == 1) SceneObjectPossessionChain(p);
        else if (r == 2) ScenePanicFrames(p);
        else SceneRouteBlocked(p);
    }
}

void SceneWitchDemand(int p) {
    PrintCenterText(p, "LOOK AT ME");
    PlayVoiceMP3(p, "music/witness_v31/look_at_me.mp3", 0.9);
    PlayHorrorSound(p, "music/witness_v29/witch_laugh_low.wav", 0.9);
    ShowOverlay(p, "witness_v28/eyes_in_static", 0.55);
    int witch = EntRefToEntIndex(g_iWitchRef);
    if (witch != INVALID_ENT_REFERENCE && IsValidEntity(witch)) {
        float ppos[3], pang[3], np[3];
        GetClientAbsOrigin(p, ppos); GetClientEyeAngles(p, pang);
        float y = pang[1] * FLOAT_PI / 180.0;
        np[0] = ppos[0] + Cosine(y) * 180.0; np[1] = ppos[1] + Sine(y) * 180.0; np[2] = ppos[2] + 10.0;
        TeleportEntity(witch, np, NULL_VECTOR, NULL_VECTOR);
    }
}

void SceneObjectPossessionChain(int p) {
    PrintHintText(p, "the map is moving itself");
    PlayHorrorSound(p, "music/witness_v28/map_hand.wav", 1.0);
    CreateTimer(0.35, Timer_ChainThrow, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    CreateTimer(1.15, Timer_ChainThrow, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    CreateTimer(1.65, Timer_ChainFace, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
}

public Action Timer_ChainThrow(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (IsValidSurvivor(p)) { ThrowTouchedProp(p); ThrowTouchedProp(p); }
    return Plugin_Stop;
}

public Action Timer_ChainFace(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (IsValidSurvivor(p)) { ShowRandomHorrorFrame(p, 0.18); PlayHorrorSound(p, "music/witness_v29/body_drop.wav", 1.0); }
    return Plugin_Stop;
}

void ScenePanicFrames(int p) {
    ShowRandomHorrorFrame(p, 0.10);
    CreateTimer(0.18, Timer_PanicFrame, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    CreateTimer(0.36, Timer_PanicFrame, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    PlayHorrorSound(p, "music/witness_v28/deep_glitch_hit.wav", 1.0);
}

public Action Timer_PanicFrame(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (IsValidSurvivor(p)) ShowRandomHorrorFrame(p, 0.09);
    return Plugin_Stop;
}

void SceneRouteBlocked(int p) {
    PrintCenterText(p, "WRONG WAY");
    PlayVoiceMP3(p, "music/witness_v31/wrong_way.mp3", 0.85);
    SpawnHallucination(p, 170.0, 3.5, true);
    SpawnHallucination(p, 110.0, 2.2, false);
}

void PrecacheAll() {
    PrecacheModel("models/infected/witch.mdl", true);
    for (int i = 0; i < sizeof(SURV_MODELS); i++) PrecacheModel(SURV_MODELS[i], true);
    PrecacheSound("ambient/atmosphere/cave_hit5.wav", true);
    PrecacheSound("ambient/ambience/rainscapes/Thunder_close01.wav", true);
    PrecacheSound("ambient/energy/zap1.wav", true);
    PrecacheSound("weapons/clipempty_rifle.wav", true);
    AddFileToDownloadsTable("materials/witness_v25/scream_face.vtf"); AddFileToDownloadsTable("materials/witness_v25/scream_face.vmt");
    AddFileToDownloadsTable("materials/witness_v25/tv_noise.vtf"); AddFileToDownloadsTable("materials/witness_v25/tv_noise.vmt");
    PrecacheSound("music/witness_v31/not_alone.mp3", true);
    PrecacheSound("music/witness_v31/look_at_me.mp3", true);
    PrecacheSound("music/witness_v31/wrong_way.mp3", true);
    PrecacheSound("music/witness_v31/no_exit.mp3", true);
    AddFileToDownloadsTable("sound/music/witness_v31/not_alone.mp3");
    AddFileToDownloadsTable("sound/music/witness_v31/look_at_me.mp3");
    AddFileToDownloadsTable("sound/music/witness_v31/wrong_way.mp3");
    AddFileToDownloadsTable("sound/music/witness_v31/no_exit.mp3");
    AddFileToDownloadsTable("materials/witness_v28/face_01.vmt"); AddFileToDownloadsTable("materials/witness_v28/face_red.vmt");
    AddFileToDownloadsTable("materials/witness_v28/face_blue.vmt"); AddFileToDownloadsTable("materials/witness_v28/eyes_static.vmt");
    AddFileToDownloadsTable("materials/witness_v28/old_build_noise.vmt"); AddFileToDownloadsTable("materials/witness_v28/missing_texture_flash.vmt");
    AddFileToDownloadsTable("materials/witness_v28/404_frame.vmt"); AddFileToDownloadsTable("materials/witness_v28/void_frame.vmt");
    AddFileToDownloadsTable("materials/witness_v28/corrupt_hud.vmt");
    AddFileToDownloadsTable("materials/witness_v28/face_analog_01.vmt");
    AddFileToDownloadsTable("materials/witness_v28/old_build_404.vmt");
    AddFileToDownloadsTable("materials/witness_v28/eyes_in_static.vmt");
}

void CaptureEngineState() {
    if (g_bEngineCaptured) return;
    if (g_cvTimeScale != null) { g_fOldTimeScale = g_cvTimeScale.FloatValue; g_iOldTimeScaleFlags = g_cvTimeScale.Flags; }
    if (g_cvGravity != null) { g_fOldGravity = g_cvGravity.FloatValue; g_iOldGravityFlags = g_cvGravity.Flags; }
    g_iOldOverlayFlags = GetCommandFlags("r_screenoverlay");
    g_bEngineCaptured = true;
}

void RelaxCheatFlags() {
    if (g_cvTimeScale != null) g_cvTimeScale.Flags = g_cvTimeScale.Flags & ~FCVAR_CHEAT;
    if (g_cvGravity != null) g_cvGravity.Flags = g_cvGravity.Flags & ~FCVAR_CHEAT;
    int flags = GetCommandFlags("r_screenoverlay"); if (flags != INVALID_FLAGS) SetCommandFlags("r_screenoverlay", flags & ~FCVAR_CHEAT);
    flags = GetCommandFlags("director_stop"); if (flags != INVALID_FLAGS) SetCommandFlags("director_stop", flags & ~FCVAR_CHEAT);
    flags = GetCommandFlags("director_start"); if (flags != INVALID_FLAGS) SetCommandFlags("director_start", flags & ~FCVAR_CHEAT);
}

void ResetEngine(bool restoreFlags) {
    if (g_cvTimeScale != null) { g_cvTimeScale.FloatValue = g_fOldTimeScale; if (restoreFlags && g_iOldTimeScaleFlags != INVALID_FLAGS) g_cvTimeScale.Flags = g_iOldTimeScaleFlags; }
    if (g_cvGravity != null) { g_cvGravity.FloatValue = g_fOldGravity; if (restoreFlags && g_iOldGravityFlags != INVALID_FLAGS) g_cvGravity.Flags = g_iOldGravityFlags; }
    if (restoreFlags && g_iOldOverlayFlags != INVALID_FLAGS) SetCommandFlags("r_screenoverlay", g_iOldOverlayFlags);
    SetLightStyle(0, "m");
    if (g_bDirectorStopped) { ServerCommand("director_start"); g_bDirectorStopped = false; }
    for (int i = 1; i <= MaxClients; i++) {
        if (!IsClientInGame(i) || IsFakeClient(i)) continue;
        SetEntProp(i, Prop_Send, "m_iDefaultFOV", 90); SetEntityMoveType(i, MOVETYPE_WALK); ClientCommand(i, "r_screenoverlay \"\"");
        StopSound(i, SNDCHAN_STATIC, "music/witness_v25/void_drone.wav"); StopSound(i, SNDCHAN_STATIC, "music/witness_v25/screamer.wav");
        float a[3]; GetClientEyeAngles(i, a); a[2] = 0.0; TeleportEntity(i, NULL_VECTOR, a, NULL_VECTOR);
    }
}

void RestoreLookEffect(int p) {
    if (g_cvTimeScale != null) g_cvTimeScale.FloatValue = g_fOldTimeScale;
    if (IsValidSurvivor(p)) SetEntProp(p, Prop_Send, "m_iDefaultFOV", 90);
}

void SetDarkness() { SetLightStyle(0, "a"); }
void StopDirector() { if (!g_bDirectorStopped) { ServerCommand("director_stop"); g_bDirectorStopped = true; } }

void CleanupSpawnedEntities() {
    int stalker = EntRefToEntIndex(g_iWitchRef); if (stalker != INVALID_ENT_REFERENCE && stalker > MaxClients && IsValidEntity(stalker)) RemoveEntity(stalker); g_iWitchRef = INVALID_ENT_REFERENCE;
    if (g_hSpawnedRefs == null) return;
    for (int i = 0; i < g_hSpawnedRefs.Length; i++) { int e = EntRefToEntIndex(g_hSpawnedRefs.Get(i)); if (e != INVALID_ENT_REFERENCE && e > MaxClients && IsValidEntity(e)) RemoveEntity(e); }
    g_hSpawnedRefs.Clear();
}

void CleanupNonStalkerWatchers() {
    if (g_hSpawnedRefs == null) return;
    for (int i = 0; i < g_hSpawnedRefs.Length; i++) {
        int e = EntRefToEntIndex(g_hSpawnedRefs.Get(i));
        if (e != INVALID_ENT_REFERENCE && e > MaxClients && IsValidEntity(e)) {
            char name[64]; GetEntPropString(e, Prop_Data, "m_iName", name, sizeof(name));
            if (StrContains(name, "witness_watcher", false) != -1) RemoveEntity(e);
        }
    }
}

void TrackEntity(int entity) { if (g_hSpawnedRefs != null && entity > MaxClients && IsValidEntity(entity)) g_hSpawnedRefs.Push(EntIndexToEntRef(entity)); }

void RemoveWeaponsFromSlot(int client, int slot) {
    for (int i = 0; i < 8; i++) { int w = GetPlayerWeaponSlot(client, slot); if (w == -1 || !IsValidEntity(w)) break; RemovePlayerItem(client, w); RemoveEntity(w); }
}

bool ShouldRun() {
    if (g_cvEnable == null || !g_cvEnable.BoolValue) return false;
    if (!IsAllowedGameMode()) return false;
    if (g_cvNoMercyOnly != null && g_cvNoMercyOnly.BoolValue && !IsNoMercyMap(g_sMap)) return false;
    return true;
}

bool IsAllowedGameMode() {
    if (g_cvGameMode == null) return true;
    char mode[32]; g_cvGameMode.GetString(mode, sizeof(mode));
    return StrEqual(mode, "coop", false) || StrEqual(mode, "realism", false) || StrEqual(mode, "singleplayer", false);
}

bool IsNoMercyMap(const char[] map) { return StrContains(map, "c8m", false) == 0; }

int ParseChapter(const char[] map) {
    int len = strlen(map);
    for (int i = 0; i < len - 1; i++) if (map[i] == 'm' && map[0] == 'c') { int c = map[i+1] - '0'; if (c >= 1 && c <= 5) return c; }
    return 1;
}

int GetBaseDecayForChapter(int chapter) {
    if (chapter <= 1) return 0;
    if (chapter == 2) return 2;
    if (chapter == 3) return 3;
    if (chapter == 4) return 4;
    return 5;
}

bool ShouldButtonTriggerVoid(int caller) {
    if (g_iChapter < 5 || !IsNoMercyMap(g_sMap)) return false;
    if (caller <= MaxClients || !IsValidEntity(caller)) return false;
    char target[128]; GetEntPropString(caller, Prop_Data, "m_iName", target, sizeof(target));
    if (target[0] == '\0') return true;
    return StrContains(target, "radio", false) != -1 || StrContains(target, "finale", false) != -1 || StrContains(target, "rescue", false) != -1 || StrContains(target, "button", false) != -1;
}

bool IsValidSurvivor(int client) { return client > 0 && client <= MaxClients && IsClientInGame(client) && IsPlayerAlive(client) && GetClientTeam(client) == 2; }
int GetPrimaryPlayer() { for (int i = 1; i <= MaxClients; i++) if (IsValidSurvivor(i) && !IsFakeClient(i)) return i; return 0; }

bool IsPlayerLookingAtPoint(int client, const float point[3], float threshold) {
    float eye[3], angles[3], fwd[3], target[3], adjusted[3];
    GetClientEyePosition(client, eye); GetClientEyeAngles(client, angles); GetAngleVectors(angles, fwd, NULL_VECTOR, NULL_VECTOR);
    adjusted[0] = point[0]; adjusted[1] = point[1]; adjusted[2] = point[2] + 40.0;
    MakeVectorFromPoints(eye, adjusted, target); NormalizeVector(target, target);
    if (GetVectorDotProduct(fwd, target) <= threshold) return false;
    TR_TraceRayFilter(eye, adjusted, MASK_SOLID, RayType_EndPoint, TraceFilterVisible, client);
    return !TR_DidHit();
}

public bool TraceFilterVisible(int entity, int contentsMask, any data) {
    if (entity > 0 && entity <= MaxClients) return false;
    if (entity > MaxClients && IsValidEntity(entity)) {
        char classname[64]; GetEntityClassname(entity, classname, sizeof(classname));
        if (StrEqual(classname, "prop_dynamic") || StrEqual(classname, "prop_dynamic_override")) return false;
    }
    return true;
}

void ShowOverlay(int client, const char[] overlay, float duration) {
    if (!IsValidSurvivor(client)) return;
    ClientCommand(client, "r_screenoverlay \"%s\"", overlay);
    if (duration < 900.0) { DataPack pack = new DataPack(); pack.WriteCell(GetClientUserId(client)); CreateTimer(duration, Timer_RemoveOverlay, pack, TIMER_DATA_HNDL_CLOSE | TIMER_FLAG_NO_MAPCHANGE); }
}

public Action Timer_RemoveOverlay(Handle timer, DataPack pack) {
    pack.Reset(); int c = GetClientOfUserId(pack.ReadCell()); if (IsValidSurvivor(c)) ClientCommand(c, "r_screenoverlay \"\""); return Plugin_Stop;
}

void ScreenShake(int client, float amp, float freq, float duration) {
    Handle m = StartMessageOne("Shake", client); if (m == null) return; BfWriteByte(m, 0); BfWriteFloat(m, amp); BfWriteFloat(m, freq); BfWriteFloat(m, duration); EndMessage();
}

void FadeClient(int client, int r, int g, int b, int a, int fadeIn, int fadeOut, int flags) {
    Handle msg = StartMessageOne("Fade", client); if (msg == null) return;
    BfWriteShort(msg, fadeIn); BfWriteShort(msg, fadeOut); BfWriteShort(msg, flags); BfWriteByte(msg, r); BfWriteByte(msg, g); BfWriteByte(msg, b); BfWriteByte(msg, a); EndMessage();
}

void Debug(const char[] fmt, any ...) {
    if (g_cvDebug == null || !g_cvDebug.BoolValue) return;
    char buffer[256]; VFormat(buffer, sizeof(buffer), fmt, 2); PrintToServer("[ERROR404] %s", buffer); LogMessage("[ERROR404] %s", buffer);
}
