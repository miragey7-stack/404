/*
    ERROR 404: LOST BUILD - LINEAR
    Workshop-ready VScript mutation. No SourceMod/MetaMod.
    WARNING: flashing images, screen shake, strong visual distortion.
*/

Msg("ERROR 404 LOST BUILD LINEAR loaded v0.3.1\n");
printl("ERROR404_LINEAR_ACTIVE");

MutationOptions <-
{
    CommonLimit = 18
    MegaMobSize = 12
    WanderingZombieDensityModifier = 0.012
    cm_MaxSpecials = 1
    BoomerLimit = 0
    SpitterLimit = 0
    JockeyLimit = 0
    ChargerLimit = 0
    HunterLimit = 0
    SmokerLimit = 1
    TankLimit = -1
    MobSpawnSize = 10
    DefaultItems = [ "pistol" ]
    function GetDefaultItem(idx) { if (idx < DefaultItems.len()) return DefaultItems[idx]; return 0; }
}

PLAYER <- null;
THINKER <- null;
WITNESS <- null;
BOSS <- null;
STATE <- "BOOT";
CHAPTER <- 1;
SPAWN <- null;
LAST_POS <- null;
LAST_YAW <- 0.0;
IDLE_SINCE <- 0.0;
NEXT_MEMORY <- 0.0;
NEXT_AMBIENT <- 0.0;
NEXT_FRACTURE <- 0.0;
NEXT_WATCHER <- 0.0;
NEXT_WITNESS <- 0.0;
NEXT_SCHIZO <- 0.0;
CORRUPT_COMPANION <- null;
SAFE_ATTEMPTS <- 0;
VOID_STARTED <- false;
BOSS_ACTIVE <- false;
BOSS_PHASE <- 0;
BOSS_START <- 0.0;
BOSS_SHOTS_AT_LAST <- 0;
BOSS_NEXT_MOVE <- 0.0;
BOSS_NEXT_SPAWN <- 0.0;

S <-
{
    boot = 0,
    c1_street = 0,
    c1_safe = 0,
    c2_intro = 0,
    c2_train = 0,
    c2_light = 0,
    c3_intro = 0,
    c3_error = 0,
    c3_safe = 0,
    c3_hallu_a = 0,
    c3_hallu_b = 0,
    c4_intro = 0,
    c4_elevator = 0,
    c4_chase = 0,
    c5_intro = 0,
    c5_radio = 0,
    shots = 0,
    lookbacks = 0,
    deaths = 0,
    intensity = 2,
    botloss = 0
}

function IsHuman(ent) { if (!ent) return false; if (IsPlayerABot(ent)) return false; try { return ent.IsSurvivor(); } catch(e) { return false; } }
function Say(t) { ClientPrint(null, HUD_PRINTTALK, "ERROR404: " + t); }
function Center(t) { ClientPrint(null, HUD_PRINTCENTER, t); }
function abs(v) { if (v < 0) return -v; return v; }
function Clamp(v, a, b) { if (v < a) return a; if (v > b) return b; return v; }
function NormYaw(y) { while (y > 180) y -= 360; while (y < -180) y += 360; return y; }

function Cmd(command, delay = 0.01)
{
    if (!PLAYER) return;
    local ent = Entities.FindByClassname(null, "point_clientcommand");
    if (!ent) ent = CreateSingleSimpleEntityFromTable({ classname = "point_clientcommand", targetname = "e404_clientcommand" });
    DoEntFire("!self", "Command", command, delay, PLAYER, ent);
}

function Delay(func, delay = 0.01)
{
    local ent = SpawnEntityFromTable("info_target", { targetname = "e404_delay" });
    if (ent.ValidateScriptScope()) {
        local sc = ent.GetScriptScope();
        sc["Run"] <- function() { func.call(g_ModeScript); EntFire("!self", "Kill", "", 0.0); }
        DoEntFire("!self", "CallScriptFunction", "Run", delay, null, ent);
    }
}

function Tone(kind = 0, vol = 0.5, pitch = 85)
{
    local snd = "ambient/energy/zap1.wav";
    if (kind == 1) snd = "ambient/atmosphere/cave_hit5.wav";
    if (kind == 2) snd = "ambient/ambience/rainscapes/Thunder_close01.wav";
    if (kind == 3) snd = "ambient/ambience/tv_static_loop2.wav";
    if (kind == 4) snd = "player/tank/voice/idle/tank_voice_03.wav";
    if (!IsSoundPrecached(snd)) PrecacheSound(snd);
    if (PLAYER) EmitAmbientSoundOn(snd, vol, 0, pitch, PLAYER);
}

function KillNamed(name) { local e = null; while (e = Entities.FindByName(e, name)) e.Kill(); }
function Chapter()
{
    local m = Director.GetMapName();
    if (m.find("c8m1") != null) return 1;
    if (m.find("c8m2") != null) return 2;
    if (m.find("c8m3") != null) return 3;
    if (m.find("c8m4") != null) return 4;
    if (m.find("c8m5") != null) return 5;
    return 1;
}
function Flow()
{
    if (!PLAYER) return 0.0;
    try { return GetCurrentFlowPercentForPlayer(PLAYER); } catch(e) { return 0.0; }
}

function ResetRunMemory()
{
    S.c1_street = 0;
    S.c1_safe = 0;
    S.c2_intro = 0;
    S.c2_train = 0;
    S.c2_light = 0;
    S.c3_intro = 0;
    S.c3_error = 0;
    S.c3_safe = 0;
    S.c3_hallu_a = 0;
    S.c3_hallu_b = 0;
    S.c4_intro = 0;
    S.c4_elevator = 0;
    S.c4_chase = 0;
    S.c5_intro = 0;
    S.c5_radio = 0;
    S.shots = 0;
    S.lookbacks = 0;
    S.botloss = 0;
    SAFE_ATTEMPTS = 0;
    VOID_STARTED = false;
    BOSS_ACTIVE = false;
}

function OnGameplayStart()
{
    RestoreTable("E404_LINEAR", S);
    CHAPTER = Chapter();
    if (CHAPTER == 1) ResetRunMemory();
    ApplyRules();
    Delay(EnsureBots, 2.0);
    SpawnThinker();
    printl("ERROR404 Linear OnGameplayStart chapter " + CHAPTER);
}
function OnShutdown() { SaveTable("E404_LINEAR", S); Cleanup(); }
function ApplyRules()
{
    Convars.SetValue("sv_cheats", 1);
    Convars.SetValue("sv_consistency", 0);
    Convars.SetValue("director_no_death_check", 1);
    Convars.SetValue("sb_all_bot_game", 1);
    Convars.SetValue("allow_all_bot_survivor_team", 1);
    Convars.SetValue("gameinstructor_start_sound_cooldown", 999999);
    SendToServerConsole("alias e404 scripted_user_func e404");
    SendToServerConsole("alias bbquiet scripted_user_func bbquiet");
    SendToServerConsole("alias bbintense scripted_user_func bbintense");
}
function Cleanup()
{
    KillNamed("e404_witness"); KillNamed("e404_watcher"); KillNamed("e404_eyes"); KillNamed("e404_companion"); KillNamed("e404_boss"); KillNamed("e404_error"); KillNamed("e404_thinker");
    SendToServerConsole("director_start");
    Cmd("cl_mouseenable 1", 0.0); Cmd("cl_drawhud 1", 0.0); Cmd("r_screenoverlay \"\"", 0.0); Cmd("host_timescale 1", 0.0); Cmd("mat_grain_scale_override 0", 0.0);
}
function SpawnThinker()
{
    KillNamed("e404_thinker");
    THINKER = SpawnEntityFromTable("info_target", { targetname = "e404_thinker" });
    if (THINKER.ValidateScriptScope()) {
        local sc = THINKER.GetScriptScope();
        sc["Think"] <- function() { g_ModeScript.MainThink(); return 0.25; }
        AddThinkToEnt(THINKER, "Think");
    }
}


function EnsureBots()
{
    printl("ERROR404 EnsureBots fired");
    // Listen-server mutations sometimes start with 0 survivor bots.
    // Some settings are ConVars, not console commands.
    try { Convars.SetValue("survivor_limit", 4); } catch(e) {}
    try { Convars.SetValue("sb_all_bot_game", 1); } catch(e) {}
    try { Convars.SetValue("allow_all_bot_survivor_team", 1); } catch(e) {}
    try { Convars.SetValue("vs_max_team_switches", 100); } catch(e) {}

    SendToServerConsole("sb_add");
    Delay(AddBotOne, 0.7);
    Delay(AddBotTwo, 1.4);
    Delay(AddBotThree, 2.1);
}
function AddBotOne() { SendToServerConsole("sb_add"); }
function AddBotTwo() { SendToServerConsole("sb_add"); }
function AddBotThree() { SendToServerConsole("sb_add"); }

function OnGameEvent_player_spawn(params)
{
    local p = GetPlayerFromUserID(params.userid); if (!IsHuman(p)) return;
    PLAYER = p; SPAWN = p.GetOrigin(); LAST_POS = p.GetOrigin(); LAST_YAW = p.EyeAngles().y; IDLE_SINCE = Time(); NEXT_MEMORY = Time() + 90;
    if (STATE == "BOOT") { STATE = "NORMAL"; Delay(BootScene, 8.0); if (CHAPTER >= 2) Delay(ChapterStart, 2.5); }
}
function OnGameEvent_player_first_spawn(params) { OnGameEvent_player_spawn(params); }
function OnGameEvent_player_connect_full(params) { local p = GetPlayerFromUserID(params.userid); if (IsHuman(p)) PLAYER = p; }
function OnGameEvent_weapon_fire(params) { S.shots++; if (BOSS_ACTIVE) BossShotCheck(); }
function OnGameEvent_door_close(params)
{
    if (!("checkpoint" in params) || !params.checkpoint) return;
    if (CHAPTER == 1) Chapter1SafeDoor();
    else if (CHAPTER == 3 && S.c3_safe == 0) Chapter3SafeRush();
    else SafeRoomGeneric();
}
function OnGameEvent_finale_start(params) { if (CHAPTER == 5 && !BOSS_ACTIVE && !VOID_STARTED) StartBossFight(); }
function OnGameEvent_finale_radio_start(params) { if (CHAPTER == 5 && !BOSS_ACTIVE && !VOID_STARTED) StartBossFight(); }
function OnGameEvent_finale_vehicle_ready(params) { if (CHAPTER == 5 && !VOID_STARTED) FakeRescue(); }
function OnGameEvent_player_death(params) { if (BOSS_ACTIVE) BossFail(); }

function UserConsoleCommand(playerScript, arg)
{
    switch(arg) {
        case "e404": Notebook(); break;
        case "bbquiet": S.intensity = 1; Say("intensity quiet"); break;
        case "bbintense": S.intensity = 3; Say("intensity intense"); break;
        case "e404reset": ResetRunMemory(); Say("run memory reset"); break;
    }
}

function MainThink()
{
    if (!PLAYER || !PLAYER.IsValid()) return;
    MemoryThink();
    if (BOSS_ACTIVE) { BossThink(); return; }
    if (STATE == "NORMAL") NormalThink();
    if (STATE == "CORRUPT" || STATE == "ALONE") { CorruptThink(); FractureThink(); WitnessThink(); AmbientThink(); }
}
function MemoryThink()
{
    if (STATE == "VOID") return;
    local yaw = PLAYER.EyeAngles().y; local delta = abs(NormYaw(yaw - LAST_YAW));
    if (delta > 145) S.lookbacks++;
    LAST_YAW = yaw;
}
function NormalThink()
{
    local f = Flow(); local d = SPAWN ? (PLAYER.GetOrigin() - SPAWN).Length() : 0;
    if (CHAPTER == 1 && S.c1_street == 0 && (f > 18 || d > 950)) Chapter1StreetGlitch();
}
function CorruptThink()
{
    if (CHAPTER == 2 && S.c2_train == 0 && Flow() > 32) Chapter2TrainSilhouette();
    if (CHAPTER == 2 && S.c2_light == 0 && Flow() > 58) Chapter2LightEvent();
    if (CHAPTER == 3 && S.c3_error == 0 && Flow() > 20) Chapter3ErrorsBegin();
    if (CHAPTER == 3 && S.c3_hallu_a == 0 && Flow() > 38) Chapter3SchizoA();
    if (CHAPTER == 3 && S.c3_hallu_b == 0 && Flow() > 62) Chapter3SchizoB();
    if (CHAPTER == 4 && S.c4_chase == 0 && Flow() > 25) Chapter4EntityBegins();
    if (CHAPTER == 4 && S.c4_elevator == 0 && Flow() > 58) Chapter4Elevator();
    if (Time() > NEXT_FRACTURE) { MapFracture(); NEXT_FRACTURE = Time() + RandomFloat(45, 90); }
}

// ---------- CHAPTERS ----------
function BootScene() { Say("recording started"); Tone(0, 0.25, 70); Center("ERROR 404"); }
function SlowPlayer(mult)
{
    if (!PLAYER) return;
    try { NetProps.SetPropFloat(PLAYER, "m_flLaggedMovementValue", mult); } catch(e) {}
}

function SafeRoomGeneric()
{
    if (SAFE_ATTEMPTS == 0) {
        Say("checkpoint accepted");
        Tone(0, 0.25, 70);
    } else if (SAFE_ATTEMPTS == 1) {
        Say("checkpoint repeated");
        Tone(1, 0.30, 65);
    } else {
        Center("SAFE ROOM IS A LIE");
        GlitchHard(1.0);
        SpawnWatcher(140, 4.0, false);
    }
    SAFE_ATTEMPTS++;
}

function ChapterStart()
{
    if (CHAPTER == 2 && S.c2_intro == 0) {
        S.c2_intro = 1;
        RemoveOneBot();
        SlowPlayer(0.88);
        SparseWorld(5);
        STATE = "CORRUPT";
        Say("survivor count mismatch");
        Center("ONE LEFT THE RECORDING");
        NEXT_FRACTURE = Time() + 25;
    }

    if (CHAPTER == 3 && S.c3_intro == 0) {
        S.c3_intro = 1;
        RemoveOneBot();
        SpawnCorruptCompanion();
        SparseWorld(0);
        STATE = "CORRUPT";
        Say("infected population: 0");
        Say("last companion render data corrupted");
        NEXT_FRACTURE = Time() + 20;
        NEXT_SCHIZO = Time() + 18;
    }

    if (CHAPTER == 4 && S.c4_intro == 0) {
        S.c4_intro = 1;
        BotBoneBreak();
        SparseWorld(0);
        STATE = "ALONE";
        Say("companions unavailable");
        SpawnWitness(520, true);
        NEXT_FRACTURE = Time() + 18;
    }

    if (CHAPTER == 5 && S.c5_intro == 0) {
        S.c5_intro = 1;
        STATE = "ALONE";
        SparseWorld(0);
        Say("rescue signal stable");
        NEXT_AMBIENT = Time() + 12;
    }
}

function Chapter1StreetGlitch()
{
    S.c1_street = 1; STATE = "OBSERVED";
    SendToServerConsole("nb_stop 1"); Cmd("cl_mouseenable 0", 0.0); Cmd("cl_drawhud 0", 0.0);
    EpiText("DO NOT LOOK AWAY", 0.3, 0.38, 4.2);
    EpiText("IT FOUND THE CAMERA", 0.22, 0.58, 4.2);
    GlitchHard(4.8);
    Tone(3, 0.8, 80);
    SpawnEyes(900, 4.5);
    SpawnWatcher(800, 4.0, true);
    Delay(Chapter1Restore, 5.2);
}
function Chapter1Restore() { Cmd("cl_mouseenable 1",0); Cmd("cl_drawhud 1",0); SendToServerConsole("nb_stop 0"); STATE = "NORMAL"; Say("recording normalized"); }
function Chapter1SafeDoor()
{
    SAFE_ATTEMPTS++;
    if (SAFE_ATTEMPTS < 5) { Center("NO EXIT"); Tone(1,0.35,60); SendToServerConsole("say NO EXIT"); }
    else { Center("NO EXIT"); S.c1_safe = 1; Tone(2,0.5,55); }
}
function Chapter2TrainSilhouette() { S.c2_train = 1; SpawnWalkerSilhouette(); Say("unknown passenger crossed track"); Tone(1,0.45,60); }
function Chapter2LightEvent()
{
    S.c2_light = 1;
    Center("LIGHT SOURCE REJECTED");
    EpiText("THIS IS NOT THE WAY", 0.22, 0.45, 3.6);
    GlitchHard(4.5);
    Tone(2,0.9,55);
    SpinBots();
    ThrowProps(6, 900, 520);
    Delay(Chapter2TeleportOutside, 3.2);
}
function Chapter2TeleportOutside() { if (!PLAYER) return; PLAYER.SetOrigin(PLAYER.GetOrigin() + Vector(500, 0, 120)); Cmd("fadein 0",0); Say("position restored"); }
function Chapter3ErrorsBegin()
{
    S.c3_error = 1;
    SpawnErrorModels();
    SpawnDistantPeople();
    Say("missing models accepted");
    Center("MODEL TABLE DAMAGED");
    Glitch(1.0);
    NEXT_AMBIENT = Time() + 5;
}
function Chapter3SafeRush() { S.c3_safe = 1; Center("RUN"); SpawnWatcher(160, 2.0, true); GlitchHard(1.2); Tone(2,0.8,55); }
function Chapter3SchizoA()
{
    S.c3_hallu_a = 1;
    Center("INPUT NOT RECORDED");
    Cmd("cl_drawhud 0", 0.0);
    GlitchHard(1.4);
    Delay(RestoreHud, 1.6);
    SpawnDistantPeople();
}

function RestoreHud()
{
    Cmd("cl_drawhud 1", 0.0);
}

function Chapter3SchizoB()
{
    S.c3_hallu_b = 1;
    EpiText("DO YOU HEAR IT", 0.28, 0.48, 2.8);
    Tone(4, 0.55, 55);
    ScreenShake(PLAYER.GetOrigin(), 10, 7, 1.8, 180, 0, true);
    SpawnWatcher(520, 5.0, true);
}

function Chapter4EntityBegins()
{
    S.c4_chase = 1;
    Say("observer now has movement permission");
    Center("RUN");
    SpawnWitness(360, true);
    NEXT_WITNESS = Time() + 4.0;
}

function Chapter4Elevator()
{
    S.c4_elevator = 1; Cmd("cl_drawhud 0",0); Cmd("fadeout 0",0); Tone(3,0.8,90);
    EpiText("NO WAY BACK",0.20,0.22,4.0); EpiText("I AM DEAD",0.25,0.38,4.0); EpiText("HELP ME",0.31,0.54,4.0); EpiText("NOTHING HERE IS REAL",0.16,0.70,4.0); EpiText("IT WAITS",0.38,0.84,4.0);
    Delay(Chapter4AfterElevator,4.5);
}
function Chapter4AfterElevator() { if (!PLAYER) return; PLAYER.SetOrigin(PLAYER.GetOrigin() + Vector(600,0,120)); Cmd("fadein 0",0); Cmd("cl_drawhud 1",0); SpawnWitness(260,true); }

// ---------- BOSS ----------
function StartBossFight()
{
    BOSS_ACTIVE = true; BOSS_PHASE = 1; BOSS_START = Time(); BOSS_SHOTS_AT_LAST = S.shots; S.c5_radio = 1;
    Center("SURVIVE"); Say("boss entity instantiated"); GlitchHard(2.0); Tone(2,0.9,55); SpawnBoss();
}
function SpawnBoss()
{
    KillNamed("e404_boss"); local pos = Around(RandomFloat(520,720), true);
    BOSS = SpawnEntityFromTable("prop_dynamic_override", { targetname="e404_boss", model="models/infected/witch.mdl", solid=0, origin=pos });
    Blacken(BOSS, 1.8); NEXT_BOSS_MOVE <- Time() + 0.25;
}
function BossThink()
{
    if (!PLAYER) return; local elapsed = Time() - BOSS_START;
    if (elapsed > 115) { BossWin(); return; }
    if (elapsed > 70 && BOSS_PHASE < 3) { BOSS_PHASE = 3; Say("dead population restored"); MutationOptions.CommonLimit = 24; SendToServerConsole("director_start"); }
    else if (elapsed > 35 && BOSS_PHASE < 2) { BOSS_PHASE = 2; Say("multiple entities detected"); SpawnWatcher(300,6,false); SpawnWatcher(350,6,true); }
    if (!BOSS || !BOSS.IsValid()) { if (Time() > BOSS_NEXT_SPAWN) SpawnBoss(); return; }
    if (Time() > BOSS_NEXT_MOVE) { MoveBossTowardPlayer(); BOSS_NEXT_MOVE = Time() + 0.18; }
    if ((BOSS.GetOrigin() - PLAYER.GetOrigin()).Length() < 90) BossFail();
}
function BossShotCheck()
{
    if (!BOSS_ACTIVE) return;
    if (S.shots - BOSS_SHOTS_AT_LAST >= 5) { BOSS_SHOTS_AT_LAST = S.shots; if (BOSS) BOSS.Kill(); BOSS = null; BOSS_NEXT_SPAWN = Time() + RandomFloat(2.0,4.0); Tone(0,0.6,70); }
}
function MoveBossTowardPlayer()
{
    local dir = PLAYER.GetOrigin() - BOSS.GetOrigin(); local len = dir.Length(); if (len <= 0) return; dir = dir.Scale(1.0/len);
    BOSS.SetOrigin(BOSS.GetOrigin() + dir.Scale(55 + BOSS_PHASE * 18));
}
function BossWin() { BOSS_ACTIVE = false; if (BOSS) BOSS.Kill(); BOSS=null; Center("RESCUE AVAILABLE"); Say("all systems normal"); Tone(0,0.35,80); Delay(FakeRescue,8.0); }
function BossFail() { BOSS_ACTIVE = false; S.deaths++; Center("YOU WERE RECORDED"); GlitchHard(4.0); Tone(2,1.0,50); Delay(RestartChapter,4.0); }
function RestartChapter() { SendToServerConsole("restart"); }
function FakeRescue() { if (!VOID_STARTED) VoidStart(); }

function SpawnEyes(distance, lifetime)
{
    if (!PLAYER) return;
    local eyeBase = Around(distance, true);
    local e1 = SpawnEntityFromTable("env_sprite", {
        targetname = "e404_eyes",
        model = "sprites/glow01.vmt",
        origin = eyeBase + Vector(-8, 0, 54),
        scale = 0.18,
        rendermode = 9,
        rendercolor = "255 0 0"
    });
    local e2 = SpawnEntityFromTable("env_sprite", {
        targetname = "e404_eyes",
        model = "sprites/glow01.vmt",
        origin = eyeBase + Vector(8, 0, 54),
        scale = 0.18,
        rendermode = 9,
        rendercolor = "255 0 0"
    });
    DoEntFire("!self", "ShowSprite", "", 0.0, null, e1);
    DoEntFire("!self", "ShowSprite", "", 0.0, null, e2);
    DoEntFire("!self", "Kill", "", lifetime, null, e1);
    DoEntFire("!self", "Kill", "", lifetime, null, e2);
}

function SpawnCorruptCompanion()
{
    if (!PLAYER) return;
    KillNamed("e404_companion");
    local e = SpawnEntityFromTable("prop_dynamic_override", {
        targetname = "e404_companion",
        model = SurvivorModel(),
        solid = 0,
        origin = PLAYER.GetOrigin() + Vector(95, 35, 8)
    });
    Blacken(e, 1.08);
    CORRUPT_COMPANION = e;
    DoEntFire("!self", "Kill", "", 35.0, null, e);
}

// ---------- WORLD ----------
function SparseWorld(common)
{
    MutationOptions.CommonLimit = common;
    MutationOptions.MegaMobSize = common;
    MutationOptions.MobSpawnSize = common;
    SendToServerConsole("director_no_specials 1");
    SendToServerConsole("director_no_bosses 1");
}
function RemoveOneBot()
{
    S.botloss++;
    if (S.botloss == 1) {
        SendToServerConsole("kick Bill");
        ClientPrint(null, HUD_PRINTTALK, "Bill disconnected");
    } else if (S.botloss == 2) {
        SendToServerConsole("kick Louis");
        SendToServerConsole("kick Francis");
        ClientPrint(null, HUD_PRINTTALK, "Louis disconnected");
    } else {
        SendToServerConsole("kick Zoey");
        SendToServerConsole("kick Coach");
    }
}
function BlackenBots() { Say("last companion render data corrupted"); }
function BotBoneBreak()
{
    Center("COMPANION SKELETON FAILED");
    Tone(1,0.7,60);
    SendToServerConsole("kick Zoey");
    SendToServerConsole("kick Francis");
    SendToServerConsole("kick Louis");
    SendToServerConsole("kick Bill");
    SendToServerConsole("kick Coach");
    SendToServerConsole("kick Ellis");
    SendToServerConsole("kick Rochelle");
    SendToServerConsole("kick Nick");
}
function SpinBots() { SendToServerConsole("nb_stop 1"); Delay(UnstopBots, 4.0); }
function UnstopBots() { SendToServerConsole("nb_stop 0"); }
function SpawnWalkerSilhouette() { SpawnWatcher(500,2.2,true); Delay(SpawnWalkerSilhouette2,0.6); }
function SpawnWalkerSilhouette2() { SpawnWatcher(420,1.5,true); }
function SpawnDistantPeople() { SpawnWatcher(700,8,true); SpawnWatcher(830,8,true); }
function SpawnErrorModels() { for(local i=0;i<4;i++) SpawnEntityFromTable("prop_dynamic_override", { targetname="e404_error", model="models/error404/missing.mdl", solid=0, origin=PLAYER.GetOrigin()+Vector(RandomFloat(-450,450),RandomFloat(-450,450),20) }); }
function AmbientThink() { if (CHAPTER >= 3 && Time() > NEXT_AMBIENT) { Tone(4,0.25,60); ScreenShake(PLAYER.GetOrigin(),5,3,0.8,140,0,true); NEXT_AMBIENT = Time()+RandomFloat(24,48); } }
function MapFracture() { Say("map transform differs from recording"); Glitch(0.6); ThrowProps(5,760,420); NEXT_FRACTURE=Time()+RandomFloat(45,90); }
function FractureThink() { if (STATE != "CORRUPT" && STATE != "ALONE") return; if (Time() > NEXT_FRACTURE) MapFracture(); }

function ThrowProps(count, radius, force)
{
    local n=0; n+=ThrowClass("prop_physics",count-n,radius,force); if(n<count)n+=ThrowClass("prop_physics_multiplayer",count-n,radius,force); if(n<count)n+=ThrowClass("prop_physics_override",count-n,radius,force);
}
function ThrowClass(cls,count,radius,force)
{
    if(count<=0 || !PLAYER)return 0; local e=null; local n=0;
    while(e=Entities.FindByClassnameWithin(e,cls,PLAYER.GetOrigin(),radius)){ if(n>=count)break; local v=Vector(RandomFloat(-force,force),RandomFloat(-force,force),RandomFloat(force*0.3,force*0.9)); try{e.ApplyAbsVelocityImpulse(v);}catch(err){e.SetOrigin(e.GetOrigin()+Vector(RandomFloat(-20,20),RandomFloat(-20,20),RandomFloat(0,25)));} n++; }
    return n;
}

// ---------- VISUAL ----------
function Glitch(d) { Cmd("mat_grain_scale_override 18",0); Cmd("mat_grain_scale_override 1",d); }
function GlitchHard(d)
{
    Cmd("mat_grain_scale_override 60",0); Cmd("r_screenoverlay 4ded",0); Cmd("soundfade 100 1 0 1",0); Cmd("host_timescale 0.45",0.05); Cmd("host_timescale 1",d); Cmd("mat_grain_scale_override 1",d); Cmd("r_screenoverlay \"\"",d);
    ScreenShake(PLAYER.GetOrigin(),25,22,d,260,0,true);
}
function EpiText(t,x,y,d) { DebugDrawScreenTextLine(x,y,0,t,255,40,40,255,d); DebugDrawScreenTextLine(x+0.01,y+0.01,1,t,255,255,255,140,d); }

// ---------- ENTITIES ----------
function SpawnWitness(distance,front) { KillNamed("e404_witness"); WITNESS=SpawnEntityFromTable("prop_dynamic_override",{targetname="e404_witness",model="models/infected/smoker.mdl",solid=0,origin=Around(distance,front)}); Blacken(WITNESS,1.25); }
function WitnessThink()
{
    if (!PLAYER) return;

    if (!WITNESS || !WITNESS.IsValid()) {
        if (Time() > NEXT_WITNESS) {
            SpawnWitness(520, false);
            NEXT_WITNESS = Time() + 24;
        }
        return;
    }

    local dist = (WITNESS.GetOrigin() - PLAYER.GetOrigin()).Length();
    if (dist < 85) {
        WitnessTouch();
        return;
    }

    if (Time() > NEXT_WITNESS) {
        WITNESS.SetOrigin(Around(RandomFloat(220, 380), false));
        NEXT_WITNESS = Time() + RandomFloat(14, 24);
    }
}
function WitnessTouch(){Say("observer contact");GlitchHard(1.0);if(WITNESS)WITNESS.Kill();WITNESS=null;NEXT_WITNESS=Time()+18;}
function SpawnWatcher(distance, lifetime, front)
{
    local e = SpawnEntityFromTable("prop_dynamic_override", {
        targetname = "e404_watcher",
        model = SurvivorModel(),
        solid = 0,
        origin = Around(distance, front)
    });
    Blacken(e, RandomFloat(1.05, 1.3));
    DoEntFire("!self", "Kill", "", lifetime, null, e);
}
function SurvivorModel(){local r=RandomInt(0,5); if(r==0)return "models/survivors/survivor_namvet.mdl"; if(r==1)return "models/survivors/survivor_biker.mdl"; if(r==2)return "models/survivors/survivor_teenangst.mdl"; if(r==3)return "models/survivors/survivor_manager.mdl"; if(r==4)return "models/survivors/survivor_coach.mdl"; return "models/survivors/survivor_gambler.mdl";}
function Blacken(e,scale){if(!e)return;try{NetProps.SetPropFloat(e,"m_flModelScale",scale);}catch(err){} e.__KeyValueFromString("rendercolor","0 0 0"); e.__KeyValueFromString("renderamt","255");}
function Around(distance,front){local yaw=PLAYER.EyeAngles().y; if(front)yaw+=RandomFloat(-28,28);else yaw+=RandomFloat(125,235); local r=yaw*3.14159/180.0; local p=PLAYER.GetOrigin(); return Vector(p.x+cos(r)*distance,p.y+sin(r)*distance,p.z+8);}

// ---------- VOID ----------
function VoidStart(){ if(VOID_STARTED||!PLAYER)return; VOID_STARTED=true; STATE="VOID"; Say("exit route not found"); Cmd("fadeout 0",0); SendToServerConsole("director_stop; nb_delete_all"); Delay(VoidStage,1.5); }
function VoidStage(){ PLAYER.SetOrigin(PLAYER.GetOrigin()+Vector(0,0,2200)); Cmd("cl_drawhud 0",0); Center("N O   E X I T"); Tone(2,0.6,55); for(local i=0;i<8;i++) SpawnWatcher(260+i*20,8,false); Delay(VoidEnd,7.0); }
function VoidEnd(){ EpiText("NO EXIT",0.38,0.45,1.2); GlitchHard(1.2); Tone(2,0.8,55); Delay(ExitGame,1.4); }
function ExitGame(){ Cmd("exit",0.01); }

function Notebook(){ ClientPrint(null,HUD_PRINTTALK,"ERROR 404 LOST BUILD / STATE: "+STATE+" / CHAPTER: "+CHAPTER); ClientPrint(null,HUD_PRINTTALK,"SHOTS: "+S.shots+" LOOKBACKS: "+S.lookbacks+" DEATHS: "+S.deaths); }

ApplyRules();
