ERROR 404: BLACKBOX FULL

Это полноценная переработка на базе идей Alone / Psychological Horror Single Player Mode.
Теперь это mutation + VScript director, а не SourceMod-спам.

Запуск:
1. Распакуй архив.
2. Запусти INSTALL_ERROR404_FULL.bat или INSTALL.bat.
3. Установщик запускает: map c8m1_apartment error404

Ручной запуск:
map c8m1_apartment error404

Что добавлено в FULL:
- BlackboxMemory с сохранением через SaveTable/RestoreTable.
- Команды через scripted_user_func:
  blackbox  - открыть запись BLACKBOX RECORD;
  hands     - опустить оружие / перейти на fists-baseball_bat и бежать быстрее;
  armed     - вернуть обычную скорость;
  bbquiet   - снизить интенсивность;
  bbintense - повысить интенсивность;
  giveup    - безопасно выйти.
- TV contact system: телевизор рядом с игроком запускает сцены и меняет skins.
- Map-specific сцены:
  c8m1: map checksum mismatch;
  c8m2: NEXT TRAIN: NEVER;
  c8m3: audio recovered from water;
  c8m4: PATIENT: YOU;
  c8m5: rescue entity missing / helicopter path null.
- Safe room progression: первая safe room спокойная, затем всё хуже.
- WITNESS использует smoker.mdl. Если установлен Morphic Spectacular - Horror Smoker, он станет высоким чёрным силуэтом.
- Fists/baseball_bat из Alone First включён в пакет.
- TV model/materials из Psychological Horror Single Player Mode включены в пакет.
- Sparse map fracture: редкая, но сильная поломка карты — physics props летят, двери двигаются, props поворачиваются.
- Void finale с NO EXIT и exit.

Важно:
- Это VScript, не SourceMod. Поэтому не нужен spcomp.
- Если в консоли нет строки ERROR 404: BLACKBOX FULL script loaded v0.2.0 — режим не загрузился.
- Если будет SCRIPT ERROR, пришли строку ошибки и номер строки.

Workshop-идеи:
- Morphic Spectacular - Horror Smoker: используем smoker.mdl как тело WITNESS.
- Alone: используем mutation/VScript/Memory/TV/safe-room подход.


Hotfix launchfix:
- Установщик теперь копирует файлы и в left4dead2 root, и в left4dead2/addons/error404_blackbox как unpacked addon.
- Запуск теперь идет через cfg/error404_start.cfg, где команда выполняется именно как консольная: map c8m1_apartment error404.
- Если всё равно не загрузилось, вручную в главном меню/консоли введи: exec error404_start.cfg или map c8m1_apartment error404.


Hotfix 0.2.1:
- Исправлен SCRIPT ERROR wrong number of parameters в FacePlayer(): SetAngles теперь вызывается одним Vector-параметром.
- Исправлен такой же риск в RotateNearbyStatics().
- Во время VOID больше не печатается idle-memory сообщение.


Hotfix 0.2.2:
- Исправлен QAngle argument expected: SetAngles теперь получает QAngle(0, yaw, 0), а не Vector.
- Это должно убрать бесконечный спам ошибок FacePlayer / UpdateWitness.
