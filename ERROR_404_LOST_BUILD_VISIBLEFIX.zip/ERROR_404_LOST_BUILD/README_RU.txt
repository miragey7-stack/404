ERROR 404: LOST BUILD — CLEAN

Полностью без SourceMod/MetaMod. Это чистый Workshop-ready VScript mutation.

Установка для теста:
1. Скопируй папку addons/error404_lost_build в Left 4 Dead 2/left4dead2/addons/
2. Запусти игру.
3. В консоли: map c8m1_apartment error404

Установщик INSTALL.bat делает это автоматически.

Проверка загрузки:
В консоли должны быть строки:
ERROR 404 LOST BUILD CLEAN loaded v0.1.0
ERROR404_CLEAN_ACTIVE

Что принципиально убрано:
- SourceMod, MetaMod, DLL, SMX, SP.
- Кастомные runtime-звуки.
- SetAngles/QAngle/FacePlayer.
- TV/сложные ассеты.
- Спам сообщений.

Что есть:
- 1 сцена на карту No Mercy.
- WITNESS как smoker.mdl без поворотов модели.
- Редкие watcher-силуэты.
- Редкий map fracture: только prop_physics и свет/зерно.
- Safe room progression.
- Void finale.

Это стабильная основа, на которую потом можно наращивать сцены.


LINEAR 0.2.0:
- Переписана под линейный сценарий по твоему описанию.
- Добавлены сильные glitch/flash/text эффекты по мотивам Alone: mat_grain, r_screenoverlay, host_timescale, DebugDrawScreenTextLine, soundfade, shake.
- Глава 1: улица, freeze camera, глаза/наблюдатель, NO EXIT на safe door.
- Глава 2: потеря бота, замедление игрока, поезд-силуэт, light event.
- Глава 3: зомби исчезают, tank sounds, ERROR-модели, дальние люди.
- Глава 4: одиночество, entity chase, elevator text scene.
- Глава 5: radio boss fight prototype, phases, win/fail, void/exit.
- Предупреждение: flashing lights / screen distortion / photosensitivity.


Launchfix 0.2.1:
- Установщик теперь копирует mutation и как unpacked addon, и напрямую в left4dead2/modes + left4dead2/scripts/vscripts.
- Запуск теперь через cfg/error404_lost_build_start.cfg: map c8m1_apartment error404.
- Если нет строки ERROR 404 LOST BUILD LINEAR loaded v0.2.1, вручную введи в консоли: exec error404_lost_build_start.cfg


Hotfix 0.2.2:
- Исправлена синтаксическая ошибка в WitnessThink line 337: функция переписана многострочно без рискованных inline if/else.
- SpawnWatcher тоже переписан безопаснее.


Hotfix 0.2.3:
- maxplayers в mutation изменён на 4, чтобы в первой главе могли быть survivor-боты.
- При запуске первой главы сбрасывается память сцен, чтобы тесты не пропускали события из-за SaveTable.
- Установщик удаляет старые root fallback scripts/vscripts/error404.nut и modes/error404.txt перед копированием.
- Сцена первой главы запускается раньше и длится дольше.
- Добавлена команда e404reset для сброса памяти сцен.
