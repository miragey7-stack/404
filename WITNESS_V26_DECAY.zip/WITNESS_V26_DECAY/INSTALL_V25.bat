@echo off
call "%~dp0INSTALL_V26_DECAY.bat"
