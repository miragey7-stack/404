#pragma semicolon 1
#pragma newdecls required

#include <sourcemod>
#include <sdktools>
#include <sdkhooks>

#define PLUGIN_VERSION "1.0.0-blackbox"
#define INVALID_FLAGS -1
#define IN_ATTACK_BIT (1 << 0)

static const char SURV_MODELS[][] = {
    "models/survivors/survivor_namvet.mdl",
    "models/survivors/survivor_biker.mdl",
    "models/survivors/survivor_teenangst.mdl",
    "models/survivors/survivor_manager.mdl",
    "models/survivors/survivor_coach.mdl",
    "models/survivors/survivor_gambler.mdl"
};

enum Phase {
    B_Init = 0,
    B_Normal,
    B_Observed,
    B_Isolated,
    B_Blackbox,
    B_Void
};

public Plugin myinfo = {
    name = "ERROR 404: BLACKBOX",
    author = "NELIXO concept, Arena.ai implementation",
    description = "Slow-burn haunted cartridge director for L4D2 No Mercy",
    version = PLUGIN_VERSION
};

Phase g_Phase = B_Init;
bool g_bActive = false;
bool g_bDirectorStopped = false;
bool g_bIsolationStarted = false;
bool g_bSafeRoomUsed = false;
bool g_bEngineCaptured = false;

char g_sMap[64];
int g_iChapter = 1;
int g_iWitnessRef = INVALID_ENT_REFERENCE;
int g_iLookBackCount[MAXPLAYERS + 1];
int g_iShotsFired[MAXPLAYERS + 1];
float g_fSpawnOrigin[MAXPLAYERS + 1][3];
float g_fLastYaw[MAXPLAYERS + 1];
float g_fLastPos[MAXPLAYERS + 1][3];
float g_fIdleSince[MAXPLAYERS + 1];

bool g_bSceneDone[10];
float g_fNextStalkerMove = 0.0;
float g_fNextMapFracture = 0.0;
float g_fNextBlackboxLine = 0.0;
float g_fNextWatcher = 0.0;
float g_fNextLookPunish = 0.0;

ConVar g_cvEnable;
ConVar g_cvIntensity;
ConVar g_cvNoMercyOnly;
ConVar g_cvFinaleExit;
ConVar g_cvDebug;
ConVar g_cvTimeScale;
ConVar g_cvGravity;
ConVar g_cvGameMode;

float g_fOldTimeScale = 1.0;
float g_fOldGravity = 800.0;
int g_iOldTimeScaleFlags = INVALID_FLAGS;
int g_iOldGravityFlags = INVALID_FLAGS;
int g_iOldOverlayFlags = INVALID_FLAGS;
int g_iOldDirectorStopFlags = INVALID_FLAGS;
int g_iOldDirectorStartFlags = INVALID_FLAGS;

Handle g_hMainTimer = null;
Handle g_hPurgeTimer = null;
ArrayList g_hSpawnedRefs = null;

public void OnPluginStart() {
    g_cvEnable = CreateConVar("blackbox_enable", "1", "Enable ERROR 404: BLACKBOX.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    g_cvIntensity = CreateConVar("blackbox_intensity", "2", "1 quiet, 2 slow-burn, 3 stronger map fractures, 4 aggressive.", FCVAR_NOTIFY, true, 1.0, true, 4.0);
    g_cvNoMercyOnly = CreateConVar("blackbox_nomercy_only", "1", "Run only on c8m* No Mercy maps.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    g_cvFinaleExit = CreateConVar("blackbox_finale_exit", "1", "Final fake crash: send client exit command.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    g_cvDebug = CreateConVar("blackbox_debug", "0", "Debug logs.", FCVAR_NOTIFY, true, 0.0, true, 1.0);
    AutoExecConfig(true, "error404_blackbox");

    HookEvent("round_start", Event_RoundStart, EventHookMode_PostNoCopy);
    HookEvent("player_spawn", Event_PlayerSpawn, EventHookMode_Post);
    HookEvent("door_close", Event_DoorClose, EventHookMode_Post);
    HookEvent("weapon_fire", Event_WeaponFire, EventHookMode_Post);
    HookEntityOutput("func_button", "OnPressed", OnButtonPressed);

    g_cvTimeScale = FindConVar("host_timescale");
    g_cvGravity = FindConVar("sv_gravity");
    g_cvGameMode = FindConVar("mp_gamemode");

    CaptureEngineState();
    RelaxFlags();

    g_hSpawnedRefs = new ArrayList();
    g_hMainTimer = CreateTimer(0.25, Timer_MainLoop, _, TIMER_REPEAT);
    g_hPurgeTimer = CreateTimer(0.75, Timer_PurgeWorld, _, TIMER_REPEAT);

    LogMessage("ERROR 404: BLACKBOX loaded.");
}

public void OnPluginEnd() {
    g_bActive = false;
    g_hMainTimer = null;
    g_hPurgeTimer = null;
    CleanupSpawnedEntities();
    ResetEngine(true);
    if (g_hSpawnedRefs != null) {
        delete g_hSpawnedRefs;
        g_hSpawnedRefs = null;
    }
}

public void OnMapStart() {
    GetCurrentMap(g_sMap, sizeof(g_sMap));
    g_iChapter = ParseChapter(g_sMap);
    g_bActive = ShouldRun();

    g_Phase = B_Init;
    g_bIsolationStarted = false;
    g_bSafeRoomUsed = false;
    g_bDirectorStopped = false;
    g_iWitnessRef = INVALID_ENT_REFERENCE;
    g_fNextStalkerMove = 0.0;
    g_fNextMapFracture = 0.0;
    g_fNextBlackboxLine = 0.0;
    g_fNextWatcher = 0.0;
    g_fNextLookPunish = 0.0;

    for (int i = 0; i < sizeof(g_bSceneDone); i++) {
        g_bSceneDone[i] = false;
    }
    for (int c = 1; c <= MaxClients; c++) {
        g_iLookBackCount[c] = 0;
        g_iShotsFired[c] = 0;
        g_fLastYaw[c] = 0.0;
        g_fIdleSince[c] = 0.0;
    }

    PrecacheAll();
    if (g_bActive) {
        ResetEngine(false);
        Debug("active on %s chapter %d", g_sMap, g_iChapter);
    }
}

public void OnMapEnd() {
    g_bActive = false;
    CleanupSpawnedEntities();
    ResetEngine(false);
}

public void OnClientPutInServer(int client) {
    SDKHook(client, SDKHook_OnTakeDamage, OnTakeDamage);
}

public Action OnTakeDamage(int victim, int &attacker, int &inflictor, float &damage, int &damagetype) {
    if (g_bActive && g_Phase >= B_Isolated && IsValidSurvivor(victim) && (damagetype & DMG_FALL)) {
        damage = 0.0;
        return Plugin_Handled;
    }
    return Plugin_Continue;
}

public Action OnPlayerRunCmd(int client, int &buttons, int &impulse, float vel[3], float angles[3], int &weapon, int &subtype, int &cmdnum, int &tickcount, int &seed, int mouse[2]) {
    if (!g_bActive || g_Phase < B_Isolated || !IsValidSurvivor(client) || IsFakeClient(client)) {
        return Plugin_Continue;
    }

    if ((buttons & IN_ATTACK_BIT) && g_iShotsFired[client] > 0 && (g_iShotsFired[client] % 24) == 0 && GetRandomInt(0, 100) < 18) {
        buttons &= ~IN_ATTACK_BIT;
        PrintHintText(client, "BLACKBOX: firearm response delayed");
        PlayTone(client, 2, 0.55);
        return Plugin_Changed;
    }
    return Plugin_Continue;
}

public void Event_RoundStart(Event event, const char[] name, bool dontBroadcast) {
    g_bActive = ShouldRun();
    g_Phase = B_Init;
    g_bIsolationStarted = false;
    g_bSafeRoomUsed = false;
    CleanupSpawnedEntities();
    ResetEngine(false);
}

public void Event_PlayerSpawn(Event event, const char[] name, bool dontBroadcast) {
    if (!g_bActive) {
        return;
    }

    int client = GetClientOfUserId(event.GetInt("userid"));
    if (!IsValidSurvivor(client) || IsFakeClient(client)) {
        return;
    }

    GetClientAbsOrigin(client, g_fSpawnOrigin[client]);
    GetClientAbsOrigin(client, g_fLastPos[client]);
    float a[3];
    GetClientEyeAngles(client, a);
    g_fLastYaw[client] = a[1];
    g_fIdleSince[client] = GetGameTime();

    if (g_Phase == B_Init) {
        g_Phase = B_Normal;
        CreateTimer(8.0, Timer_FirstBlackboxLine, GetClientUserId(client), TIMER_FLAG_NO_MAPCHANGE);
        if (g_iChapter >= 2) {
            CreateTimer(3.5, Timer_BeginIsolation, GetClientUserId(client), TIMER_FLAG_NO_MAPCHANGE);
        }
    }
}

public void Event_WeaponFire(Event event, const char[] name, bool dontBroadcast) {
    int client = GetClientOfUserId(event.GetInt("userid"));
    if (IsValidSurvivor(client) && !IsFakeClient(client)) {
        g_iShotsFired[client]++;
    }
}

public void Event_DoorClose(Event event, const char[] name, bool dontBroadcast) {
    if (!g_bActive || !event.GetBool("checkpoint") || g_iChapter >= 5 || g_bSafeRoomUsed) {
        return;
    }

    int p = GetPrimaryPlayer();
    if (p <= 0 || g_Phase < B_Isolated) {
        return;
    }

    g_bSafeRoomUsed = true;
    SceneSafeRoomProgression(p);
}

public void OnButtonPressed(const char[] output, int caller, int activator, float delay) {
    if (!g_bActive || g_Phase == B_Void || !IsValidSurvivor(activator) || IsFakeClient(activator)) {
        return;
    }

    if (g_iChapter >= 5 && IsNoMercyMap(g_sMap)) {
        TriggerVoid(activator);
    }
}

public void OnEntityCreated(int entity, const char[] classname) {
    if (!g_bActive || g_Phase < B_Isolated) {
        return;
    }

    if (StrEqual(classname, "infected") || StrEqual(classname, "witch")) {
        RequestFrame(Frame_RemoveEntity, EntIndexToEntRef(entity));
    }
}

public void Frame_RemoveEntity(any ref) {
    int ent = EntRefToEntIndex(ref);
    if (ent > MaxClients && IsValidEntity(ent)) {
        RemoveEntity(ent);
    }
}

public Action Timer_MainLoop(Handle timer) {
    if (!g_bActive) {
        return Plugin_Continue;
    }

    int p = GetPrimaryPlayer();
    if (p <= 0) {
        return Plugin_Continue;
    }

    float now = GetGameTime();
    UpdateMemory(p, now);

    if (g_Phase == B_Normal) {
        UpdateNormalPhase(p, now);
    } else if (g_Phase >= B_Isolated && g_Phase < B_Void) {
        UpdateWitness(p, now);
        UpdateMapDirector(p, now);
    } else if (g_Phase == B_Void) {
        PrintCenterText(p, "N O   E X I T");
    }

    return Plugin_Continue;
}

public Action Timer_PurgeWorld(Handle timer) {
    if (!g_bActive || g_Phase < B_Isolated) {
        return Plugin_Continue;
    }

    RemoveClassEntities("infected");
    RemoveClassEntities("witch");
    for (int i = 1; i <= MaxClients; i++) {
        if (IsClientInGame(i) && IsFakeClient(i) && GetClientTeam(i) == 3 && IsPlayerAlive(i)) {
            ForcePlayerSuicide(i);
        }
    }
    return Plugin_Continue;
}

public Action Timer_FirstBlackboxLine(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (g_bActive && IsValidSurvivor(p) && g_Phase == B_Normal) {
        Blackbox(p, "recording started");
        PlayTone(p, 0, 0.25);
    }
    return Plugin_Stop;
}

public Action Timer_BeginIsolation(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (g_bActive && IsValidSurvivor(p) && !g_bIsolationStarted) {
        BeginIsolation(p);
    }
    return Plugin_Stop;
}

void UpdateNormalPhase(int p, float now) {
    float pos[3];
    GetClientAbsOrigin(p, pos);
    float dist = GetVectorDistance(g_fSpawnOrigin[p], pos);

    if (g_iChapter == 1 && dist > 800.0 && !g_bSceneDone[1]) {
        g_bSceneDone[1] = true;
        g_Phase = B_Observed;
        SceneC8M1Checksum(p);
    }

    if (dist > 1850.0 && !g_bIsolationStarted) {
        BeginIsolation(p);
    }
}

void BeginIsolation(int p) {
    if (g_bIsolationStarted || !IsValidSurvivor(p)) {
        return;
    }

    g_bIsolationStarted = true;
    g_Phase = B_Isolated;
    StopDirector();
    SetDarkness();

    Blackbox(p, "companions removed by request");
    PlayTone(p, 1, 0.6);
    FadeClient(p, 0, 0, 0, 210, 250, 900, 0x0001);
    StageBotsForDeletion(p);
    CreateTimer(1.0, Timer_DeleteSurvivorBots, _, TIMER_FLAG_NO_MAPCHANGE);
    CreateTimer(1.4, Timer_PostIsolation, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
}

public Action Timer_PostIsolation(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (g_bActive && IsValidSurvivor(p)) {
        PrintToChat(p, "\x01Bill disconnected");
        PrintToChat(p, "\x01Zoey disconnected");
        PrintToChat(p, "\x01Francis disconnected");
        SpawnWitness(p, 650.0, true);
        g_Phase = B_Blackbox;
        g_fNextMapFracture = GetGameTime() + GetRandomFloat(35.0, 70.0);
        g_fNextBlackboxLine = GetGameTime() + GetRandomFloat(45.0, 80.0);
        g_fNextWatcher = GetGameTime() + GetRandomFloat(25.0, 45.0);
    }
    return Plugin_Stop;
}

void StageBotsForDeletion(int p) {
    float ppos[3];
    GetClientAbsOrigin(p, ppos);

    for (int i = 1; i <= MaxClients; i++) {
        if (!IsClientInGame(i) || !IsFakeClient(i) || GetClientTeam(i) != 2 || !IsPlayerAlive(i)) {
            continue;
        }
        SetEntityMoveType(i, MOVETYPE_NONE);
        SetEntityRenderMode(i, RENDER_TRANSCOLOR);
        SetEntityRenderColor(i, 0, 0, 0, 255);
        float bpos[3], dir[3], ang[3];
        GetClientAbsOrigin(i, bpos);
        MakeVectorFromPoints(bpos, ppos, dir);
        GetVectorAngles(dir, ang);
        ang[0] = 0.0;
        ang[2] = 0.0;
        TeleportEntity(i, NULL_VECTOR, ang, NULL_VECTOR);
    }
}

public Action Timer_DeleteSurvivorBots(Handle timer) {
    for (int i = 1; i <= MaxClients; i++) {
        if (IsClientInGame(i) && IsFakeClient(i) && GetClientTeam(i) == 2) {
            KickClient(i, "blackbox erased companion");
        }
    }
    return Plugin_Stop;
}

void UpdateMemory(int p, float now) {
    float pos[3];
    GetClientAbsOrigin(p, pos);

    if (GetVectorDistance(pos, g_fLastPos[p]) > 32.0) {
        g_fLastPos[p][0] = pos[0];
        g_fLastPos[p][1] = pos[1];
        g_fLastPos[p][2] = pos[2];
        g_fIdleSince[p] = now;
    } else if (now - g_fIdleSince[p] > 28.0 && now > g_fNextBlackboxLine) {
        Blackbox(p, "subject waiting for instruction");
        g_fNextBlackboxLine = now + 70.0;
    }

    float ang[3];
    GetClientEyeAngles(p, ang);
    float delta = FloatAbs(AngleDiff(ang[1], g_fLastYaw[p]));
    if (delta > 140.0) {
        g_iLookBackCount[p]++;
        if ((g_iLookBackCount[p] % 6) == 0 && now > g_fNextBlackboxLine) {
            Blackbox(p, "subject repeatedly checks behind");
            g_fNextBlackboxLine = now + 75.0;
        }
    }
    g_fLastYaw[p] = ang[1];
}

void UpdateMapDirector(int p, float now) {
    if (g_iChapter == 2 && !g_bSceneDone[2]) {
        g_bSceneDone[2] = true;
        SceneC8M2TrainNever(p);
        g_fNextMapFracture = now + 45.0;
        return;
    }
    if (g_iChapter == 3 && !g_bSceneDone[3]) {
        g_bSceneDone[3] = true;
        SceneC8M3WaterMemory(p);
        g_fNextMapFracture = now + 40.0;
        return;
    }
    if (g_iChapter == 4 && !g_bSceneDone[4]) {
        g_bSceneDone[4] = true;
        SceneC8M4PatientYou(p);
        g_fNextMapFracture = now + 40.0;
        return;
    }
    if (g_iChapter == 5 && !g_bSceneDone[5]) {
        g_bSceneDone[5] = true;
        SceneC8M5RescueMissing(p);
        g_fNextMapFracture = now + 25.0;
        return;
    }

    if (now > g_fNextMapFracture) {
        SceneMapFracture(p);
        float minDelay = (g_iChapter >= 3) ? 55.0 : 80.0;
        float maxDelay = (g_iChapter >= 3) ? 105.0 : 145.0;
        if (GetIntensity() >= 3) {
            minDelay *= 0.65;
            maxDelay *= 0.75;
        }
        g_fNextMapFracture = now + GetRandomFloat(minDelay, maxDelay);
    }

    if (now > g_fNextWatcher) {
        SpawnWatcher(p, GetRandomFloat(240.0, 620.0), GetRandomFloat(5.0, 9.0), GetRandomInt(0, 1) == 1);
        g_fNextWatcher = now + GetRandomFloat(42.0, 85.0);
    }
}

void UpdateWitness(int p, float now) {
    int ent = EntRefToEntIndex(g_iWitnessRef);
    if (ent == INVALID_ENT_REFERENCE || !IsValidEntity(ent)) {
        if (now > g_fNextStalkerMove) {
            SpawnWitness(p, 520.0, false);
            g_fNextStalkerMove = now + 8.0;
        }
        return;
    }

    float epos[3], ppos[3], dir[3], ang[3];
    GetEntPropVector(ent, Prop_Data, "m_vecAbsOrigin", epos);
    GetClientAbsOrigin(p, ppos);
    MakeVectorFromPoints(epos, ppos, dir);
    dir[2] = 0.0;
    NormalizeVector(dir, dir);
    GetVectorAngles(dir, ang);
    ang[0] = 0.0;
    ang[2] = 0.0;
    TeleportEntity(ent, NULL_VECTOR, ang, NULL_VECTOR);

    bool looking = IsPlayerLookingAtPoint(p, epos, 0.45);
    float dist = GetVectorDistance(epos, ppos);

    if (looking) {
        if (g_cvTimeScale != null) {
            g_cvTimeScale.FloatValue = 0.55;
        }
        if (now > g_fNextLookPunish) {
            PrintHintText(p, "BLACKBOX: observer acknowledged");
            PlayTone(p, 2, 0.45);
            g_fNextLookPunish = now + 18.0;
        }
    } else {
        RestoreLookEffect(p);
        if (now > g_fNextStalkerMove) {
            MoveWitnessNear(p, ent, GetRandomFloat(180.0, 360.0));
            g_fNextStalkerMove = now + GetRandomFloat(8.0, 16.0) - float(GetIntensity());
        }
    }

    if (dist < 85.0) {
        WitnessTouch(p, ent, dir);
    }
}

void SceneC8M1Checksum(int p) {
    Blackbox(p, "map checksum mismatch");
    PlayTone(p, 0, 0.35);
    SpawnWatcher(p, 700.0, 6.0, true);
    SetLightStyle(0, "b");
    CreateTimer(1.4, Timer_RestoreLight, _, TIMER_FLAG_NO_MAPCHANGE);
}

void SceneC8M2TrainNever(int p) {
    PrintCenterText(p, "NEXT TRAIN: NEVER");
    Blackbox(p, "platform schedule missing");
    ScreenShake(p, 8.0, 4.0, 1.3);
    PlayTone(p, 1, 0.5);
    SpawnWatcher(p, 560.0, 7.0, true);
    CreateTimer(1.4, Timer_SecondWatcher, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
}

void SceneC8M3WaterMemory(int p) {
    Blackbox(p, "audio recovered from water");
    PlayTone(p, 1, 0.55);
    ScreenShake(p, 7.0, 5.0, 1.5);
    ThrowNearbyPhysics(p, 2, 520.0, 260.0);
}

void SceneC8M4PatientYou(int p) {
    PrintCenterText(p, "PATIENT: YOU");
    PrintToChat(p, "\x01Zoey: don't let it wear my face");
    PlayTone(p, 2, 0.5);
    SpawnHangingBody(p, 5.0);
}

void SceneC8M5RescueMissing(int p) {
    Blackbox(p, "rescue entity missing");
    Blackbox(p, "helicopter path null");
    PlayTone(p, 1, 0.65);
    SpawnWatcher(p, 280.0, 10.0, true);
    SpawnWatcher(p, 320.0, 10.0, false);
}

void SceneSafeRoomProgression(int p) {
    if (g_iChapter <= 2) {
        Blackbox(p, "safe room hypothesis rejected");
        PlayTone(p, 0, 0.35);
    } else {
        PrintCenterText(p, "SAFE ROOM IS A LIE");
        PlayTone(p, 2, 0.55);
        ScreenShake(p, 18.0, 12.0, 2.0);
        SpawnWatcher(p, 110.0, 4.0, false);
        SpawnWatcher(p, 140.0, 4.0, true);
    }
}

public Action Timer_SecondWatcher(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (IsValidSurvivor(p)) {
        SpawnWatcher(p, 220.0, 4.0, false);
    }
    return Plugin_Stop;
}

void SceneMapFracture(int p) {
    // Stronger map break, but sparse. Mostly physics and doors, not vital logic entities.
    if (GetRandomInt(0, 100) < 65) {
        PrintHintText(p, "the map moved while you were inside it");
    }
    if (GetRandomInt(0, 1) == 1) SetLightStyle(0, "a"); else SetLightStyle(0, "c");
    CreateTimer(0.9, Timer_RestoreLight, _, TIMER_FLAG_NO_MAPCHANGE);

    ThrowNearbyPhysics(p, 4 + GetIntensity(), 700.0, 420.0);
    CorruptNearbyStatics(p, 5, 850.0);
    NudgeNearbyDoors(p, 700.0);
    PlayTone(p, 1, 0.45);
}

void TriggerVoid(int p) {
    if (!IsValidSurvivor(p) || g_Phase == B_Void) {
        return;
    }

    g_Phase = B_Void;
    CleanupSpawnedEntities();
    StopDirector();
    Blackbox(p, "exit route not found");
    FadeClient(p, 0, 0, 0, 255, 300, 1400, 0x0001);
    CreateTimer(1.4, Timer_VoidStage1, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
}

public Action Timer_VoidStage1(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (!IsValidSurvivor(p)) {
        return Plugin_Stop;
    }

    float pos[3];
    GetClientAbsOrigin(p, pos);
    pos[2] += 2200.0;
    RemoveWeaponsFromSlot(p, 0);
    RemoveWeaponsFromSlot(p, 1);
    RemoveWeaponsFromSlot(p, 2);
    SetEntityMoveType(p, MOVETYPE_NONE);
    TeleportEntity(p, pos, NULL_VECTOR, NULL_VECTOR);
    SetDarkness();

    for (int i = 0; i < 8; i++) {
        SpawnVoidWatcher(pos, i);
    }
    PrintCenterText(p, "N O   E X I T");
    PlayTone(p, 2, 0.65);
    CreateTimer(7.0, Timer_VoidFinale, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    return Plugin_Stop;
}

public Action Timer_VoidFinale(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (!IsValidSurvivor(p)) {
        return Plugin_Stop;
    }

    ShowOverlay(p, "witness_v25/scream_face", 0.8);
    ScreenShake(p, 45.0, 35.0, 1.6);
    PlayTone(p, 2, 0.8);
    if (g_cvFinaleExit != null && g_cvFinaleExit.BoolValue) {
        CreateTimer(1.0, Timer_ExitGame, GetClientUserId(p), TIMER_FLAG_NO_MAPCHANGE);
    }
    return Plugin_Stop;
}

public Action Timer_ExitGame(Handle timer, any userid) {
    int p = GetClientOfUserId(userid);
    if (p > 0 && IsClientInGame(p) && g_Phase == B_Void) {
        ClientCommand(p, "exit");
    }
    return Plugin_Stop;
}

public Action Timer_RestoreLight(Handle timer) {
    if (g_bActive && g_Phase >= B_Isolated) {
        SetDarkness();
    } else {
        SetLightStyle(0, "m");
    }
    return Plugin_Stop;
}

void SpawnWitness(int p, float distance, bool inFront) {
    float ppos[3], pang[3];
    GetClientAbsOrigin(p, ppos);
    GetClientEyeAngles(p, pang);

    float yaw = pang[1] + (inFront ? GetRandomFloat(-28.0, 28.0) : GetRandomFloat(135.0, 225.0));
    float rad = yaw * FLOAT_PI / 180.0;
    float pos[3];
    pos[0] = ppos[0] + Cosine(rad) * distance;
    pos[1] = ppos[1] + Sine(rad) * distance;
    pos[2] = ppos[2] + 8.0;

    int e = CreateEntityByName("prop_dynamic_override");
    if (e == -1) {
        return;
    }
    // If the player subscribes to Morphic Spectacular - Horror Smoker, this becomes the black tall body.
    DispatchKeyValue(e, "model", "models/infected/smoker.mdl");
    DispatchKeyValue(e, "targetname", "error404_witness_body");
    DispatchKeyValue(e, "solid", "0");
    DispatchSpawn(e);
    TrackEntity(e);
    ApplyBlackSilhouette(e, 1.25);

    float d[3], a[3];
    MakeVectorFromPoints(pos, ppos, d);
    GetVectorAngles(d, a);
    a[0] = 0.0;
    a[2] = 0.0;
    TeleportEntity(e, pos, a, NULL_VECTOR);
    g_iWitnessRef = EntIndexToEntRef(e);
}

void MoveWitnessNear(int p, int ent, float distance) {
    float ppos[3], pang[3];
    GetClientAbsOrigin(p, ppos);
    GetClientEyeAngles(p, pang);
    float yaw = pang[1] + GetRandomFloat(110.0, 250.0);
    float rad = yaw * FLOAT_PI / 180.0;
    float pos[3];
    pos[0] = ppos[0] + Cosine(rad) * distance;
    pos[1] = ppos[1] + Sine(rad) * distance;
    pos[2] = ppos[2] + 8.0;
    TeleportEntity(ent, pos, NULL_VECTOR, NULL_VECTOR);
    PlayTone(p, 0, 0.25);
}

void WitnessTouch(int p, int ent, const float dir[3]) {
    PrintHintText(p, "BLACKBOX: observer contact");
    ShowOverlay(p, "witness_v25/tv_noise", 0.35);
    ScreenShake(p, 22.0, 18.0, 1.3);
    PlayTone(p, 2, 0.55);

    float vel[3];
    vel[0] = dir[0] * 850.0;
    vel[1] = dir[1] * 850.0;
    vel[2] = 220.0;
    TeleportEntity(p, NULL_VECTOR, NULL_VECTOR, vel);

    RemoveEntity(ent);
    g_iWitnessRef = INVALID_ENT_REFERENCE;
    g_fNextStalkerMove = GetGameTime() + 16.0;
}

void SpawnWatcher(int p, float distance, float lifetime, bool inFront) {
    float ppos[3], pang[3];
    GetClientAbsOrigin(p, ppos);
    GetClientEyeAngles(p, pang);

    float yaw = pang[1] + (inFront ? GetRandomFloat(-35.0, 35.0) : GetRandomFloat(120.0, 240.0));
    float rad = yaw * FLOAT_PI / 180.0;
    float pos[3];
    pos[0] = ppos[0] + Cosine(rad) * distance;
    pos[1] = ppos[1] + Sine(rad) * distance;
    pos[2] = ppos[2] + 4.0;

    int e = CreateEntityByName("prop_dynamic_override");
    if (e == -1) {
        return;
    }
    DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS) - 1)]);
    DispatchKeyValue(e, "targetname", "error404_memory_watcher");
    DispatchKeyValue(e, "solid", "0");
    DispatchSpawn(e);
    TrackEntity(e);
    ApplyBlackSilhouette(e, GetRandomFloat(1.05, 1.28));

    float d[3], a[3];
    MakeVectorFromPoints(pos, ppos, d);
    GetVectorAngles(d, a);
    a[0] = 0.0;
    a[2] = 0.0;
    TeleportEntity(e, pos, a, NULL_VECTOR);
    CreateTimer(lifetime, Timer_DeleteEntity, EntIndexToEntRef(e), TIMER_FLAG_NO_MAPCHANGE);
}

void SpawnHangingBody(int p, float lifetime) {
    float ppos[3];
    GetClientAbsOrigin(p, ppos);
    float pos[3];
    pos[0] = ppos[0] + GetRandomFloat(-90.0, 90.0);
    pos[1] = ppos[1] + GetRandomFloat(-90.0, 90.0);
    pos[2] = ppos[2] + 185.0;

    int e = CreateEntityByName("prop_dynamic_override");
    if (e == -1) {
        return;
    }
    DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS) - 1)]);
    DispatchKeyValue(e, "targetname", "error404_hanging_memory");
    DispatchKeyValue(e, "solid", "0");
    DispatchSpawn(e);
    TrackEntity(e);
    ApplyBlackSilhouette(e, 1.18);

    float a[3];
    a[0] = 180.0;
    a[1] = GetRandomFloat(0.0, 360.0);
    a[2] = 0.0;
    TeleportEntity(e, pos, a, NULL_VECTOR);
    CreateTimer(lifetime, Timer_DeleteEntity, EntIndexToEntRef(e), TIMER_FLAG_NO_MAPCHANGE);
}

void SpawnVoidWatcher(float center[3], int index) {
    float yaw = float(index) * 45.0 * FLOAT_PI / 180.0;
    float pos[3];
    pos[0] = center[0] + Cosine(yaw) * 250.0;
    pos[1] = center[1] + Sine(yaw) * 250.0;
    pos[2] = center[2] + GetRandomFloat(-35.0, 65.0);

    int e = CreateEntityByName("prop_dynamic_override");
    if (e == -1) {
        return;
    }
    DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS) - 1)]);
    DispatchKeyValue(e, "solid", "0");
    DispatchSpawn(e);
    TrackEntity(e);
    ApplyBlackSilhouette(e, 1.35);
    TeleportEntity(e, pos, NULL_VECTOR, NULL_VECTOR);
}

public Action Timer_DeleteEntity(Handle timer, any ref) {
    int e = EntRefToEntIndex(ref);
    if (e != INVALID_ENT_REFERENCE && e > MaxClients && IsValidEntity(e)) {
        RemoveEntity(e);
    }
    return Plugin_Stop;
}

void ApplyBlackSilhouette(int entity, float scale) {
    SetEntityRenderMode(entity, RENDER_TRANSCOLOR);
    SetEntityRenderColor(entity, 0, 0, 0, 255);
    SetEntPropFloat(entity, Prop_Send, "m_flModelScale", scale);
    SetEntProp(entity, Prop_Send, "m_nSequence", 0);
    SetEntPropFloat(entity, Prop_Send, "m_flPlaybackRate", 0.0);
}

void ThrowNearbyPhysics(int p, int count, float radius, float force) {
    int thrown = 0;
    thrown += ThrowPhysicsClass(p, "prop_physics", count - thrown, radius, force);
    if (thrown < count) thrown += ThrowPhysicsClass(p, "prop_physics_multiplayer", count - thrown, radius, force);
    if (thrown < count) thrown += ThrowPhysicsClass(p, "prop_physics_override", count - thrown, radius, force);
}

int ThrowPhysicsClass(int p, const char[] classname, int count, float radius, float force) {
    if (count <= 0) {
        return 0;
    }

    float ppos[3];
    GetClientAbsOrigin(p, ppos);
    int candidates[48];
    int total = 0;
    int ent = -1;

    while ((ent = FindEntityByClassname(ent, classname)) != -1) {
        if (total >= sizeof(candidates)) {
            break;
        }
        if (ent <= MaxClients || !IsValidEntity(ent)) {
            continue;
        }
        float epos[3];
        GetEntPropVector(ent, Prop_Data, "m_vecAbsOrigin", epos);
        if (GetVectorDistance(ppos, epos) <= radius) {
            candidates[total++] = ent;
        }
    }

    int thrown = 0;
    for (int i = 0; i < count && total > 0; i++) {
        int pick = GetRandomInt(0, total - 1);
        int e = candidates[pick];
        candidates[pick] = candidates[total - 1];
        total--;

        float vel[3];
        vel[0] = GetRandomFloat(-force, force);
        vel[1] = GetRandomFloat(-force, force);
        vel[2] = GetRandomFloat(force * 0.35, force * 0.85);
        TeleportEntity(e, NULL_VECTOR, NULL_VECTOR, vel);
        thrown++;
    }
    return thrown;
}

void CorruptNearbyStatics(int p, int count, float radius) {
    float ppos[3];
    GetClientAbsOrigin(p, ppos);
    int changed = 0;
    int ent = -1;

    while ((ent = FindEntityByClassname(ent, "prop_dynamic")) != -1) {
        if (changed >= count) {
            break;
        }
        if (ent <= MaxClients || !IsValidEntity(ent)) {
            continue;
        }
        float epos[3];
        GetEntPropVector(ent, Prop_Data, "m_vecAbsOrigin", epos);
        if (GetVectorDistance(ppos, epos) > radius) {
            continue;
        }

        float ang[3];
        GetEntPropVector(ent, Prop_Data, "m_angRotation", ang);
        ang[1] += GetRandomFloat(-28.0, 28.0);
        TeleportEntity(ent, NULL_VECTOR, ang, NULL_VECTOR);
        changed++;
    }
}

void NudgeNearbyDoors(int p, float radius) {
    float ppos[3];
    GetClientAbsOrigin(p, ppos);
    NudgeDoorClass(ppos, "prop_door_rotating", radius);
    NudgeDoorClass(ppos, "func_door", radius);
    NudgeDoorClass(ppos, "func_door_rotating", radius);
}

void NudgeDoorClass(float ppos[3], const char[] classname, float radius) {
    int ent = -1;
    int touched = 0;
    while ((ent = FindEntityByClassname(ent, classname)) != -1) {
        if (touched >= 2) {
            break;
        }
        if (ent <= MaxClients || !IsValidEntity(ent)) {
            continue;
        }
        float epos[3];
        GetEntPropVector(ent, Prop_Data, "m_vecAbsOrigin", epos);
        if (GetVectorDistance(ppos, epos) > radius) {
            continue;
        }
        if (GetRandomInt(0, 1) == 1) {
            AcceptEntityInput(ent, "Open");
        } else {
            AcceptEntityInput(ent, "Close");
        }
        touched++;
    }
}

void PlayTone(int client, int type, float volume) {
    if (!IsValidSurvivor(client)) {
        return;
    }

    if (type == 0) {
        EmitSoundToClient(client, "ambient/energy/zap1.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, volume, 70);
    } else if (type == 1) {
        EmitSoundToClient(client, "ambient/atmosphere/cave_hit5.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, volume, 60);
    } else {
        EmitSoundToClient(client, "ambient/ambience/rainscapes/Thunder_close01.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, volume, 55);
    }
}

void Blackbox(int client, const char[] line) {
    if (!IsValidSurvivor(client)) {
        return;
    }
    PrintToChat(client, "\x01BLACKBOX: %s", line);
}

void ShowOverlay(int client, const char[] overlay, float duration) {
    if (!IsValidSurvivor(client)) {
        return;
    }
    ClientCommand(client, "r_screenoverlay \"%s\"", overlay);
    if (duration < 900.0) {
        DataPack pack = new DataPack();
        pack.WriteCell(GetClientUserId(client));
        CreateTimer(duration, Timer_RemoveOverlay, pack, TIMER_DATA_HNDL_CLOSE | TIMER_FLAG_NO_MAPCHANGE);
    }
}

public Action Timer_RemoveOverlay(Handle timer, DataPack pack) {
    pack.Reset();
    int c = GetClientOfUserId(pack.ReadCell());
    if (IsValidSurvivor(c)) {
        ClientCommand(c, "r_screenoverlay \"\"");
    }
    return Plugin_Stop;
}

void ScreenShake(int client, float amp, float freq, float duration) {
    Handle msg = StartMessageOne("Shake", client);
    if (msg == null) {
        return;
    }
    BfWriteByte(msg, 0);
    BfWriteFloat(msg, amp);
    BfWriteFloat(msg, freq);
    BfWriteFloat(msg, duration);
    EndMessage();
}

void FadeClient(int client, int r, int g, int b, int a, int fadeIn, int fadeOut, int flags) {
    Handle msg = StartMessageOne("Fade", client);
    if (msg == null) {
        return;
    }
    BfWriteShort(msg, fadeIn);
    BfWriteShort(msg, fadeOut);
    BfWriteShort(msg, flags);
    BfWriteByte(msg, r);
    BfWriteByte(msg, g);
    BfWriteByte(msg, b);
    BfWriteByte(msg, a);
    EndMessage();
}

void PrecacheAll() {
    PrecacheModel("models/infected/smoker.mdl", true);
    for (int i = 0; i < sizeof(SURV_MODELS); i++) {
        PrecacheModel(SURV_MODELS[i], true);
    }
    PrecacheSound("ambient/energy/zap1.wav", true);
    PrecacheSound("ambient/atmosphere/cave_hit5.wav", true);
    PrecacheSound("ambient/ambience/rainscapes/Thunder_close01.wav", true);

    AddFileToDownloadsTable("materials/witness_v25/scream_face.vtf");
    AddFileToDownloadsTable("materials/witness_v25/scream_face.vmt");
    AddFileToDownloadsTable("materials/witness_v25/tv_noise.vtf");
    AddFileToDownloadsTable("materials/witness_v25/tv_noise.vmt");
}

void CaptureEngineState() {
    if (g_bEngineCaptured) {
        return;
    }
    if (g_cvTimeScale != null) {
        g_fOldTimeScale = g_cvTimeScale.FloatValue;
        g_iOldTimeScaleFlags = g_cvTimeScale.Flags;
    }
    if (g_cvGravity != null) {
        g_fOldGravity = g_cvGravity.FloatValue;
        g_iOldGravityFlags = g_cvGravity.Flags;
    }
    g_iOldOverlayFlags = GetCommandFlags("r_screenoverlay");
    g_iOldDirectorStopFlags = GetCommandFlags("director_stop");
    g_iOldDirectorStartFlags = GetCommandFlags("director_start");
    g_bEngineCaptured = true;
}

void RelaxFlags() {
    if (g_cvTimeScale != null) {
        g_cvTimeScale.Flags = g_cvTimeScale.Flags & ~FCVAR_CHEAT;
    }
    if (g_cvGravity != null) {
        g_cvGravity.Flags = g_cvGravity.Flags & ~FCVAR_CHEAT;
    }
    int flags = GetCommandFlags("r_screenoverlay");
    if (flags != INVALID_FLAGS) {
        SetCommandFlags("r_screenoverlay", flags & ~FCVAR_CHEAT);
    }
    flags = GetCommandFlags("director_stop");
    if (flags != INVALID_FLAGS) {
        SetCommandFlags("director_stop", flags & ~FCVAR_CHEAT);
    }
    flags = GetCommandFlags("director_start");
    if (flags != INVALID_FLAGS) {
        SetCommandFlags("director_start", flags & ~FCVAR_CHEAT);
    }
}

void ResetEngine(bool restoreFlags) {
    if (g_cvTimeScale != null) {
        g_cvTimeScale.FloatValue = g_fOldTimeScale;
        if (restoreFlags && g_iOldTimeScaleFlags != INVALID_FLAGS) {
            g_cvTimeScale.Flags = g_iOldTimeScaleFlags;
        }
    }
    if (g_cvGravity != null) {
        g_cvGravity.FloatValue = g_fOldGravity;
        if (restoreFlags && g_iOldGravityFlags != INVALID_FLAGS) {
            g_cvGravity.Flags = g_iOldGravityFlags;
        }
    }

    if (restoreFlags) {
        if (g_iOldOverlayFlags != INVALID_FLAGS) SetCommandFlags("r_screenoverlay", g_iOldOverlayFlags);
        if (g_iOldDirectorStopFlags != INVALID_FLAGS) SetCommandFlags("director_stop", g_iOldDirectorStopFlags);
        if (g_iOldDirectorStartFlags != INVALID_FLAGS) SetCommandFlags("director_start", g_iOldDirectorStartFlags);
    }

    SetLightStyle(0, "m");
    if (g_bDirectorStopped) {
        ServerCommand("director_start");
        g_bDirectorStopped = false;
    }

    for (int i = 1; i <= MaxClients; i++) {
        if (!IsClientInGame(i) || IsFakeClient(i)) {
            continue;
        }
        SetEntProp(i, Prop_Send, "m_iDefaultFOV", 90);
        SetEntityMoveType(i, MOVETYPE_WALK);
        ClientCommand(i, "r_screenoverlay \"\"");
        float a[3];
        GetClientEyeAngles(i, a);
        a[2] = 0.0;
        TeleportEntity(i, NULL_VECTOR, a, NULL_VECTOR);
    }
}

void RestoreLookEffect(int client) {
    if (g_cvTimeScale != null) {
        g_cvTimeScale.FloatValue = g_fOldTimeScale;
    }
    if (IsValidSurvivor(client)) {
        SetEntProp(client, Prop_Send, "m_iDefaultFOV", 90);
    }
}

void SetDarkness() {
    SetLightStyle(0, "a");
}

void StopDirector() {
    if (!g_bDirectorStopped) {
        ServerCommand("director_stop");
        g_bDirectorStopped = true;
    }
}

void CleanupSpawnedEntities() {
    int w = EntRefToEntIndex(g_iWitnessRef);
    if (w != INVALID_ENT_REFERENCE && w > MaxClients && IsValidEntity(w)) {
        RemoveEntity(w);
    }
    g_iWitnessRef = INVALID_ENT_REFERENCE;

    if (g_hSpawnedRefs == null) {
        return;
    }
    for (int i = 0; i < g_hSpawnedRefs.Length; i++) {
        int e = EntRefToEntIndex(g_hSpawnedRefs.Get(i));
        if (e != INVALID_ENT_REFERENCE && e > MaxClients && IsValidEntity(e)) {
            RemoveEntity(e);
        }
    }
    g_hSpawnedRefs.Clear();
}

void TrackEntity(int entity) {
    if (g_hSpawnedRefs != null && entity > MaxClients && IsValidEntity(entity)) {
        g_hSpawnedRefs.Push(EntIndexToEntRef(entity));
    }
}

void RemoveClassEntities(const char[] classname) {
    int ent = -1;
    while ((ent = FindEntityByClassname(ent, classname)) != -1) {
        if (ent > MaxClients && IsValidEntity(ent)) {
            RemoveEntity(ent);
        }
    }
}

void RemoveWeaponsFromSlot(int client, int slot) {
    for (int i = 0; i < 8; i++) {
        int w = GetPlayerWeaponSlot(client, slot);
        if (w == -1 || !IsValidEntity(w)) {
            break;
        }
        RemovePlayerItem(client, w);
        RemoveEntity(w);
    }
}

bool ShouldRun() {
    if (g_cvEnable == null || !g_cvEnable.BoolValue) {
        return false;
    }
    if (g_cvNoMercyOnly != null && g_cvNoMercyOnly.BoolValue && !IsNoMercyMap(g_sMap)) {
        return false;
    }
    if (g_cvGameMode == null) {
        return true;
    }
    char mode[32];
    g_cvGameMode.GetString(mode, sizeof(mode));
    return StrEqual(mode, "coop", false) || StrEqual(mode, "realism", false) || StrEqual(mode, "singleplayer", false);
}

bool IsNoMercyMap(const char[] map) {
    return StrContains(map, "c8m", false) == 0;
}

int ParseChapter(const char[] map) {
    int len = strlen(map);
    for (int i = 0; i < len - 1; i++) {
        if (map[i] == 'm' && map[0] == 'c') {
            int c = map[i + 1] - '0';
            if (c >= 1 && c <= 5) {
                return c;
            }
        }
    }
    return 1;
}

int GetIntensity() {
    if (g_cvIntensity == null) {
        return 2;
    }
    int v = g_cvIntensity.IntValue;
    if (v < 1) return 1;
    if (v > 4) return 4;
    return v;
}

bool IsValidSurvivor(int client) {
    return client > 0 && client <= MaxClients && IsClientInGame(client) && IsPlayerAlive(client) && GetClientTeam(client) == 2;
}

int GetPrimaryPlayer() {
    for (int i = 1; i <= MaxClients; i++) {
        if (IsValidSurvivor(i) && !IsFakeClient(i)) {
            return i;
        }
    }
    return 0;
}

bool IsPlayerLookingAtPoint(int client, const float point[3], float threshold) {
    float eye[3], angles[3], fwd[3], target[3], adjusted[3];
    GetClientEyePosition(client, eye);
    GetClientEyeAngles(client, angles);
    GetAngleVectors(angles, fwd, NULL_VECTOR, NULL_VECTOR);
    adjusted[0] = point[0];
    adjusted[1] = point[1];
    adjusted[2] = point[2] + 40.0;
    MakeVectorFromPoints(eye, adjusted, target);
    NormalizeVector(target, target);
    if (GetVectorDotProduct(fwd, target) <= threshold) {
        return false;
    }
    TR_TraceRayFilter(eye, adjusted, MASK_SOLID, RayType_EndPoint, TraceFilterVisible, client);
    return !TR_DidHit();
}

public bool TraceFilterVisible(int entity, int contentsMask, any data) {
    if (entity > 0 && entity <= MaxClients) {
        return false;
    }
    if (entity > MaxClients && IsValidEntity(entity)) {
        char classname[64];
        GetEntityClassname(entity, classname, sizeof(classname));
        if (StrEqual(classname, "prop_dynamic") || StrEqual(classname, "prop_dynamic_override")) {
            return false;
        }
    }
    return true;
}

float AngleDiff(float a, float b) {
    float d = a - b;
    while (d > 180.0) d -= 360.0;
    while (d < -180.0) d += 360.0;
    return d;
}

void Debug(const char[] fmt, any ...) {
    if (g_cvDebug == null || !g_cvDebug.BoolValue) {
        return;
    }
    char buffer[256];
    VFormat(buffer, sizeof(buffer), fmt, 2);
    PrintToServer("[BLACKBOX] %s", buffer);
    LogMessage("[BLACKBOX] %s", buffer);
}
