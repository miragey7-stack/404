@echo off
call "%~dp0INSTALL_BLACKBOX.bat"
