ERROR 404: BLACKBOX

Это новая переработка, а не продолжение V29/V31.
Цель: убрать скучный спам и сделать slow-burn haunted cartridge director.

Что изменено:
- Никакого custom sound spam через SourceMod.
- Никаких постоянных WITNESS joined / material table каждые 5 секунд.
- Никакой агрессивной долбежки по умолчанию.
- 1 уникальная режиссёрская сцена на каждую карту No Mercy.
- Более сильная поломка карты, но редко: physics props бросаются, двери рядом могут открываться/закрываться, prop_dynamic слегка поворачиваются.
- Главный аватар WITNESS теперь использует smoker.mdl. Если подписаться на Morphic Spectacular - Horror Smoker, он станет высоким черным силуэтом.
- Survivor-модели больше не ломаются через scale/bodygroups.

Фазы:
- c8m1: checksum mismatch, первый наблюдатель.
- c8m2: изоляция, удаление спутников, NEXT TRAIN: NEVER.
- c8m3: water memory / трубы и вода помнят голоса.
- c8m4: PATIENT: YOU.
- c8m5: rescue entity missing / Void.

ConVars:
- blackbox_enable 1/0
- blackbox_intensity 1-4, по умолчанию 2
- blackbox_nomercy_only 1/0
- blackbox_finale_exit 1/0
- blackbox_debug 1/0

Рекомендуемые Workshop-моды, НЕ включены в архив:
- Morphic Spectacular - Horror Smoker: https://steamcommunity.com/sharedfiles/filedetails/?id=1166632254
- Alone - Psychological Horror Single Player Mode: https://steamcommunity.com/sharedfiles/filedetails/?id=2908453385
- Witch Whispers: https://steamcommunity.com/sharedfiles/filedetails/?id=3357951800
- Wendigo Scream (horde): https://steamcommunity.com/sharedfiles/filedetails/?id=3357948344
- RIFT - Theme: https://steamcommunity.com/sharedfiles/filedetails/?id=3357960798
- Horror ReShade: https://steamcommunity.com/sharedfiles/filedetails/?id=3369615712

Важно:
Workshop-файлы не перепакованы в этот ZIP. Подписывайся на них отдельно, если хочешь усилить звук/модель/визуал.

Установка:
1. Распакуй архив.
2. Запусти INSTALL_BLACKBOX.bat.
3. Проверь в консоли игры:
   sm plugins info witness_core

Должно быть:
ERROR 404: BLACKBOX
1.0.0-blackbox
