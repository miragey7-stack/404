@echo off
setlocal EnableExtensions EnableDelayedExpansion
color 0C
title ERROR 404 - BLACKBOX Installer

set "GAME="
if exist "D:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=D:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "E:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=E:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME set /p "GAME=Paste the folder containing left4dead2.exe: "
set "GAME=%GAME:"=%"
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%"

if not exist "%GAME%\left4dead2.exe" (
    echo ERROR: left4dead2.exe was not found.
    pause
    exit /b 1
)

set "SRC=%~dp0WITNESS_FILES"
set "DST=%GAME%\left4dead2"
set "SP=%DST%\addons\sourcemod\scripting\witness_core.sp"
set "SMX=%DST%\addons\sourcemod\plugins\witness_core.smx"
set "SMX_TMP=%TEMP%\blackbox_compile.smx"
set "COMPILE_LOG=%TEMP%\blackbox_compile.log"
set "SPCOMP=%DST%\addons\sourcemod\scripting\spcomp.exe"
set "SMZIP=%TEMP%\sourcemod-1.12.0-git7246-windows.zip"
set "SMTMP=%TEMP%\blackbox_sourcemod"
set "SMURL=https://github.com/alliedmodders/sourcemod/releases/download/1.12.0.7246/sourcemod-1.12.0-git7246-windows.zip"

echo.
echo ============================================================
echo  ERROR 404: BLACKBOX
echo  Clean slow-burn director. No sound spam. No random chaos spam.
echo ============================================================
echo Installing to: %DST%
echo.

if not exist "%DST%\addons\sourcemod\plugins" mkdir "%DST%\addons\sourcemod\plugins"
if not exist "%DST%\addons\sourcemod\scripting" mkdir "%DST%\addons\sourcemod\scripting"

echo Copying BLACKBOX payload...
xcopy "%SRC%\*" "%DST%\" /E /I /H /R /Y /Q >NUL

if not exist "%DST%\addons\sourcemod\plugins\disabled" mkdir "%DST%\addons\sourcemod\plugins\disabled"
if exist "%DST%\addons\sourcemod\plugins\nextmap.smx" move /Y "%DST%\addons\sourcemod\plugins\nextmap.smx" "%DST%\addons\sourcemod\plugins\disabled\nextmap.smx.disabled" >NUL
if exist "%DST%\addons\sourcemod\plugins\updater.smx" move /Y "%DST%\addons\sourcemod\plugins\updater.smx" "%DST%\addons\sourcemod\plugins\disabled\updater.smx.disabled" >NUL

if not exist "%SPCOMP%" (
    echo spcomp.exe was not found. Downloading official SourceMod compiler/runtime...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%SMURL%' -OutFile '%SMZIP%' -UseBasicParsing; exit 0 } catch { exit 1 }"
    if not errorlevel 1 (
        if exist "%SMTMP%" rmdir /S /Q "%SMTMP%"
        mkdir "%SMTMP%"
        powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%SMZIP%' -DestinationPath '%SMTMP%' -Force"
        if exist "%SMTMP%\addons\sourcemod\scripting" xcopy "%SMTMP%\addons\sourcemod\scripting\*" "%DST%\addons\sourcemod\scripting\" /E /I /H /R /Y /Q >NUL
        if exist "%SMTMP%\addons\sourcemod\extensions" xcopy "%SMTMP%\addons\sourcemod\extensions\*" "%DST%\addons\sourcemod\extensions\" /E /I /H /R /Y /Q >NUL
        if exist "%SMTMP%\addons\sourcemod\gamedata" xcopy "%SMTMP%\addons\sourcemod\gamedata\*" "%DST%\addons\sourcemod\gamedata\" /E /I /H /R /Y /Q >NUL
    )
)

if exist "%SPCOMP%" (
    if exist "%SMX_TMP%" del /Q "%SMX_TMP%"
    echo Compiling BLACKBOX plugin...
    "%SPCOMP%" "%SP%" -o"%SMX_TMP%" > "%COMPILE_LOG%" 2>&1
    if errorlevel 1 (
        color 0E
        echo.
        echo ERROR: witness_core.sp compilation failed.
        echo Existing witness_core.smx was NOT deleted.
        echo Compile log:
        type "%COMPILE_LOG%"
        echo.
        pause
    ) else (
        copy /Y "%SMX_TMP%" "%SMX%" >NUL
        echo Compiled successfully: %SMX%
    )
) else (
    color 0E
    echo WARNING: spcomp.exe missing. Existing witness_core.smx was NOT deleted.
    pause
)

echo.
echo Launching No Mercy...
timeout /t 2 /nobreak >NUL
start "" "%GAME%\left4dead2.exe" -insecure -console -windowed -noborder +sv_consistency 0 +map c8m1_apartment coop
endlocal
