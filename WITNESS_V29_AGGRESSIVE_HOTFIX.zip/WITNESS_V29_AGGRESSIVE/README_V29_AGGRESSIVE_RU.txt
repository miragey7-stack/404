ERROR 404: WITNESS V29.1 AGGRESSIVE HAUNTING

Эта версия сделана после твоего фидбека: V28 была рабочей, но слишком мягкой, а новые звуки почти не ощущались; V29.1 исправляет custom sound path через */ и убирает битые VTF.

Главные изменения V29:

1. Звуки стали заметнее
- Добавлен PlayHorrorSound(): звук теперь идет через EmitSoundToClient и дополнительно через client command play.
- Это сделано специально, чтобы custom WAV были слышны в локальной игре, а не терялись как тихий 3D-звук.
- SNDLEVEL поднят до очень высокого уровня.

2. Новые V29 звуки
- voice_not_alone.wav
- voice_look_at_me.wav
- voice_wrong_way.wav
- voice_no_exit.wav
- door_pound.wav
- body_drop.wav
- witch_laugh_low.wav
- heartbeat_low.wav

3. Сцены стали намного чаще
- Добавлен ConVar witness_intensity, по умолчанию 4.
- 1 = атмосферно, 4 = агрессивно.
- После изоляции сцены идут намного чаще.
- c8m3/c8m4 становятся гораздо более плотными.
- c8m5 почти постоянно давит событиями.

4. Ведьма стала активнее
- WitchSpecialAction вызывается значительно чаще.
- Ведьма может требовать LOOK AT ME.
- Может прыгать ближе перед игроком.
- Может запускать цепочки possession-сцен.
- Может вызывать голос, смех, глаза, face overlays.

5. Добавлены цепочки сцен
- SceneObjectPossessionChain: карта трогает предметы серией, потом face frame и body drop.
- SceneWitchDemand: ведьма требует смотреть на нее и появляется ближе.
- ScenePanicFrames: серия коротких horror-кадров.
- SceneRouteBlocked: WRONG WAY, голос и силуэты вокруг.

6. Старые V28 сцены оставлены, но усилены
- Behind теперь громче.
- Wrong Survivor громче.
- Old Build громче.
- DoorKnock заменен на более жесткий door_pound.
- MapHand чаще бросает предметы.

7. Body horror без комичного бага одежды
- Сильное ломание survivor-моделей не возвращал.
- В V29 фокус на силуэты, резкие кадры, звуки костей, подвешенные тела и постановку.
- Без кастомных .mdl нормальное вытягивание конечностей невозможно сделать стабильно.

Установка:
1. Распакуй архив.
2. Запусти INSTALL_V29_AGGRESSIVE.bat или INSTALL_V29.bat.
3. Установщик скопирует файлы, отключит nextmap/updater, скомпилирует witness_core.sp и запустит No Mercy.

Проверка:
sm plugins info witness_core

Должно быть:
ERROR 404: WITNESS V29.1 AGGRESSIVE HAUNTING
29.1.0-sound-vtf-hotfix

Если всё еще мало — в консоли:
witness_intensity 4

Финальный exit сохранен.
