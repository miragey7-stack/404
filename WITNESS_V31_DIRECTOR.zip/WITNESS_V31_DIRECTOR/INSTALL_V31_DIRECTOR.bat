@echo off
setlocal EnableExtensions EnableDelayedExpansion
color 0C
title ERROR 404 - WITNESS V31 DIRECTOR Installer

set "GAME="
if exist "D:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=D:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "E:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=E:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME set /p "GAME=Paste the folder containing left4dead2.exe: "
set "GAME=%GAME:"=%"
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%"
if not exist "%GAME%\left4dead2.exe" ( echo ERROR: left4dead2.exe was not found. & pause & exit /b 1 )

set "SRC=%~dp0WITNESS_FILES"
set "DST=%GAME%\left4dead2"
set "SP=%DST%\addons\sourcemod\scripting\witness_core.sp"
set "SMX=%DST%\addons\sourcemod\plugins\witness_core.smx"
set "SPCOMP=%DST%\addons\sourcemod\scripting\spcomp.exe"
set "SMZIP=%TEMP%\sourcemod-1.12.0-git7246-windows.zip"
set "SMTMP=%TEMP%\witness_v31_sourcemod"
set "SMURL=https://github.com/alliedmodders/sourcemod/releases/download/1.12.0.7246/sourcemod-1.12.0-git7246-windows.zip"

echo Installing ERROR 404: WITNESS V31 DIRECTOR to: %DST%
if not exist "%DST%\addons\sourcemod\plugins" mkdir "%DST%\addons\sourcemod\plugins"
if not exist "%DST%\addons\sourcemod\scripting" mkdir "%DST%\addons\sourcemod\scripting"
xcopy "%SRC%\*" "%DST%\" /E /I /H /R /Y /Q >NUL

if not exist "%DST%\addons\sourcemod\plugins\disabled" mkdir "%DST%\addons\sourcemod\plugins\disabled"
if exist "%DST%\addons\sourcemod\plugins\nextmap.smx" move /Y "%DST%\addons\sourcemod\plugins\nextmap.smx" "%DST%\addons\sourcemod\plugins\disabled\nextmap.smx.disabled" >NUL
if exist "%DST%\addons\sourcemod\plugins\updater.smx" move /Y "%DST%\addons\sourcemod\plugins\updater.smx" "%DST%\addons\sourcemod\plugins\disabled\updater.smx.disabled" >NUL

if not exist "%SPCOMP%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%SMURL%' -OutFile '%SMZIP%' -UseBasicParsing; exit 0 } catch { exit 1 }"
    if not errorlevel 1 (
        if exist "%SMTMP%" rmdir /S /Q "%SMTMP%"
        mkdir "%SMTMP%"
        powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%SMZIP%' -DestinationPath '%SMTMP%' -Force"
        if exist "%SMTMP%\addons\sourcemod\scripting" xcopy "%SMTMP%\addons\sourcemod\scripting\*" "%DST%\addons\sourcemod\scripting\" /E /I /H /R /Y /Q >NUL
        if exist "%SMTMP%\addons\sourcemod\extensions" xcopy "%SMTMP%\addons\sourcemod\extensions\*" "%DST%\addons\sourcemod\extensions\" /E /I /H /R /Y /Q >NUL
        if exist "%SMTMP%\addons\sourcemod\gamedata" xcopy "%SMTMP%\addons\sourcemod\gamedata\*" "%DST%\addons\sourcemod\gamedata\" /E /I /H /R /Y /Q >NUL
    )
)

if exist "%SMX%" del /Q "%SMX%"
if exist "%SPCOMP%" (
    "%SPCOMP%" "%SP%" -o"%SMX%"
) else (
    echo WARNING: spcomp.exe missing. Compile witness_core.sp manually.
    pause
)

echo Launching No Mercy...
timeout /t 2 /nobreak >NUL
start "" "%GAME%\left4dead2.exe" -insecure -console -windowed -noborder +sv_consistency 0 +map c8m1_apartment coop
endlocal
