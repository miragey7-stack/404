/*
    ERROR 404: BLACKBOX MODE
    VScript/mutation rewrite inspired by Alone's architecture:
    - own mutation
    - memory table
    - delayed staged scenes
    - safe room / finale rituals
    - TV contact points
    - sparse map fractures instead of spam
*/

Msg("ERROR 404: BLACKBOX script loaded v0.1.2\n");
printl("BLACKBOXBLACKBOXBLACKBOX");

MutationOptions <-
{
    CommonLimit = 14
    MegaMobSize = 12
    WanderingZombieDensityModifier = 0.012
    cm_MaxSpecials = 1
    BoomerLimit = 0
    JockeyLimit = 0
    SpitterLimit = 0
    SmokerLimit = 1
    ChargerLimit = 0
    HunterLimit = 0
    TankLimit = -1
    MobSpawnSize = 10
    DefaultItems = [ "pistol" ]

    function GetDefaultItem(idx)
    {
        if (idx < DefaultItems.len()) return DefaultItems[idx];
        return 0;
    }
}

// -------------------- GLOBALS --------------------
DEBUG <- 0;
PLAYER <- null;
SPAWNPOINT <- null;
WITNESS <- null;
ERROR404_TV <- null;
DIRECTOR_THINKER <- null;

STATE <- "BOOT";
MAPNAME <- "";
CHAPTER <- 1;
STARTTIME <- 0.0;
LASTPOS <- null;
LASTYAW <- 0.0;
NEXT_MEMORY_LINE <- 0.0;
NEXT_FRACTURE <- 0.0;
NEXT_WITNESS_MOVE <- 0.0;
NEXT_WATCHER <- 0.0;
IDLE_SINCE <- 0.0;
SAFE_ROOM_COUNT <- 0;
VOID_STARTED <- false;

BlackboxMemory <-
{
    booted = 0,
    isolated = 0,
    lookbacks = 0,
    shots = 0,
    witness_seen = 0,
    witness_contacts = 0,
    safe_rooms = 0,
    map_fractures = 0,
    tv_contacts = 0,
    idle_since = 0.0,
    next_memory_line = 0.0,
    last_x = 0.0,
    last_y = 0.0,
    last_z = 0.0,
    last_yaw = 0.0,
    c8m1_scene = 0,
    c8m2_scene = 0,
    c8m3_scene = 0,
    c8m4_scene = 0,
    c8m5_scene = 0,
    intensity = 2
}

// -------------------- UTILITIES --------------------
function client_command(player, command, delay = 0.01)
{
    local ent = Entities.FindByClassname(null, "point_clientcommand");
    if (!ent) {
        ent = CreateSingleSimpleEntityFromTable({ classname = "point_clientcommand", targetname = "error404_clientcommand" });
    }
    DoEntFire("!self", "Command", command, delay, player, ent);
}

function DelayFunc(func, delay = 0.01, paramArray = "noparams", context = null)
{
    local delayed = SpawnEntityFromTable("info_target", { targetname = "error404_delay" });
    if (delayed.ValidateScriptScope()) {
        local scope = delayed.GetScriptScope();
        scope["CallFunction"] <- function()
        {
            if (paramArray == "noparams") {
                if (context == null) func.call(g_ModeScript); else func.call(context);
            } else {
                if (context == null) {
                    if (paramArray[0] != g_ModeScript) paramArray.insert(0, g_ModeScript);
                } else {
                    paramArray.insert(0, context);
                }
                func.acall(paramArray);
            }
            EntFire("!self", "Kill", "", 0.0);
        }
        DoEntFire("!self", "CallScriptFunction", "CallFunction", delay, null, delayed);
    }
}

function AudioCommand(sound, delay = 0.0, mode = "play", volume = 0.65, pitch = 100, entity = null)
{
    if (entity == null) entity = PLAYER;
    if (entity == null) return;
    if (!IsSoundPrecached(sound)) PrecacheSound(sound);

    if (delay <= 0.0) {
        if (mode == "play") EmitAmbientSoundOn(sound, volume, 0, pitch, entity);
        else if (mode == "stop") StopAmbientSoundOn(sound, entity);
        return;
    }

    local timer = SpawnEntityFromTable("logic_timer", { targetname = "error404_sound_timer", start_disabled = false, RefireTime = 0.05 });
    if (timer.ValidateScriptScope()) {
        local s = timer.GetScriptScope();
        s["ticks"] <- 0;
        s["Tick"] <- function()
        {
            ticks++;
            if (ticks >= delay * 20) {
                if (mode == "play") EmitAmbientSoundOn(sound, volume, 0, pitch, entity);
                else if (mode == "stop") StopAmbientSoundOn(sound, entity);
                EntFire("!self", "Kill", "", 0.0);
            }
        }
        timer.ConnectOutput("OnTimer", "Tick");
    }
}

function Dist(a, b)
{
    return (a.GetOrigin() - b.GetOrigin()).Length();
}

function Blackbox(line)
{
    ClientPrint(null, HUD_PRINTTALK, "BLACKBOX: " + line);
}

function Center(line)
{
    ClientPrint(null, HUD_PRINTCENTER, line);
}

function Tone(kind = 0, vol = 0.55, pitch = 100)
{
    if (kind == 0) AudioCommand("ambient/energy/zap1.wav", 0.0, "play", vol, pitch);
    else if (kind == 1) AudioCommand("ambient/atmosphere/cave_hit5.wav", 0.0, "play", vol, pitch);
    else if (kind == 2) AudioCommand("ambient/ambience/rainscapes/Thunder_close01.wav", 0.0, "play", vol, pitch);
    else AudioCommand("ambient/ambience/tv_static_loop2.wav", 0.0, "play", vol, pitch);
}

function FadeOut(delay = 0.0)
{
    if (PLAYER) client_command(PLAYER, "fadeout 0", delay);
}
function FadeIn(delay = 0.0)
{
    if (PLAYER) client_command(PLAYER, "fadein 0", delay);
}
function Overlay(mat, delay = 0.0)
{
    if (PLAYER) client_command(PLAYER, "r_screenoverlay " + mat, delay);
}
function ClearOverlay(delay = 0.0)
{
    if (PLAYER) client_command(PLAYER, "r_screenoverlay \"\"", delay);
}

function LightDark()
{
    if (!PLAYER) return;
    client_command(PLAYER, "mat_grain_scale_override 6", 0.0);
    client_command(PLAYER, "r_flashlightbrightness 0.25", 0.0);
}

function LightGlitch()
{
    if (!PLAYER) return;
    client_command(PLAYER, "mat_grain_scale_override 16", 0.0);
    client_command(PLAYER, "r_flashlightbrightness 2.5", 0.0);
}

function LightNormal()
{
    if (!PLAYER) return;
    client_command(PLAYER, "mat_grain_scale_override 1", 0.0);
    client_command(PLAYER, "r_flashlightbrightness 1", 0.0);
}

function GetChapter()
{
    local m = Director.GetMapName();
    if (m.find("c8m1", 0) != null) return 1;
    if (m.find("c8m2", 0) != null) return 2;
    if (m.find("c8m3", 0) != null) return 3;
    if (m.find("c8m4", 0) != null) return 4;
    if (m.find("c8m5", 0) != null) return 5;
    return 1;
}

function IsHumanSurvivor(ent)
{
    if (!ent) return false;
    if (IsPlayerABot(ent)) return false;
    try { return ent.IsSurvivor(); } catch(e) { return false; }
}

// -------------------- SETUP / CLEANUP --------------------
function ApplyBaseCvars()
{
    Convars.SetValue("sv_cheats", 1);
    Convars.SetValue("sv_consistency", 0);
    Convars.SetValue("sb_all_bot_game", 1);
    Convars.SetValue("allow_all_bot_survivor_team", 1);
    Convars.SetValue("director_no_death_check", 1);
    Convars.SetValue("sv_rescue_disabled", 1);
    Convars.SetValue("survivor_limit", 4);
    Convars.SetValue("gameinstructor_start_sound_cooldown", 999999);
    Convars.SetValue("cl_glow_brightness", 4);
    Convars.SetValue("mat_grain_enable", 1);
    Convars.SetValue("mat_grain_scale_override", 1);
}

function RestoreCvars()
{
    SendToServerConsole("cl_drawhud 1");
    SendToServerConsole("r_screenoverlay \"\"");
    SendToServerConsole("host_timescale 1");
    SendToServerConsole("nb_stop 0");
    SendToServerConsole("director_start");
    SendToServerConsole("mat_grain_scale_override 0");
}

function OnGameplayStart()
{
    MAPNAME = Director.GetMapName();
    CHAPTER = GetChapter();
    STARTTIME = Time();
    ApplyBaseCvars();
    RestoreTable("BlackboxMemory", BlackboxMemory);
    SpawnDirectorThinker();
    Msg("ERROR404 OnGameplayStart on " + MAPNAME + "\n");
}

function OnShutdown()
{
    SaveTable("BlackboxMemory", BlackboxMemory);
    KillByName("error404_witness");
    KillByName("error404_watcher");
    KillByName("error404_tv");
    KillByName("error404_director");
    RestoreCvars();
}

function OnGameEvent_player_spawn(params)
{
    local p = GetPlayerFromUserID(params.userid);
    if (IsHumanSurvivor(p)) {
        PLAYER = p;
        SPAWNPOINT = p.GetOrigin();
        LASTPOS = p.GetOrigin();
        LASTYAW = p.EyeAngles().y;
        IDLE_SINCE = Time();
        BlackboxMemory.last_x = LASTPOS.x;
        BlackboxMemory.last_y = LASTPOS.y;
        BlackboxMemory.last_z = LASTPOS.z;
        BlackboxMemory.last_yaw = LASTYAW;
        BlackboxMemory.idle_since = Time();
        BlackboxMemory.next_memory_line = Time() + 75.0;
        if (STATE == "BOOT") {
            STATE = "NORMAL";
            DelayFunc(SceneBoot, 8.0);
            if (CHAPTER >= 2) DelayFunc(BeginIsolation, 4.0);
        }
    }
}

function OnGameEvent_player_first_spawn(params)
{
    OnGameEvent_player_spawn(params);
}

function OnGameEvent_player_connect_full(params)
{
    local p = GetPlayerFromUserID(params.userid);
    if (IsHumanSurvivor(p)) PLAYER = p;
}

function OnGameEvent_weapon_fire(params)
{
    if (!PLAYER) return;
    BlackboxMemory.shots++;
    if ((BlackboxMemory.shots % 35) == 0 && Time() > NEXT_MEMORY_LINE) {
        Blackbox("firearm use logged");
        NEXT_MEMORY_LINE = Time() + 75.0;
    }
}

function OnGameEvent_door_close(params)
{
    if (STATE == "ISOLATED" || STATE == "BLACKBOX") {
        if ("checkpoint" in params && params.checkpoint) {
            SAFE_ROOM_COUNT++;
            BlackboxMemory.safe_rooms++;
            SceneSafeRoom();
        }
    }
}

function OnGameEvent_finale_start(params)
{
    if (CHAPTER >= 5 && !VOID_STARTED) {
        TriggerVoid();
    }
}

function OnGameEvent_finale_vehicle_ready(params)
{
    if (CHAPTER >= 5 && !VOID_STARTED) {
        TriggerVoid();
    }
}

function SpawnDirectorThinker()
{
    KillByName("error404_director");
    DIRECTOR_THINKER = SpawnEntityFromTable("info_target", { targetname = "error404_director" });
    if (DIRECTOR_THINKER.ValidateScriptScope()) {
        local s = DIRECTOR_THINKER.GetScriptScope();
        s["Think"] <- function()
        {
            g_ModeScript.BlackboxThink();
            return 0.25;
        }
        AddThinkToEnt(DIRECTOR_THINKER, "Think");
    }
}

function BlackboxThink()
{
    if (!PLAYER || !PLAYER.IsValid()) return;
    UpdateMemory();

    if (STATE == "NORMAL") UpdateNormal();
    if (STATE == "ISOLATED" || STATE == "BLACKBOX") {
        UpdateMapScenes();
        UpdateWitness();
        UpdateSparseFractures();
        UpdateTelevision();
    }
}

// -------------------- MEMORY --------------------
function UpdateMemory()
{
    if (!PLAYER) return;
    local now = Time();
    local pos = PLAYER.GetOrigin();

    local oldpos = Vector(BlackboxMemory.last_x, BlackboxMemory.last_y, BlackboxMemory.last_z);
    if ((pos - oldpos).Length() > 40) {
        BlackboxMemory.last_x = pos.x;
        BlackboxMemory.last_y = pos.y;
        BlackboxMemory.last_z = pos.z;
        BlackboxMemory.idle_since = now;
    } else if (now - BlackboxMemory.idle_since > 45 && now > BlackboxMemory.next_memory_line) {
        Blackbox("subject waiting for instruction");
        BlackboxMemory.next_memory_line = now + 120.0;
        // Prevent repeating if player remains still.
        BlackboxMemory.idle_since = now;
    }

    local yaw = PLAYER.EyeAngles().y;
    local delta = abs(NormalizeYaw(yaw - BlackboxMemory.last_yaw));
    if (delta > 145) {
        BlackboxMemory.lookbacks++;
        if ((BlackboxMemory.lookbacks % 7) == 0 && now > BlackboxMemory.next_memory_line) {
            Blackbox("subject repeatedly checks behind");
            BlackboxMemory.next_memory_line = now + 120.0;
        }
    }
    BlackboxMemory.last_yaw = yaw;
}

function NormalizeYaw(y)
{
    while (y > 180) y -= 360;
    while (y < -180) y += 360;
    return y;
}

// -------------------- PHASES --------------------
function SceneBoot()
{
    if (!PLAYER) return;
    Blackbox("recording started");
    BlackboxMemory.booted = 1;
    Tone(0, 0.25, 70);
    Spawn404TVNearPlayer();
}

function UpdateNormal()
{
    if (!PLAYER || !SPAWNPOINT) return;
    local dist = (PLAYER.GetOrigin() - SPAWNPOINT).Length();
    if (CHAPTER == 1 && BlackboxMemory.c8m1_scene == 0 && dist > 900) {
        BlackboxMemory.c8m1_scene = 1;
        STATE = "OBSERVED";
        SceneC8M1Checksum();
    }
    if (dist > 1900) BeginIsolation();
}

function BeginIsolation()
{
    if (STATE == "ISOLATED" || STATE == "BLACKBOX" || !PLAYER) return;
    STATE = "ISOLATED";
    BlackboxMemory.isolated = 1;
    Blackbox("companions removed by request");
    Tone(2, 0.45, 55);
    FadeOut(0.1);
    client_command(PLAYER, "nb_stop 1", 0.1);
    SendToServerConsole("director_stop");
    LightDark();
    StageBots();
    DelayFunc(DeleteBots, 1.0);
    DelayFunc(PostIsolation, 1.4);
}

function StageBots()
{
    local bot = null;
    while (bot = Entities.FindByClassname(bot, "player")) {
        if (IsPlayerABot(bot)) {
            bot.SetHealth(1);
        }
    }
}

function DeleteBots()
{
    SendToServerConsole("kick Bill");
    SendToServerConsole("kick Zoey");
    SendToServerConsole("kick Francis");
    SendToServerConsole("kick Louis");
    SendToServerConsole("kick Coach");
    SendToServerConsole("kick Ellis");
    SendToServerConsole("kick Rochelle");
    SendToServerConsole("kick Nick");
    SendToServerConsole("nb_delete_all");
}

function PostIsolation()
{
    if (!PLAYER) return;
    FadeIn(0.0);
    PrintDisconnectedLines();
    SpawnWitness(620, true);
    STATE = "BLACKBOX";
    NEXT_FRACTURE = Time() + RandomFloat(45, 80);
    NEXT_WATCHER = Time() + RandomFloat(25, 55);
}

function PrintDisconnectedLines()
{
    ClientPrint(null, HUD_PRINTTALK, "Bill disconnected");
    ClientPrint(null, HUD_PRINTTALK, "Zoey disconnected");
    ClientPrint(null, HUD_PRINTTALK, "Francis disconnected");
}

// -------------------- MAP-SPECIFIC SCENES --------------------
function SceneC8M1Checksum()
{
    Blackbox("map checksum mismatch");
    Tone(0, 0.3, 70);
    SpawnWatcher(700, 7.0, true);
    LightGlitch();
    DelayFunc(RestoreLight, 1.5);
}

function UpdateMapScenes()
{
    if (!PLAYER) return;
    if (CHAPTER == 2 && BlackboxMemory.c8m2_scene == 0) {
        BlackboxMemory.c8m2_scene = 1;
        SceneC8M2TrainNever();
        return;
    }
    if (CHAPTER == 3 && BlackboxMemory.c8m3_scene == 0) {
        BlackboxMemory.c8m3_scene = 1;
        SceneC8M3WaterMemory();
        return;
    }
    if (CHAPTER == 4 && BlackboxMemory.c8m4_scene == 0) {
        BlackboxMemory.c8m4_scene = 1;
        SceneC8M4PatientYou();
        return;
    }
    if (CHAPTER == 5 && BlackboxMemory.c8m5_scene == 0) {
        BlackboxMemory.c8m5_scene = 1;
        SceneC8M5RescueMissing();
        return;
    }
}

function SceneC8M2TrainNever()
{
    Center("NEXT TRAIN: NEVER");
    Blackbox("platform schedule missing");
    Tone(1, 0.45, 60);
    ScreenShake(PLAYER.GetOrigin(), 7, 4, 1.3, 160, 0, true);
    SpawnWatcher(560, 8.0, true);
    DelayFunc(SecondWatcher, 1.4);
}

function SecondWatcher()
{
    SpawnWatcher(230, 4.0, false);
}

function SceneC8M3WaterMemory()
{
    Blackbox("audio recovered from water");
    Tone(1, 0.55, 55);
    ScreenShake(PLAYER.GetOrigin(), 8, 6, 1.5, 180, 0, true);
    ThrowNearbyPhysics(2, 520, 260);
}

function SceneC8M4PatientYou()
{
    Center("PATIENT: YOU");
    ClientPrint(null, HUD_PRINTTALK, "Zoey: don't let it wear my face");
    Tone(2, 0.45, 55);
    SpawnHangingBody(6.0);
}

function SceneC8M5RescueMissing()
{
    Blackbox("rescue entity missing");
    Blackbox("helicopter path null");
    Tone(1, 0.55, 55);
    SpawnWatcher(280, 10.0, true);
    SpawnWatcher(320, 10.0, false);
}

function SceneSafeRoom()
{
    if (SAFE_ROOM_COUNT <= 1) {
        Blackbox("checkpoint accepted");
        Tone(0, 0.25, 70);
    } else if (SAFE_ROOM_COUNT == 2) {
        Blackbox("checkpoint repeated");
        Tone(1, 0.35, 60);
    } else {
        Center("SAFE ROOM IS A LIE");
        Tone(2, 0.5, 55);
        ScreenShake(PLAYER.GetOrigin(), 18, 12, 2.0, 220, 0, true);
        SpawnWatcher(125, 4.0, false);
        SpawnWatcher(160, 4.0, true);
    }
}

// -------------------- WITNESS --------------------
function SpawnWitness(distance = 520, inFront = false)
{
    if (!PLAYER) return;
    KillByName("error404_witness");

    local pos = PointAroundPlayer(distance, inFront);
    local ent = SpawnEntityFromTable("prop_dynamic_override", {
        targetname = "error404_witness",
        model = "models/infected/smoker.mdl",
        solid = 0,
        origin = pos,
        angles = Vector(0, 0, 0)
    });
    WITNESS = ent;
    ApplySilhouette(ent, 1.25);
    FacePlayer(ent);
    BlackboxMemory.witness_seen++;
}

function UpdateWitness()
{
    if (!PLAYER) return;
    if (!WITNESS || !WITNESS.IsValid()) {
        if (Time() > NEXT_WITNESS_MOVE) {
            SpawnWitness(520, false);
            NEXT_WITNESS_MOVE = Time() + 16;
        }
        return;
    }

    FacePlayer(WITNESS);
    local d = Dist(WITNESS, PLAYER);
    if (d < 85) {
        WitnessContact();
        return;
    }

    if (Time() > NEXT_WITNESS_MOVE) {
        local dist = RandomFloat(210, 380);
        WITNESS.SetOrigin(PointAroundPlayer(dist, false));
        FacePlayer(WITNESS);
        Tone(0, 0.22, 70);
        NEXT_WITNESS_MOVE = Time() + RandomFloat(12, 22) - BlackboxMemory.intensity;
    }
}

function WitnessContact()
{
    if (!PLAYER || !WITNESS) return;
    Blackbox("observer contact");
    BlackboxMemory.witness_contacts++;
    Overlay("witness_v25/tv_noise", 0.0);
    ClearOverlay(0.35);
    ScreenShake(PLAYER.GetOrigin(), 22, 18, 1.3, 220, 0, true);
    Tone(2, 0.45, 55);
    local away = PLAYER.GetOrigin() - WITNESS.GetOrigin();
    local len = away.Length();
    if (len > 0) away = away.Scale(1.0 / len);
    PLAYER.SetVelocity(away.Scale(760) + Vector(0,0,210));
    WITNESS.Kill();
    WITNESS = null;
    NEXT_WITNESS_MOVE = Time() + 18;
}

function SpawnWatcher(distance, lifetime, inFront)
{
    if (!PLAYER) return;
    local ent = SpawnEntityFromTable("prop_dynamic_override", {
        targetname = "error404_watcher",
        model = RandomSurvivorModel(),
        solid = 0,
        origin = PointAroundPlayer(distance, inFront),
        angles = Vector(0, 0, 0)
    });
    ApplySilhouette(ent, RandomFloat(1.05, 1.25));
    FacePlayer(ent);
    DoEntFire("!self", "Kill", "", lifetime, null, ent);
}

function SpawnHangingBody(lifetime)
{
    if (!PLAYER) return;
    local pos = PLAYER.GetOrigin() + Vector(RandomFloat(-90,90), RandomFloat(-90,90), 185);
    local ent = SpawnEntityFromTable("prop_dynamic_override", {
        targetname = "error404_watcher",
        model = RandomSurvivorModel(),
        solid = 0,
        origin = pos,
        angles = Vector(180, RandomFloat(0,360), 0)
    });
    ApplySilhouette(ent, 1.15);
    DoEntFire("!self", "Kill", "", lifetime, null, ent);
}

function RandomSurvivorModel()
{
    local r = RandomInt(0, 5);
    if (r == 0) return "models/survivors/survivor_namvet.mdl";
    if (r == 1) return "models/survivors/survivor_biker.mdl";
    if (r == 2) return "models/survivors/survivor_teenangst.mdl";
    if (r == 3) return "models/survivors/survivor_manager.mdl";
    if (r == 4) return "models/survivors/survivor_coach.mdl";
    return "models/survivors/survivor_gambler.mdl";
}

function ApplySilhouette(ent, scale)
{
    if (!ent) return;
    NetProps.SetPropFloat(ent, "m_flModelScale", scale);
    NetProps.SetPropInt(ent, "m_nRenderMode", 1);
    ent.__KeyValueFromString("rendercolor", "0 0 0");
    ent.__KeyValueFromString("renderamt", "255");
}

function PointAroundPlayer(distance, inFront)
{
    local yaw = PLAYER.EyeAngles().y;
    if (inFront) yaw += RandomFloat(-30, 30);
    else yaw += RandomFloat(125, 235);
    local rad = yaw * 3.14159 / 180.0;
    local p = PLAYER.GetOrigin();
    return Vector(p.x + cos(rad) * distance, p.y + sin(rad) * distance, p.z + 8);
}

function FacePlayer(ent)
{
    if (!ent || !PLAYER) return;
    local dir = PLAYER.GetOrigin() - ent.GetOrigin();
    local yaw = atan2(dir.y, dir.x) * 180.0 / 3.14159;
    ent.SetAngles(0, yaw, 0);
}

// -------------------- TV CONTACTS --------------------
function Spawn404TVNearPlayer()
{
    if (!PLAYER || ERROR404_TV) return;
    local pos = PLAYER.GetOrigin() + PLAYER.EyeAngles().Forward().Scale(180) + Vector(0,0,10);
    ERROR404_TV = SpawnEntityFromTable("prop_physics", {
        targetname = "error404_tv",
        model = "models/props_interiors/tv.mdl",
        origin = pos,
        angles = Vector(0, PLAYER.EyeAngles().y + 180, 0),
        skin = 2
    });
}

function UpdateTelevision()
{
    if (!PLAYER || !ERROR404_TV || !ERROR404_TV.IsValid()) return;
    if (Dist(PLAYER, ERROR404_TV) < 115) {
        BlackboxMemory.tv_contacts++;
        Blackbox("signal source local");
        Overlay("4ded", 0.0);
        ClearOverlay(1.2);
        Tone(3, 0.35, 120);
        DoEntFire("!self", "Kill", "", 0.3, null, ERROR404_TV);
        ERROR404_TV = null;
    }
}

// -------------------- MAP FRACTURE --------------------
function UpdateSparseFractures()
{
    if (!PLAYER || Time() < NEXT_FRACTURE) return;
    SceneMapFracture();
    local minDelay = (CHAPTER >= 3) ? 55.0 : 85.0;
    local maxDelay = (CHAPTER >= 3) ? 110.0 : 150.0;
    if (BlackboxMemory.intensity >= 3) {
        minDelay *= 0.65;
        maxDelay *= 0.75;
    }
    NEXT_FRACTURE = Time() + RandomFloat(minDelay, maxDelay);
}

function SceneMapFracture()
{
    BlackboxMemory.map_fractures++;
    if (RandomInt(0, 100) < 55) ClientPrint(null, HUD_PRINTTALK, "BLACKBOX: map transform differs from recording");
    LightGlitch();
    DelayFunc(RestoreLight, 0.9);
    ThrowNearbyPhysics(3 + BlackboxMemory.intensity, 700, 390);
    RotateNearbyStatics(4, 850);
    NudgeDoors(720);
    Tone(1, 0.35, 60);
}

function ThrowNearbyPhysics(count, radius, force)
{
    local thrown = 0;
    thrown += ThrowClass("prop_physics", count - thrown, radius, force);
    if (thrown < count) thrown += ThrowClass("prop_physics_multiplayer", count - thrown, radius, force);
    if (thrown < count) thrown += ThrowClass("prop_physics_override", count - thrown, radius, force);
}

function ThrowClass(classname, count, radius, force)
{
    if (count <= 0 || !PLAYER) return 0;
    local ent = null;
    local thrown = 0;
    while (ent = Entities.FindByClassnameWithin(ent, classname, PLAYER.GetOrigin(), radius)) {
        if (thrown >= count) break;
        if (ent.GetName() == "error404_tv") continue;
        local v = Vector(RandomFloat(-force, force), RandomFloat(-force, force), RandomFloat(force * 0.3, force * 0.85));
        try { ent.ApplyAbsVelocityImpulse(v); } catch(e) { ent.SetOrigin(ent.GetOrigin() + Vector(RandomFloat(-15,15), RandomFloat(-15,15), RandomFloat(0,20))); }
        thrown++;
    }
    return thrown;
}

function RotateNearbyStatics(count, radius)
{
    if (!PLAYER) return;
    local ent = null;
    local changed = 0;
    while (ent = Entities.FindByClassnameWithin(ent, "prop_dynamic", PLAYER.GetOrigin(), radius)) {
        if (changed >= count) break;
        ent.SetAngles(0, ent.GetAngles().y + RandomFloat(-28, 28), 0);
        changed++;
    }
}

function NudgeDoors(radius)
{
    NudgeDoorClass("prop_door_rotating", radius);
    NudgeDoorClass("func_door", radius);
    NudgeDoorClass("func_door_rotating", radius);
}

function NudgeDoorClass(classname, radius)
{
    if (!PLAYER) return;
    local ent = null;
    local touched = 0;
    while (ent = Entities.FindByClassnameWithin(ent, classname, PLAYER.GetOrigin(), radius)) {
        if (touched >= 2) break;
        if (RandomInt(0,1) == 1) DoEntFire("!self", "Open", "", 0.0, null, ent);
        else DoEntFire("!self", "Close", "", 0.0, null, ent);
        touched++;
    }
}

function RestoreLight()
{
    if (STATE == "ISOLATED" || STATE == "BLACKBOX") LightDark();
    else LightNormal();
}

// -------------------- VOID --------------------
function TriggerVoid()
{
    if (!PLAYER || VOID_STARTED) return;
    VOID_STARTED = true;
    STATE = "VOID";
    Blackbox("exit route not found");
    FadeOut(0.0);
    SendToServerConsole("director_stop");
    SendToServerConsole("nb_delete_all");
    DelayFunc(VoidStage1, 1.4);
}

function VoidStage1()
{
    if (!PLAYER) return;
    local pos = PLAYER.GetOrigin() + Vector(0,0,2200);
    PLAYER.SetOrigin(pos);
    client_command(PLAYER, "cl_drawhud 0", 0.0);
    Center("N O   E X I T");
    Tone(2, 0.55, 55);
    for (local i = 0; i < 8; i++) SpawnVoidWatcher(pos, i);
    DelayFunc(VoidFinale, 7.0);
}

function SpawnVoidWatcher(center, i)
{
    local yaw = i * 45.0 * 3.14159 / 180.0;
    local pos = Vector(center.x + cos(yaw) * 250, center.y + sin(yaw) * 250, center.z + RandomFloat(-35, 65));
    local ent = SpawnEntityFromTable("prop_dynamic_override", {
        targetname = "error404_watcher",
        model = RandomSurvivorModel(),
        solid = 0,
        origin = pos
    });
    ApplySilhouette(ent, 1.3);
    FacePlayer(ent);
}

function VoidFinale()
{
    if (!PLAYER) return;
    Overlay("witness_v25/scream_face", 0.0);
    ScreenShake(PLAYER.GetOrigin(), 45, 35, 1.5, 260, 0, true);
    Tone(2, 0.75, 55);
    DelayFunc(ExitGame, 1.2);
}

function ExitGame()
{
    if (PLAYER) client_command(PLAYER, "exit", 0.01);
}

// -------------------- MISC --------------------
function KillByName(name)
{
    local ent = null;
    while (ent = Entities.FindByName(ent, name)) {
        ent.Kill();
    }
}

function abs(v) { if (v < 0) return -v; return v; }

// Start a very quiet state immediately.
ApplyBaseCvars();
