/* ERROR 404: LOST BUILD CLEAN
   Stable VScript-only baseline.
   No SourceMod. No SetAngles. No custom sound loading.
*/

Msg("ERROR 404 LOST BUILD CLEAN loaded v0.1.0\n");
printl("ERROR404_CLEAN_ACTIVE");

MutationOptions <-
{
    CommonLimit = 14
    MegaMobSize = 10
    WanderingZombieDensityModifier = 0.012
    cm_MaxSpecials = 1
    BoomerLimit = 0
    SpitterLimit = 0
    JockeyLimit = 0
    ChargerLimit = 0
    HunterLimit = 0
    SmokerLimit = 1
    TankLimit = -1
    MobSpawnSize = 8
    DefaultItems = [ "pistol" ]
    function GetDefaultItem(idx)
    {
        if (idx < DefaultItems.len()) return DefaultItems[idx];
        return 0;
    }
}

PLAYER <- null;
THINKER <- null;
WITNESS <- null;
STATE <- "BOOT";
CHAPTER <- 1;
SPAWN <- null;
LASTPOS <- null;
LASTYAW <- 0.0;
IDLE_SINCE <- 0.0;
NEXT_MEMORY <- 0.0;
NEXT_WITNESS <- 0.0;
NEXT_FRACTURE <- 0.0;
NEXT_WATCHER <- 0.0;
SAFE_COUNT <- 0;
VOID_STARTED <- false;

Memory <-
{
    lookbacks = 0,
    shots = 0,
    witness_seen = 0,
    witness_contact = 0,
    safe_rooms = 0,
    c1 = 0,
    c2 = 0,
    c3 = 0,
    c4 = 0,
    c5 = 0,
    intensity = 2
}

function IsHuman(ent)
{
    if (!ent) return false;
    if (IsPlayerABot(ent)) return false;
    try { return ent.IsSurvivor(); } catch(e) { return false; }
}

function Say(t) { ClientPrint(null, HUD_PRINTTALK, "BLACKBOX: " + t); }
function Center(t) { ClientPrint(null, HUD_PRINTCENTER, t); }
function abs(v) { if (v < 0) return -v; return v; }
function NormalizeYaw(y) { while (y > 180) y -= 360; while (y < -180) y += 360; return y; }

function Tone(kind = 0, vol = 0.45, pitch = 80)
{
    local snd = "ambient/energy/zap1.wav";
    if (kind == 1) snd = "ambient/atmosphere/cave_hit5.wav";
    if (kind == 2) snd = "ambient/ambience/rainscapes/Thunder_close01.wav";
    if (!IsSoundPrecached(snd)) PrecacheSound(snd);
    if (PLAYER) EmitAmbientSoundOn(snd, vol, 0, pitch, PLAYER);
}

function Cmd(command, delay = 0.01)
{
    if (!PLAYER) return;
    local ent = Entities.FindByClassname(null, "point_clientcommand");
    if (!ent) ent = CreateSingleSimpleEntityFromTable({ classname = "point_clientcommand", targetname = "e404_clientcommand" });
    DoEntFire("!self", "Command", command, delay, PLAYER, ent);
}

function Delay(func, delay = 0.01)
{
    local ent = SpawnEntityFromTable("info_target", { targetname = "e404_delay" });
    if (ent.ValidateScriptScope()) {
        local sc = ent.GetScriptScope();
        sc["Run"] <- function()
        {
            func.call(g_ModeScript);
            EntFire("!self", "Kill", "", 0.0);
        }
        DoEntFire("!self", "CallScriptFunction", "Run", delay, null, ent);
    }
}

function KillNamed(name)
{
    local e = null;
    while (e = Entities.FindByName(e, name)) e.Kill();
}

function Chapter()
{
    local m = Director.GetMapName();
    if (m.find("c8m1") != null) return 1;
    if (m.find("c8m2") != null) return 2;
    if (m.find("c8m3") != null) return 3;
    if (m.find("c8m4") != null) return 4;
    if (m.find("c8m5") != null) return 5;
    return 1;
}

function ApplyRules()
{
    Convars.SetValue("sv_cheats", 1);
    Convars.SetValue("sv_consistency", 0);
    Convars.SetValue("director_no_death_check", 1);
    Convars.SetValue("sb_all_bot_game", 1);
    Convars.SetValue("allow_all_bot_survivor_team", 1);
    Convars.SetValue("gameinstructor_start_sound_cooldown", 999999);
    SendToServerConsole("alias blackbox scripted_user_func blackbox");
    SendToServerConsole("alias bbquiet scripted_user_func bbquiet");
    SendToServerConsole("alias bbintense scripted_user_func bbintense");
    SendToServerConsole("alias bbgiveup scripted_user_func bbgiveup");
}

function OnGameplayStart()
{
    RestoreTable("E404Memory", Memory);
    CHAPTER = Chapter();
    ApplyRules();
    SpawnThinker();
    printl("ERROR404 OnGameplayStart clean chapter " + CHAPTER);
}

function OnShutdown()
{
    SaveTable("E404Memory", Memory);
    Cleanup();
}

function Cleanup()
{
    KillNamed("e404_witness");
    KillNamed("e404_watcher");
    KillNamed("e404_thinker");
    SendToServerConsole("director_start");
    Cmd("cl_drawhud 1", 0.0);
    Cmd("r_screenoverlay \"\"", 0.0);
    Cmd("host_timescale 1", 0.0);
}

function SpawnThinker()
{
    KillNamed("e404_thinker");
    THINKER = SpawnEntityFromTable("info_target", { targetname = "e404_thinker" });
    if (THINKER.ValidateScriptScope()) {
        local sc = THINKER.GetScriptScope();
        sc["Think"] <- function()
        {
            g_ModeScript.MainThink();
            return 0.25;
        }
        AddThinkToEnt(THINKER, "Think");
    }
}

function OnGameEvent_player_spawn(params)
{
    local p = GetPlayerFromUserID(params.userid);
    if (!IsHuman(p)) return;
    PLAYER = p;
    SPAWN = p.GetOrigin();
    LASTPOS = p.GetOrigin();
    LASTYAW = p.EyeAngles().y;
    IDLE_SINCE = Time();
    NEXT_MEMORY = Time() + 80.0;
    if (STATE == "BOOT") {
        STATE = "NORMAL";
        Delay(BootScene, 8.0);
        if (CHAPTER >= 2) Delay(Isolate, 3.5);
    }
}
function OnGameEvent_player_first_spawn(params) { OnGameEvent_player_spawn(params); }
function OnGameEvent_player_connect_full(params)
{
    local p = GetPlayerFromUserID(params.userid);
    if (IsHuman(p)) PLAYER = p;
}

function OnGameEvent_weapon_fire(params)
{
    Memory.shots++;
    if ((Memory.shots % 40) == 0) Say("firearm pattern stored");
}

function OnGameEvent_door_close(params)
{
    if ((STATE == "ISOLATED" || STATE == "BLACKBOX") && "checkpoint" in params && params.checkpoint) {
        SAFE_COUNT++;
        Memory.safe_rooms++;
        SafeScene();
    }
}

function OnGameEvent_finale_start(params) { if (CHAPTER >= 5) VoidStart(); }
function OnGameEvent_finale_vehicle_ready(params) { if (CHAPTER >= 5) VoidStart(); }

function UserConsoleCommand(playerScript, arg)
{
    switch(arg) {
        case "blackbox": Notebook(); break;
        case "bbquiet": Memory.intensity = 1; Say("intensity quiet"); break;
        case "bbintense": Memory.intensity = 3; Say("intensity intense"); break;
        case "bbgiveup": Cleanup(); Cmd("disconnect", 1.0); break;
    }
}

function MainThink()
{
    if (!PLAYER || !PLAYER.IsValid()) return;
    MemoryThink();
    if (STATE == "NORMAL") NormalThink();
    else if (STATE == "ISOLATED" || STATE == "BLACKBOX") {
        ChapterSceneThink();
        WitnessThink();
        FractureThink();
        AmbientWatcherThink();
    }
}

function MemoryThink()
{
    if (STATE == "VOID") return;
    local now = Time();
    local pos = PLAYER.GetOrigin();
    if (LASTPOS == null) LASTPOS = pos;
    if ((pos - LASTPOS).Length() > 45) { LASTPOS = pos; IDLE_SINCE = now; }
    else if (now - IDLE_SINCE > 60 && now > NEXT_MEMORY) {
        Say("subject waiting for instruction");
        NEXT_MEMORY = now + 150;
        IDLE_SINCE = now;
    }
    local yaw = PLAYER.EyeAngles().y;
    local delta = abs(NormalizeYaw(yaw - LASTYAW));
    if (delta > 145) {
        Memory.lookbacks++;
        if ((Memory.lookbacks % 8) == 0 && now > NEXT_MEMORY) { Say("subject checks behind"); NEXT_MEMORY = now + 150; }
    }
    LASTYAW = yaw;
}

function NormalThink()
{
    if (!SPAWN) return;
    local d = (PLAYER.GetOrigin() - SPAWN).Length();
    if (CHAPTER == 1 && Memory.c1 == 0 && d > 850) { Memory.c1 = 1; STATE = "OBSERVED"; C1Scene(); }
    if (d > 1900) Isolate();
}

function BootScene() { Say("recording started"); Tone(0, 0.25, 70); }
function C1Scene() { Say("map checksum mismatch"); Tone(0, 0.28, 70); SpawnWatcher(650, 6.0, true); Glitch(1.0); }

function Isolate()
{
    if (STATE == "ISOLATED" || STATE == "BLACKBOX" || !PLAYER) return;
    STATE = "ISOLATED";
    Say("companions removed by request");
    Tone(2, 0.45, 55);
    Cmd("fadeout 0", 0.0);
    SendToServerConsole("director_stop");
    SendToServerConsole("nb_stop 1");
    Delay(DeleteBots, 0.8);
    Delay(PostIsolation, 1.3);
}
function DeleteBots() { SendToServerConsole("kick Bill; kick Zoey; kick Francis; kick Louis; kick Coach; kick Ellis; kick Rochelle; kick Nick; nb_delete_all"); }
function PostIsolation()
{
    Cmd("fadein 0", 0.0);
    ClientPrint(null, HUD_PRINTTALK, "Bill disconnected");
    ClientPrint(null, HUD_PRINTTALK, "Zoey disconnected");
    ClientPrint(null, HUD_PRINTTALK, "Francis disconnected");
    SpawnWitness(600, true);
    STATE = "BLACKBOX";
    NEXT_FRACTURE = Time() + RandomFloat(45, 80);
    NEXT_WITNESS = Time() + 14;
}

function ChapterSceneThink()
{
    if (CHAPTER == 2 && Memory.c2 == 0) { Memory.c2 = 1; Center("NEXT TRAIN: NEVER"); Say("platform schedule missing"); Tone(1, 0.45, 60); SpawnWatcher(560, 7.0, true); return; }
    if (CHAPTER == 3 && Memory.c3 == 0) { Memory.c3 = 1; Say("audio recovered from water"); Tone(1, 0.55, 55); ThrowProps(2, 520, 260); return; }
    if (CHAPTER == 4 && Memory.c4 == 0) { Memory.c4 = 1; Center("PATIENT: YOU"); ClientPrint(null, HUD_PRINTTALK, "Zoey: don't let it wear my face"); Tone(2, 0.45, 55); SpawnWatcher(180, 5.0, false); return; }
    if (CHAPTER == 5 && Memory.c5 == 0) { Memory.c5 = 1; Say("rescue entity missing"); Say("helicopter path null"); Tone(1, 0.55, 55); SpawnWatcher(280, 10.0, true); SpawnWatcher(320, 10.0, false); return; }
}

function SafeScene()
{
    if (SAFE_COUNT == 1) Say("checkpoint accepted");
    else if (SAFE_COUNT == 2) Say("checkpoint repeated");
    else { Center("SAFE ROOM IS A LIE"); Say("room classification failed"); Glitch(0.8); SpawnWatcher(120, 4.0, false); ThrowProps(3, 420, 280); }
}

function SpawnWitness(distance, front)
{
    KillNamed("e404_witness");
    WITNESS = SpawnEntityFromTable("prop_dynamic_override", { targetname = "e404_witness", model = "models/infected/smoker.mdl", solid = 0, origin = Around(distance, front) });
    Blacken(WITNESS, 1.25);
    Memory.witness_seen++;
}
function WitnessThink()
{
    if (!PLAYER) return;
    if (!WITNESS || !WITNESS.IsValid()) { if (Time() > NEXT_WITNESS) { SpawnWitness(520, false); NEXT_WITNESS = Time() + 22; } return; }
    local d = (WITNESS.GetOrigin() - PLAYER.GetOrigin()).Length();
    if (d < 85) { WitnessContact(); return; }
    if (Time() > NEXT_WITNESS) { WITNESS.SetOrigin(Around(RandomFloat(200, 360), false)); Tone(0, 0.22, 70); NEXT_WITNESS = Time() + RandomFloat(14, 24) - Memory.intensity; }
}
function WitnessContact()
{
    Memory.witness_contact++;
    Say("observer contact");
    Glitch(0.6);
    ScreenShake(PLAYER.GetOrigin(), 22, 18, 1.3, 220, 0, true);
    Tone(2, 0.45, 55);
    if (WITNESS) WITNESS.Kill();
    WITNESS = null;
    NEXT_WITNESS = Time() + 18;
}
function SpawnWatcher(distance, lifetime, front)
{
    local ent = SpawnEntityFromTable("prop_dynamic_override", { targetname = "e404_watcher", model = SurvivorModel(), solid = 0, origin = Around(distance, front) });
    Blacken(ent, RandomFloat(1.05, 1.25));
    DoEntFire("!self", "Kill", "", lifetime, null, ent);
}
function AmbientWatcherThink()
{
    if (Time() < NEXT_WATCHER) return;
    if (RandomInt(0,100) < 25) SpawnWatcher(RandomFloat(260, 620), RandomFloat(5, 9), RandomInt(0,1) == 1);
    NEXT_WATCHER = Time() + RandomFloat(50, 90);
}

function Around(distance, front)
{
    local yaw = PLAYER.EyeAngles().y;
    if (front) yaw += RandomFloat(-28, 28); else yaw += RandomFloat(125, 235);
    local r = yaw * 3.14159 / 180.0;
    local p = PLAYER.GetOrigin();
    return Vector(p.x + cos(r) * distance, p.y + sin(r) * distance, p.z + 8);
}
function SurvivorModel()
{
    local r = RandomInt(0, 5);
    if (r == 0) return "models/survivors/survivor_namvet.mdl";
    if (r == 1) return "models/survivors/survivor_biker.mdl";
    if (r == 2) return "models/survivors/survivor_teenangst.mdl";
    if (r == 3) return "models/survivors/survivor_manager.mdl";
    if (r == 4) return "models/survivors/survivor_coach.mdl";
    return "models/survivors/survivor_gambler.mdl";
}
function Blacken(ent, scale)
{
    if (!ent) return;
    try { NetProps.SetPropFloat(ent, "m_flModelScale", scale); } catch(e) {}
    ent.__KeyValueFromString("rendercolor", "0 0 0");
    ent.__KeyValueFromString("renderamt", "255");
}

function FractureThink()
{
    if (Time() < NEXT_FRACTURE) return;
    Say("map transform differs from recording");
    Glitch(0.6);
    ThrowProps(3 + Memory.intensity, 720, 420);
    Tone(1, 0.35, 60);
    local minDelay = (CHAPTER >= 3) ? 55.0 : 85.0;
    local maxDelay = (CHAPTER >= 3) ? 110.0 : 150.0;
    if (Memory.intensity >= 3) { minDelay *= 0.65; maxDelay *= 0.75; }
    NEXT_FRACTURE = Time() + RandomFloat(minDelay, maxDelay);
}
function ThrowProps(count, radius, force)
{
    local n = 0;
    n += ThrowClass("prop_physics", count - n, radius, force);
    if (n < count) n += ThrowClass("prop_physics_multiplayer", count - n, radius, force);
    if (n < count) n += ThrowClass("prop_physics_override", count - n, radius, force);
}
function ThrowClass(classname, count, radius, force)
{
    if (count <= 0) return 0;
    local ent = null;
    local n = 0;
    while (ent = Entities.FindByClassnameWithin(ent, classname, PLAYER.GetOrigin(), radius)) {
        if (n >= count) break;
        local v = Vector(RandomFloat(-force, force), RandomFloat(-force, force), RandomFloat(force * 0.3, force * 0.85));
        try { ent.ApplyAbsVelocityImpulse(v); } catch(e) { ent.SetOrigin(ent.GetOrigin() + Vector(RandomFloat(-20,20), RandomFloat(-20,20), RandomFloat(0,25))); }
        n++;
    }
    return n;
}
function Glitch(duration)
{
    Cmd("mat_grain_scale_override 18", 0.0);
    Cmd("mat_grain_scale_override 1", duration);
}

function VoidStart()
{
    if (VOID_STARTED || !PLAYER) return;
    VOID_STARTED = true;
    STATE = "VOID";
    Say("exit route not found");
    Cmd("fadeout 0", 0.0);
    SendToServerConsole("director_stop");
    SendToServerConsole("nb_delete_all");
    Delay(VoidStage, 1.5);
}
function VoidStage()
{
    PLAYER.SetOrigin(PLAYER.GetOrigin() + Vector(0,0,2200));
    Cmd("cl_drawhud 0", 0.0);
    Center("N O   E X I T");
    Tone(2, 0.6, 55);
    for (local i = 0; i < 6; i++) SpawnWatcher(260 + i * 20, 8.0, false);
    Delay(VoidEnd, 7.0);
}
function VoidEnd()
{
    ScreenShake(PLAYER.GetOrigin(), 45, 35, 1.4, 260, 0, true);
    Tone(2, 0.75, 55);
    Delay(ExitGame, 1.2);
}
function ExitGame() { Cmd("exit", 0.01); }

function Notebook()
{
    ClientPrint(null, HUD_PRINTTALK, "________ ERROR 404 LOST BUILD ________");
    ClientPrint(null, HUD_PRINTTALK, "STATE: " + STATE + " | CHAPTER: " + CHAPTER);
    ClientPrint(null, HUD_PRINTTALK, "LOOKBACKS: " + Memory.lookbacks + " | SHOTS: " + Memory.shots);
    ClientPrint(null, HUD_PRINTTALK, "WITNESS SEEN: " + Memory.witness_seen + " | CONTACTS: " + Memory.witness_contact);
    ClientPrint(null, HUD_PRINTTALK, "SAFE ROOMS: " + Memory.safe_rooms);
}

ApplyRules();
