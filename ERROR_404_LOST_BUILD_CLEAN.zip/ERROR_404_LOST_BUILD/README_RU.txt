ERROR 404: LOST BUILD — CLEAN

Полностью без SourceMod/MetaMod. Это чистый Workshop-ready VScript mutation.

Установка для теста:
1. Скопируй папку addons/error404_lost_build в Left 4 Dead 2/left4dead2/addons/
2. Запусти игру.
3. В консоли: map c8m1_apartment error404

Установщик INSTALL.bat делает это автоматически.

Проверка загрузки:
В консоли должны быть строки:
ERROR 404 LOST BUILD CLEAN loaded v0.1.0
ERROR404_CLEAN_ACTIVE

Что принципиально убрано:
- SourceMod, MetaMod, DLL, SMX, SP.
- Кастомные runtime-звуки.
- SetAngles/QAngle/FacePlayer.
- TV/сложные ассеты.
- Спам сообщений.

Что есть:
- 1 сцена на карту No Mercy.
- WITNESS как smoker.mdl без поворотов модели.
- Редкие watcher-силуэты.
- Редкий map fracture: только prop_physics и свет/зерно.
- Safe room progression.
- Void finale.

Это стабильная основа, на которую потом можно наращивать сцены.
