@echo off
setlocal EnableExtensions
color 0C
title WITNESS V25 - MADNESS

set "GAME="
if exist "D:\SteamLibrary\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=D:\SteamLibrary\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles(x86)%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME if exist "%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2\left4dead2.exe" set "GAME=%ProgramFiles%\Steam\steamapps\common\Left 4 Dead 2"
if not defined GAME set /p "GAME=Paste the folder containing left4dead2.exe: "
set "GAME=%GAME:"=%"
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%"

if not exist "%GAME%\left4dead2.exe" (
    echo ERROR: left4dead2.exe was not found.
    pause
    exit /b 1
)

echo Cleaning up ALL previous versions...
del /Q "%GAME%\left4dead2\addons\sourcemod\plugins\curse*.smx" 2>NUL
del /Q "%GAME%\left4dead2\addons\sourcemod\plugins\error404*.smx" 2>NUL
del /Q "%GAME%\left4dead2\addons\sourcemod\plugins\witness*.smx" 2>NUL
del /Q "%GAME%\left4dead2\addons\sourcemod\plugins\omnicide*.smx" 2>NUL
del /Q "%GAME%\left4dead2\addons\sourcemod\plugins\fatal*.smx" 2>NUL
del /Q "%GAME%\left4dead2\addons\sourcemod\plugins\haunted*.smx" 2>NUL
if exist "%GAME%\left4dead2\addons\metamod.vdf.disabled" del /Q "%GAME%\left4dead2\addons\metamod.vdf.disabled"

echo Injecting V25 MADNESS Payload...
xcopy "%~dp0WITNESS_FILES\*" "%GAME%\left4dead2\" /E /I /H /R /Y /Q >NUL

echo Launching L4D2...
timeout /t 2 /nobreak >NUL
start "" "%GAME%\left4dead2.exe" -insecure -console -windowed -noborder +sv_consistency 0 +map c8m1_apartment coop
endlocal