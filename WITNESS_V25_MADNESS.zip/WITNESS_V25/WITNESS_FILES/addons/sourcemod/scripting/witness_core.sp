#pragma semicolon 1
#pragma newdecls required

#include <sourcemod>
#include <sdktools>
#include <sdkhooks>

#define PLUGIN_VERSION "25.0.0"

static const char SURV_MODELS[][] = {
    "models/survivors/survivor_namvet.mdl", // Bill
    "models/survivors/survivor_biker.mdl",  // Francis
    "models/survivors/survivor_teenangst.mdl", // Zoey
    "models/survivors/survivor_manager.mdl", // Louis
    "models/survivors/survivor_coach.mdl",
    "models/survivors/survivor_gambler.mdl"
};

enum Phase {
    P_Init = 0,
    P_Normal,
    P_Corrupted,
    P_Void
};

Phase g_Phase = P_Init;
bool g_bActive = false;
bool g_bSafeRoomTrap = false;

int g_iWitchRef = INVALID_ENT_REFERENCE;
float g_fNextTeleport = 0.0;
float g_fNextAttack = 0.0;
float g_fNextGlitch = 0.0;
float g_fNextStatue = 0.0;

int g_iChapter = 1;
float g_fSpawnOrigin[3];

ConVar g_cvTimeScale;
ConVar g_cvGravity;

public Plugin myinfo = {
    name = "WITNESS V25: MADNESS",
    author = "NELIXO",
    description = "True Isolation, Stalker, and Absolute Terror",
    version = PLUGIN_VERSION
};

public void OnPluginStart() {
    HookEvent("round_start", Event_RoundStart, EventHookMode_PostNoCopy);
    HookEvent("player_spawn", Event_PlayerSpawn, EventHookMode_Post);
    HookEvent("door_close", Event_DoorClose, EventHookMode_Post);
    
    // We don't use finale_start, we intercept button presses directly!
    HookEntityOutput("func_button", "OnPressed", OnButtonPressed);
    
    g_cvTimeScale = FindConVar("host_timescale");
    g_cvGravity = FindConVar("sv_gravity");
    
    if (g_cvTimeScale != null) g_cvTimeScale.Flags &= ~FCVAR_CHEAT;
    if (g_cvGravity != null) g_cvGravity.Flags &= ~FCVAR_CHEAT;
    SetCommandFlags("r_screenoverlay", GetCommandFlags("r_screenoverlay") & ~FCVAR_CHEAT);
    
    CreateTimer(0.1, Timer_MainLoop, _, TIMER_REPEAT);
    CreateTimer(0.1, Timer_FastPurge, _, TIMER_REPEAT); // Aggressive purge!
}

public void OnMapStart() {
    PrecacheModel("models/infected/witch.mdl", true);
    for (int i=0; i<sizeof(SURV_MODELS); i++) PrecacheModel(SURV_MODELS[i], true);
    
    PrecacheSound("ambient/atmosphere/cave_hit5.wav", true);
    PrecacheSound("ambient/ambience/rainscapes/Thunder_close01.wav", true);
    PrecacheSound("music/witness_v25/screamer.wav", true);
    PrecacheSound("music/witness_v25/void_drone.wav", true);
    PrecacheSound("music/witness_v25/static_burst.wav", true);
    
    AddFileToDownloadsTable("materials/witness_v25/scream_face.vtf");
    AddFileToDownloadsTable("materials/witness_v25/scream_face.vmt");
    AddFileToDownloadsTable("materials/witness_v25/tv_noise.vtf");
    AddFileToDownloadsTable("materials/witness_v25/tv_noise.vmt");
    AddFileToDownloadsTable("sound/music/witness_v25/screamer.wav");
    AddFileToDownloadsTable("sound/music/witness_v25/void_drone.wav");
    AddFileToDownloadsTable("sound/music/witness_v25/static_burst.wav");

    char map[64]; GetCurrentMap(map, sizeof(map));
    g_iChapter = 1;
    for (int i=0; i<strlen(map); i++) {
        if (map[i] == 'm' && i+1 < strlen(map)) {
            int c = map[i+1] - '0';
            if (c >= 1 && c <= 5) g_iChapter = c;
        }
    }
    
    g_bActive = true;
    ResetEngine();
}

public void OnMapEnd() { ResetEngine(); }

void ResetEngine() {
    if (g_cvTimeScale != null) g_cvTimeScale.FloatValue = 1.0;
    if (g_cvGravity != null) g_cvGravity.FloatValue = 800.0;
    for (int i=1; i<=MaxClients; i++) if (IsClientInGame(i) && !IsFakeClient(i)) {
        SetEntProp(i, Prop_Send, "m_iDefaultFOV", 90);
        ClientCommand(i, "r_screenoverlay \"\"");
        float a[3]; GetClientEyeAngles(i, a); a[2] = 0.0; TeleportEntity(i, NULL_VECTOR, a, NULL_VECTOR);
    }
}

public void OnClientPutInServer(int client) {
    SDKHook(client, SDKHook_OnTakeDamage, OnTakeDamage);
}

public Action OnTakeDamage(int victim, int &attacker, int &inflictor, float &damage, int &damagetype) {
    // Disable fall damage
    if (victim > 0 && victim <= MaxClients && (damagetype & DMG_FALL)) {
        damage = 0.0;
        return Plugin_Handled;
    }
    return Plugin_Continue;
}

// Aggressive Purge of all Infected, right as they spawn
public void OnEntityCreated(int entity, const char[] classname) {
    if (!g_bActive || g_Phase < P_Corrupted) return;
    if (StrEqual(classname, "infected") || StrEqual(classname, "witch")) {
        // Destroy instantly next frame
        RequestFrame(Frame_RemoveEntity, EntIndexToEntRef(entity));
    }
}
public void Frame_RemoveEntity(any ref) {
    int ent = EntRefToEntIndex(ref);
    if (ent > MaxClients && IsValidEntity(ent)) RemoveEntity(ent);
}

public Action Timer_FastPurge(Handle timer) {
    if (!g_bActive || g_Phase < P_Corrupted) return Plugin_Continue;
    
    // Purge Specials
    for (int i=1; i<=MaxClients; i++) {
        if (IsClientInGame(i) && GetClientTeam(i) == 3) {
            if (IsPlayerAlive(i)) ForcePlayerSuicide(i);
            if (IsFakeClient(i)) KickClient(i, "");
        }
    }
    return Plugin_Continue;
}

public void Event_RoundStart(Event event, const char[] name, bool dontBroadcast) {
    g_Phase = P_Init; g_bActive = true; g_bSafeRoomTrap = false;
    ResetEngine();
}

public void Event_PlayerSpawn(Event event, const char[] name, bool dontBroadcast) {
    int client = GetClientOfUserId(event.GetInt("userid"));
    if (client > 0 && IsClientInGame(client) && !IsFakeClient(client) && GetClientTeam(client) == 2) {
        GetClientAbsOrigin(client, g_fSpawnOrigin);
        if (g_iChapter >= 2) {
            TriggerCorruption(client);
        } else {
            g_Phase = P_Normal;
            ClientCommand(client, "r_screenoverlay \"\"");
        }
    }
}

public void OnButtonPressed(const char[] output, int caller, int activator, float delay) {
    if (g_iChapter >= 4 && activator > 0 && activator <= MaxClients && !IsFakeClient(activator)) {
        if (g_Phase != P_Void) {
            // Button pressed in finale map! (Elevator/Radio)
            TriggerVoid(activator);
        }
    }
}

public void Event_DoorClose(Event event, const char[] name, bool dontBroadcast) {
    if (g_Phase >= P_Corrupted && event.GetBool("checkpoint") && !g_bSafeRoomTrap && g_iChapter < 4) {
        g_bSafeRoomTrap = true;
        int p = GetRealPlayer();
        if (p > 0) {
            SetLightStyle(0, "a");
            EmitSoundToClient(p, "music/witness_v25/screamer.wav", SOUND_FROM_PLAYER, SNDCHAN_STATIC, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
            ScreenShake(p, 40.0, 30.0, 3.0);
            ShowOverlay(p, "witness_v25/scream_face", 3.0);
            
            float pos[3]; GetClientAbsOrigin(p, pos);
            for(int i=0; i<8; i++) {
                int e = CreateEntityByName("prop_dynamic_override");
                if (e != -1) {
                    DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS)-1)]); DispatchKeyValue(e, "solid", "0"); DispatchSpawn(e);
                    float y = i * 45.0 * 3.14159 / 180.0;
                    float ep[3]; ep[0]=pos[0]+Cosine(y)*70.0; ep[1]=pos[1]+Sine(y)*70.0; ep[2]=pos[2];
                    float ea[3]; ea[1] = (y * 180.0 / 3.14159) + 180.0;
                    TeleportEntity(e, ep, ea, NULL_VECTOR);
                    SetEntityRenderMode(e, RENDER_TRANSCOLOR); SetEntityRenderColor(e, 0, 0, 0, 255);
                    SetEntPropFloat(e, Prop_Send, "m_flModelScale", GetRandomFloat(2.5, 4.0));
                    SetEntProp(e, Prop_Send, "m_nSequence", 0); // T-Pose
                }
            }
        }
    }
}

void TriggerCorruption(int client) {
    if (g_Phase >= P_Corrupted) return;
    g_Phase = P_Corrupted;
    
    // Boom!
    EmitSoundToClient(client, "ambient/ambience/rainscapes/Thunder_close01.wav", SOUND_FROM_PLAYER, SNDCHAN_STATIC, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
    Handle msg = StartMessageOne("Fade", client);
    if (msg!=null) { BfWriteShort(msg, 200); BfWriteShort(msg, 3000); BfWriteShort(msg, 0x0010); BfWriteByte(msg, 255); BfWriteByte(msg, 255); BfWriteByte(msg, 255); BfWriteByte(msg, 255); EndMessage(); }
    
    // Purge Bots
    for (int i = 1; i <= MaxClients; i++) if (IsClientInGame(i) && IsFakeClient(i) && GetClientTeam(i) == 2) KickClient(i, "");
    
    SetDarkness();
    g_fNextTeleport = GetGameTime() + 5.0;
    g_fNextStatue = GetGameTime() + 10.0;
}

void SetDarkness() {
    int fog = FindEntityByClassname(-1, "env_fog_controller");
    if (fog != -1) { DispatchKeyValue(fog, "fogcolor", "0 0 0"); DispatchKeyValue(fog, "fogmaxdensity", "1.0"); SetVariantInt(-50); AcceptEntityInput(fog, "SetStartDist"); SetVariantInt(150); AcceptEntityInput(fog, "SetEndDist"); }
    SetLightStyle(0, "a");
}

public Action Timer_MainLoop(Handle timer) {
    if (!g_bActive) return Plugin_Continue;
    float now = GetGameTime(); int p = GetRealPlayer(); if (p <= 0) return Plugin_Continue;
    
    if (g_Phase == P_Normal) {
        float pPos[3]; GetClientAbsOrigin(p, pPos);
        if (GetVectorDistance(g_fSpawnOrigin, pPos) > 1500.0) {
            TriggerCorruption(p);
        }
    }
    else if (g_Phase == P_Corrupted) {
        UpdateWitch(p, now);
        
        // --- 1. Glitches and Chaos ---
        if (now > g_fNextGlitch) {
            g_fNextGlitch = now + GetRandomFloat(5.0, 15.0);
            int roll = GetRandomInt(0, 3);
            if (roll == 0) {
                // Roll screen
                float a[3]; GetClientEyeAngles(p, a); a[2] = GetRandomFloat(-45.0, 45.0);
                TeleportEntity(p, NULL_VECTOR, a, NULL_VECTOR);
                EmitSoundToClient(p, "music/witness_v25/static_burst.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
                CreateTimer(3.0, Timer_RestoreRoll, GetClientUserId(p));
            } else if (roll == 1) {
                // Flashlight glitch
                int effects = GetEntProp(p, Prop_Send, "m_fEffects");
                if (effects & 4) SetEntProp(p, Prop_Send, "m_fEffects", effects & ~4);
                ShowOverlay(p, "witness_v25/tv_noise", 0.5);
                EmitSoundToClient(p, "music/witness_v25/static_burst.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
            } else if (roll == 2 && g_cvGravity != null) {
                // Low gravity burst
                g_cvGravity.FloatValue = 200.0;
                CreateTimer(4.0, Timer_RestoreGrav);
            }
        }
        
        // --- 2. Statue Watchers ---
        if (now > g_fNextStatue) {
            g_fNextStatue = now + GetRandomFloat(10.0, 20.0);
            float pPos[3], pAng[3]; GetClientAbsOrigin(p, pPos); GetClientEyeAngles(p, pAng);
            float y = (pAng[1] + GetRandomFloat(-45.0, 45.0)) * 3.14159 / 180.0;
            float sP[3]; sP[0]=pPos[0]+Cosine(y)*500.0; sP[1]=pPos[1]+Sine(y)*500.0; sP[2]=pPos[2]+10.0;
            int e = CreateEntityByName("prop_dynamic_override");
            if (e != -1) {
                DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS)-1)]); DispatchSpawn(e);
                // ALWAYS FACE PLAYER
                float ea[3], d[3]; MakeVectorFromPoints(sP, pPos, d); GetVectorAngles(d, ea); ea[0]=0.0; ea[2]=0.0;
                TeleportEntity(e, sP, ea, NULL_VECTOR);
                SetEntityRenderMode(e, RENDER_TRANSCOLOR); SetEntityRenderColor(e, 0, 0, 0, 255);
                
                // Bone Scaling (Distortion)
                SetEntPropFloat(e, Prop_Send, "m_flModelScale", GetRandomFloat(1.5, 3.0));
                SetEntProp(e, Prop_Send, "m_nSequence", 0); SetEntPropFloat(e, Prop_Send, "m_flPlaybackRate", 0.0);
                
                CreateTimer(8.0, Timer_DeleteStatue, EntIndexToEntRef(e));
            }
        }
    }
    else if (g_Phase == P_Void) {
        float a[3]; GetClientEyeAngles(p, a); a[2] += 0.5; TeleportEntity(p, NULL_VECTOR, a, NULL_VECTOR);
        PrintCenterText(p, "Y O U   C A N N O T   E X I T");
    }
    return Plugin_Continue;
}

public Action Timer_RestoreRoll(Handle timer, any userid) {
    int p = GetClientOfUserId(userid); if (p > 0 && IsClientInGame(p)) { float a[3]; GetClientEyeAngles(p, a); a[2] = 0.0; TeleportEntity(p, NULL_VECTOR, a, NULL_VECTOR); } return Plugin_Stop;
}
public Action Timer_RestoreGrav(Handle timer) {
    if (g_cvGravity != null) g_cvGravity.FloatValue = 800.0; return Plugin_Stop;
}
public Action Timer_DeleteStatue(Handle timer, any ref) {
    int e = EntRefToEntIndex(ref); if (e != INVALID_ENT_REFERENCE && IsValidEntity(e)) {
        // Disappear sound
        EmitSoundToAll("music/witness_v25/static_burst.wav", e, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 0.4);
        RemoveEntity(e);
    }
    return Plugin_Stop;
}

void UpdateWitch(int p, float now) {
    int witch = EntRefToEntIndex(g_iWitchRef);
    if (witch == INVALID_ENT_REFERENCE || !IsValidEntity(witch)) {
        float pPos[3], pAng[3]; GetClientAbsOrigin(p, pPos); GetClientEyeAngles(p, pAng);
        float yaw = (pAng[1] + 180.0) * 3.14159 / 180.0;
        float sPos[3]; sPos[0]=pPos[0]+Cosine(yaw)*800.0; sPos[1]=pPos[1]+Sine(yaw)*800.0; sPos[2]=pPos[2]+10.0;
        
        int e = CreateEntityByName("prop_dynamic_override");
        if (e != -1) {
            DispatchKeyValue(e, "model", "models/infected/witch.mdl"); DispatchKeyValue(e, "targetname", "witness_stalker"); DispatchSpawn(e);
            float d[3], a[3]; MakeVectorFromPoints(sPos, pPos, d); GetVectorAngles(d, a); a[0]=0.0; a[2]=0.0; TeleportEntity(e, sPos, a, NULL_VECTOR);
            SetEntityRenderMode(e, RENDER_TRANSCOLOR); SetEntityRenderColor(e, 0, 0, 0, 255);
            SetEntProp(e, Prop_Data, "m_nSequence", 4); g_iWitchRef = EntIndexToEntRef(e);
        }
    } else {
        float wPos[3], pPos[3], dir[3], ang[3]; GetEntPropVector(witch, Prop_Data, "m_vecAbsOrigin", wPos); GetClientAbsOrigin(p, pPos);
        MakeVectorFromPoints(wPos, pPos, dir); dir[2]=0.0; NormalizeVector(dir, dir); GetVectorAngles(dir, ang); ang[0]=0.0; ang[2]=0.0; TeleportEntity(witch, NULL_VECTOR, ang, NULL_VECTOR);
        
        float dist = GetVectorDistance(wPos, pPos);
        float pEye[3], pFwd[3], wDir[3]; GetClientEyePosition(p, pEye); GetClientEyeAngles(p, ang); GetAngleVectors(ang, pFwd, NULL_VECTOR, NULL_VECTOR);
        float wC[3]; for(int i=0;i<3;i++) wC[i]=wPos[i]; wC[2]+=40.0; MakeVectorFromPoints(pEye, wC, wDir); NormalizeVector(wDir, wDir);
        bool looking = (GetVectorDotProduct(pFwd, wDir) > 0.4);
        
        if (looking) {
            if (g_cvTimeScale != null) g_cvTimeScale.FloatValue = 0.3;
            // Pulsing FOV zoom
            int fov = 90 - RoundToNearest(50.0 * Sine(now * 5.0));
            SetEntProp(p, Prop_Send, "m_iDefaultFOV", fov);
            
            if (now > g_fNextAttack) { EmitSoundToClient(p, "ambient/energy/zap1.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 70); g_fNextAttack = now + 1.0; }
        } else {
            ResetEngine();
            if (now > g_fNextTeleport) {
                g_fNextTeleport = now + GetRandomFloat(4.0, 8.0);
                float y = (ang[1] + 180.0 + GetRandomFloat(-45.0, 45.0)) * 3.14159 / 180.0;
                float nP[3]; nP[0]=pPos[0]+Cosine(y)*200.0; nP[1]=pPos[1]+Sine(y)*200.0; nP[2]=pPos[2]+10.0;
                TeleportEntity(witch, nP, NULL_VECTOR, NULL_VECTOR);
                SetEntProp(witch, Prop_Data, "m_nSequence", 6); SetEntPropFloat(witch, Prop_Send, "m_flPlaybackRate", 1.5);
                EmitSoundToClient(p, "ambient/atmosphere/cave_hit5.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 60);
            }
        }
        
        if (dist < 80.0) {
            // STRIKE
            EmitSoundToClient(p, "music/witness_v25/screamer.wav", SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
            ShowOverlay(p, "witness_v25/scream_face", 1.0);
            
            float vel[3]; vel[0] = dir[0] * -1200.0; vel[1] = dir[1] * -1200.0; vel[2] = 300.0;
            TeleportEntity(p, NULL_VECTOR, NULL_VECTOR, vel);
            
            Handle msg = StartMessageOne("Fade", p);
            if (msg!=null) { BfWriteShort(msg, 200); BfWriteShort(msg, 0); BfWriteShort(msg, 0x0001); BfWriteByte(msg, 255); BfWriteByte(msg, 0); BfWriteByte(msg, 0); BfWriteByte(msg, 200); EndMessage(); }
            
            int effects = GetEntProp(p, Prop_Send, "m_fEffects"); if (effects & 4) SetEntProp(p, Prop_Send, "m_fEffects", effects & ~4);
            RemoveEntity(witch); g_iWitchRef = INVALID_ENT_REFERENCE; g_fNextTeleport = now + 15.0;
        }
    }
}

void TriggerVoid(int p) {
    if (g_Phase == P_Void) return;
    g_Phase = P_Void;
    
    float pos[3]; GetClientAbsOrigin(p, pos); pos[2] += 2000.0;
    int w = -1; while((w=GetPlayerWeaponSlot(p,0))!=-1){RemovePlayerItem(p,w);RemoveEntity(w);} while((w=GetPlayerWeaponSlot(p,1))!=-1){RemovePlayerItem(p,w);RemoveEntity(w);}
    SetEntityMoveType(p, MOVETYPE_NONE);
    TeleportEntity(p, pos, NULL_VECTOR, NULL_VECTOR);
    
    int fog = FindEntityByClassname(-1, "env_fog_controller");
    if (fog != -1) { DispatchKeyValue(fog, "fogcolor", "0 0 0"); DispatchKeyValue(fog, "fogmaxdensity", "1.0"); SetVariantInt(0); AcceptEntityInput(fog, "SetStartDist"); SetVariantInt(50); AcceptEntityInput(fog, "SetEndDist"); }
    SetLightStyle(0, "a");
    
    EmitSoundToClient(p, "music/witness_v25/void_drone.wav", SOUND_FROM_PLAYER, SNDCHAN_STATIC, SNDLEVEL_NORMAL, SND_NOFLAGS, 1.0, 100);
    
    for (int i=0; i<20; i++) {
        float yaw = (i*18.0)*3.14159/180.0; float mP[3]; mP[0]=pos[0]+Cosine(yaw)*200.0; mP[1]=pos[1]+Sine(yaw)*200.0; mP[2]=pos[2];
        int e = CreateEntityByName("prop_dynamic_override");
        if (e != -1) {
            DispatchKeyValue(e, "model", SURV_MODELS[GetRandomInt(0, sizeof(SURV_MODELS)-1)]); DispatchSpawn(e);
            float mA[3], d[3]; MakeVectorFromPoints(mP, pos, d); GetVectorAngles(d, mA); mA[0]=0.0; mA[2]=0.0;
            TeleportEntity(e, mP, mA, NULL_VECTOR); SetEntityRenderMode(e, RENDER_TRANSCOLOR); SetEntityRenderColor(e, 0, 0, 0, 255);
            SetEntPropFloat(e, Prop_Send, "m_flModelScale", 2.0); SetEntProp(e, Prop_Data, "m_nSequence", 0);
        }
    }
    CreateTimer(12.0, Timer_ExitGame, GetClientUserId(p));
}

public Action Timer_ExitGame(Handle timer, any userid) { int p = GetClientOfUserId(userid); if (p > 0) ClientCommand(p, "exit"); return Plugin_Stop; }

void ShowOverlay(int c, const char[] o, float d) {
    ClientCommand(c, "r_screenoverlay \"%s\"", o);
    if (d < 900.0) { DataPack pack = new DataPack(); pack.WriteCell(GetClientUserId(c)); CreateTimer(d, Timer_RemoveOverlay, pack, TIMER_DATA_HNDL_CLOSE); }
}
public Action Timer_RemoveOverlay(Handle timer, DataPack pack) { pack.Reset(); int c = GetClientOfUserId(pack.ReadCell()); if (c > 0 && IsClientInGame(c)) ClientCommand(c, "r_screenoverlay \"\""); return Plugin_Stop; }

void ScreenShake(int c, float a, float f, float d) { Handle m = StartMessageOne("Shake", c); if (m==null) return; BfWriteByte(m, 0); BfWriteFloat(m, a); BfWriteFloat(m, f); BfWriteFloat(m, d); EndMessage(); }
int GetRealPlayer() { for (int i=1; i<=MaxClients; i++) if (IsClientInGame(i) && !IsFakeClient(i) && GetClientTeam(i) == 2 && IsPlayerAlive(i)) return i; return 0; }