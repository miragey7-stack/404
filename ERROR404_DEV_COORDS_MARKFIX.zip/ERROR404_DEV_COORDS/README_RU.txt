ERROR404 DEV COORDS

Это НЕ хоррор-версия. Это dev-инструмент для снятия координат и событий карты.
Цель: перестать гадать Flow() > N и начать делать линейные сцены по точкам.

Установка:
- Запусти INSTALL_DEV.bat
- Или вручную: map c8m1_apartment error404dev

После запуска в консоли должны быть:
ERROR404 DEV COORDS loaded v0.1.0
ERROR404_DEV_ACTIVE

Команды в консоли игры:
e404_pos      - печатает карту, origin, angles, flow
e404_box      - печатает маленький trigger box вокруг текущей позиции
e404_bigbox   - печатает большой trigger box вокруг текущей позиции
e404_status   - текущий статус

Метки:
e404_mark_street
e404_mark_eyes
e404_mark_safe1
e404_mark_train
e404_mark_light
e404_mark_c3safe
e404_mark_elevator
e404_mark_radio
e404_mark_boss
e404_mark_rescue

События автоматически логируются:
- player_use
- door_open
- door_close
- finale_start
- finale_vehicle_ready
- player_spawn
- round_start

Что мне потом скидывать:
- строки MARK ...
- строки EVENT player_use / door_close около нужных мест
- e404_box для зон триггеров


Hotfix 0.1.1:
- Исправлена ошибка the index 'Mark' does not exist. Mark заменён на MarkPoint <- function.
