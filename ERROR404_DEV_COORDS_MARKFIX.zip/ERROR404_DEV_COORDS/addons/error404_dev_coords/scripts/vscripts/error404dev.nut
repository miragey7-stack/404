/* ERROR404 DEV COORDS
   Pure VScript mutation helper. No horror. No SourceMod.
*/

Msg("ERROR404 DEV COORDS loaded v0.1.1\n");
printl("ERROR404_DEV_ACTIVE");

MutationOptions <-
{
    CommonLimit = 20
    MegaMobSize = 20
    cm_MaxSpecials = 1
    DefaultItems = [ "pistol" ]
    function GetDefaultItem(idx)
    {
        if (idx < DefaultItems.len()) return DefaultItems[idx];
        return 0;
    }
}

PLAYER <- null;
THINKER <- null;
LAST_PRINT <- 0.0;
AUTO_PRINT <- false;

function IsHuman(ent)
{
    if (!ent) return false;
    if (IsPlayerABot(ent)) return false;
    try { return ent.IsSurvivor(); } catch(e) { return false; }
}

function MapName()
{
    return Director.GetMapName();
}

function Flow()
{
    if (!PLAYER) return 0.0;
    try { return GetCurrentFlowPercentForPlayer(PLAYER); } catch(e) { return -1.0; }
}

function VStr(v)
{
    return format("Vector(%.3f, %.3f, %.3f)", v.x, v.y, v.z);
}

function AngStr(a)
{
    return format("QAngle(%.3f, %.3f, %.3f)", a.x, a.y, a.z);
}

function PrintBoth(line)
{
    printl(line);
    ClientPrint(null, HUD_PRINTTALK, line);
}

function PrintPos(label = "POS")
{
    if (!PLAYER) {
        PrintBoth("ERROR404 DEV: PLAYER is null");
        return;
    }
    local p = PLAYER.GetOrigin();
    local a = PLAYER.EyeAngles();
    local f = Flow();
    PrintBoth(format("%s map=%s origin=%s eye=%s angles=%s flow=%.2f", label, MapName(), VStr(p), VStr(PLAYER.EyePosition()), AngStr(a), f));
}

function PrintBox(label, size)
{
    if (!PLAYER) return;
    local p = PLAYER.GetOrigin();
    local mn = Vector(p.x - size, p.y - size, p.z - 96);
    local mx = Vector(p.x + size, p.y + size, p.z + 128);
    PrintBoth(format("BOX %s map=%s min=%s max=%s center=%s flow=%.2f", label, MapName(), VStr(mn), VStr(mx), VStr(p), Flow()));
}

MarkPoint <- function(label)
{
    PrintPos("MARK " + label);
    PrintBox(label + "_small", 160);
}

function DumpParams(name, params)
{
    local line = "EVENT " + name + " map=" + MapName();
    if (PLAYER) line += " player=" + VStr(PLAYER.GetOrigin()) + format(" flow=%.2f", Flow());
    printl(line);
    ClientPrint(null, HUD_PRINTTALK, line);
    foreach(k, v in params) {
        local kv = "  " + k + " = " + v;
        printl(kv);
    }
}

function ApplyDevRules()
{
    Convars.SetValue("sv_cheats", 1);
    Convars.SetValue("sv_consistency", 0);
    SendToServerConsole("alias e404_pos scripted_user_func e404_pos");
    SendToServerConsole("alias e404_box scripted_user_func e404_box");
    SendToServerConsole("alias e404_bigbox scripted_user_func e404_bigbox");
    SendToServerConsole("alias e404_status scripted_user_func e404_status");
    SendToServerConsole("alias e404_auto scripted_user_func e404_auto");
    SendToServerConsole("alias e404_mark_street scripted_user_func e404_mark_street");
    SendToServerConsole("alias e404_mark_eyes scripted_user_func e404_mark_eyes");
    SendToServerConsole("alias e404_mark_safe1 scripted_user_func e404_mark_safe1");
    SendToServerConsole("alias e404_mark_train scripted_user_func e404_mark_train");
    SendToServerConsole("alias e404_mark_light scripted_user_func e404_mark_light");
    SendToServerConsole("alias e404_mark_c3safe scripted_user_func e404_mark_c3safe");
    SendToServerConsole("alias e404_mark_elevator scripted_user_func e404_mark_elevator");
    SendToServerConsole("alias e404_mark_radio scripted_user_func e404_mark_radio");
    SendToServerConsole("alias e404_mark_boss scripted_user_func e404_mark_boss");
    SendToServerConsole("alias e404_mark_rescue scripted_user_func e404_mark_rescue");
}

function SpawnThinker()
{
    local old = Entities.FindByName(null, "e404_dev_thinker");
    if (old) old.Kill();
    THINKER = SpawnEntityFromTable("info_target", { targetname = "e404_dev_thinker" });
    if (THINKER.ValidateScriptScope()) {
        local sc = THINKER.GetScriptScope();
        sc["Think"] <- function()
        {
            g_ModeScript.DevThink();
            return 1.0;
        }
        AddThinkToEnt(THINKER, "Think");
    }
}

function DevThink()
{
    if (!AUTO_PRINT || !PLAYER) return;
    if (Time() > LAST_PRINT + 5.0) {
        LAST_PRINT = Time();
        PrintPos("AUTO");
    }
}

function OnGameplayStart()
{
    ApplyDevRules();
    SpawnThinker();
    PrintBoth("ERROR404 DEV READY map=" + MapName());
}

function OnShutdown()
{
    if (THINKER) THINKER.Kill();
}

function OnGameEvent_player_spawn(params)
{
    local p = GetPlayerFromUserID(params.userid);
    if (IsHuman(p)) {
        PLAYER = p;
        PrintPos("PLAYER_SPAWN");
    }
}
function OnGameEvent_player_first_spawn(params) { OnGameEvent_player_spawn(params); }
function OnGameEvent_player_connect_full(params)
{
    local p = GetPlayerFromUserID(params.userid);
    if (IsHuman(p)) PLAYER = p;
}
function OnGameEvent_round_start(params) { DumpParams("round_start", params); }
function OnGameEvent_player_use(params) { DumpParams("player_use", params); }
function OnGameEvent_door_open(params) { DumpParams("door_open", params); }
function OnGameEvent_door_close(params) { DumpParams("door_close", params); }
function OnGameEvent_finale_start(params) { DumpParams("finale_start", params); }
function OnGameEvent_finale_vehicle_ready(params) { DumpParams("finale_vehicle_ready", params); }
function OnGameEvent_finale_radio_start(params) { DumpParams("finale_radio_start", params); }
function OnGameEvent_button_pressed(params) { DumpParams("button_pressed", params); }

function UserConsoleCommand(playerScript, arg)
{
    switch(arg) {
        case "e404_pos": PrintPos("POS"); break;
        case "e404_box": PrintBox("manual_small", 160); break;
        case "e404_bigbox": PrintBox("manual_big", 360); break;
        case "e404_status": PrintBoth(format("STATUS map=%s flow=%.2f auto=%s", MapName(), Flow(), AUTO_PRINT ? "on" : "off")); break;
        case "e404_auto": AUTO_PRINT = !AUTO_PRINT; PrintBoth("AUTO_PRINT " + (AUTO_PRINT ? "ON" : "OFF")); break;
        case "e404_mark_street": MarkPoint("c8m1_street"); break;
        case "e404_mark_eyes": MarkPoint("c8m1_eyes"); break;
        case "e404_mark_safe1": MarkPoint("safe_door"); break;
        case "e404_mark_train": MarkPoint("c8m2_train"); break;
        case "e404_mark_light": MarkPoint("c8m2_light_event"); break;
        case "e404_mark_c3safe": MarkPoint("c8m3_safe_rush"); break;
        case "e404_mark_elevator": MarkPoint("c8m4_elevator"); break;
        case "e404_mark_radio": MarkPoint("c8m5_radio"); break;
        case "e404_mark_boss": MarkPoint("c8m5_boss_arena"); break;
        case "e404_mark_rescue": MarkPoint("c8m5_rescue"); break;
    }
}

ApplyDevRules();
